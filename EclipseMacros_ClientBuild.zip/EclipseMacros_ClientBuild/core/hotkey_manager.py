
import ctypes
import ctypes.wintypes
from PyQt6.QtCore import QObject, QThread, pyqtSignal

user32   = ctypes.windll.user32
kernel32 = ctypes.windll.kernel32

MOD_NOREPEAT = 0x4000   # fire once per press, no auto-repeat

WM_HOTKEY = 0x0312

_VK_MAP = {
    # Function keys
    "f1":  0x70, "f2":  0x71, "f3":  0x72, "f4":  0x73,
    "f5":  0x74, "f6":  0x75, "f7":  0x76, "f8":  0x77,
    "f9":  0x78, "f10": 0x79, "f11": 0x7A, "f12": 0x7B,
    # Letters
    "a": 0x41, "b": 0x42, "c": 0x43, "d": 0x44, "e": 0x45,
    "f": 0x46, "g": 0x47, "h": 0x48, "i": 0x49, "j": 0x4A,
    "k": 0x4B, "l": 0x4C, "m": 0x4D, "n": 0x4E, "o": 0x4F,
    "p": 0x50, "q": 0x51, "r": 0x52, "s": 0x53, "t": 0x54,
    "u": 0x55, "v": 0x56, "w": 0x57, "x": 0x58, "y": 0x59,
    "z": 0x5A,
    # Numbers
    "0": 0x30, "1": 0x31, "2": 0x32, "3": 0x33, "4": 0x34,
    "5": 0x35, "6": 0x36, "7": 0x37, "8": 0x38, "9": 0x39,
    # Numpad
    "num0": 0x60, "num1": 0x61, "num2": 0x62, "num3": 0x63,
    "num4": 0x64, "num5": 0x65, "num6": 0x66, "num7": 0x67,
    "num8": 0x68, "num9": 0x69,
    # Special keys
    "ins":       0x2D, "insert":    0x2D,
    "del":       0x2E, "delete":    0x2E,
    "home":      0x24, "end":       0x23,
    "pgup":      0x21, "pgdown":    0x22,
    "left":      0x25, "up":        0x26,
    "right":     0x27, "down":      0x28,
    "tab":       0x09, "caps":      0x14,
    "esc":       0x1B, "escape":    0x1B,
    "space":     0x20, "return":    0x0D,
    "backspace": 0x08,
}

_ID_TO_ACTION = {
    1: "start",
    3: "stop",
    4: "show_ui",
    5: "pixel",
    6: "calibration",
    7: "fat_calibration",
}
_ACTION_TO_ID = {v: k for k, v in _ID_TO_ACTION.items()}

class _HotkeyThread(QThread):
    sig_hotkey = pyqtSignal(str)   # emits action name string

    def __init__(self, bindings: dict, disabled_actions: set = None):
        super().__init__()
        self._bindings   = dict(bindings)
        self._disabled   = set(disabled_actions) if disabled_actions else set()
        self._stop_event = False

    def run(self):
        try:
            self._run_inner()
        except Exception:
            # Safety net: never let an unhandled exception in this thread
            # propagate to Qt's thread-termination handler, which would
            # silently close the whole application on Windows 11.
            pass

    def _run_inner(self):
        registered_ids = []
        for action, key in self._bindings.items():
            if action in self._disabled:
                continue
            hid = _ACTION_TO_ID.get(action)
            # Normalize: PyQt6 may return "M", "Shift+M", "F1", etc.
            raw = (key or "").strip()
            # Strip modifiers — take only the base key (last part after +)
            base = raw.split("+")[-1].lower()
            vk  = _VK_MAP.get(base)
            if hid and vk:
                # First attempt: with MOD_NOREPEAT (preferred)
                ok = user32.RegisterHotKey(None, hid, MOD_NOREPEAT, vk)
                if not ok:
                    # Fallback: some Windows 11 builds / third-party apps
                    # hold F2/F3 with MOD_NOREPEAT already registered.
                    # Retry without that flag so the hotkey still works.
                    ok = user32.RegisterHotKey(None, hid, 0, vk)
                if ok:
                    registered_ids.append(hid)

        msg = ctypes.wintypes.MSG()
        while not self._stop_event:
            try:
                if user32.PeekMessageW(ctypes.byref(msg), None, 0, 0, 1):
                    if msg.message == WM_HOTKEY:
                        action = _ID_TO_ACTION.get(msg.wParam)
                        if action:
                            self.sig_hotkey.emit(action)
                else:
                    kernel32.Sleep(10)
            except Exception:
                kernel32.Sleep(10)

        for hid in registered_ids:
            try:
                user32.UnregisterHotKey(None, hid)
            except Exception:
                pass

    def stop(self):
        self._stop_event = True

class HotkeyManager(QObject):

    sig_start   = pyqtSignal()
    sig_stop    = pyqtSignal()
    sig_pixel   = pyqtSignal()
    sig_show_ui = pyqtSignal()
    sig_calibration = pyqtSignal()
    sig_fat_calibration = pyqtSignal()

    def __init__(self):
        super().__init__()
        self._bindings: dict = {
            "start":   "f1",
            "stop":    "f3",
            "show_ui": "f9",
            "pixel":   "f10",
            "calibration": "k",
            "fat_calibration": "j",
        }
        self._thread = None
        self._disabled_actions: set = set()  # actions whose hotkeys are unregistered

    def register_all(self):
        self._stop_thread()
        self._thread = _HotkeyThread(self._bindings, self._disabled_actions)
        self._thread.sig_hotkey.connect(self._dispatch)
        self._thread.start()

    def update_bindings(self, new_bindings: dict):
        self._bindings.update(new_bindings)
        self.register_all()

    def set_hotkey_enabled(self, action: str, enabled: bool):
        if enabled:
            if action not in self._disabled_actions:
                return  # already enabled
            self._disabled_actions.discard(action)
        else:
            self._disabled_actions.add(action)
        self.register_all()

    def unregister_all(self):
        self._stop_thread()

    def get_bindings(self) -> dict:
        return dict(self._bindings)

    def _stop_thread(self):
        if self._thread and self._thread.isRunning():
            self._thread.stop()
            self._thread.wait(1000)
        self._thread = None

    def _dispatch(self, action: str):
        mapping = {
            "start":   self.sig_start,
            "stop":    self.sig_stop,
            "show_ui": self.sig_show_ui,
            "pixel":   self.sig_pixel,
            "calibration": self.sig_calibration,
            "fat_calibration": self.sig_fat_calibration,
        }
        sig = mapping.get(action)
        if sig:
            sig.emit()
