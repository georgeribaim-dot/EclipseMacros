
import json
import copy
import os
from pathlib import Path
from typing import Any

DEFAULT_CONFIG: dict[str, Any] = {
    "CD_Skill1": 2000,
    "CD_Skill2": 4000,
    "CD_Skill3": 6000,
    "CD_Skill4": 8000,
    "CD_Skill5": 10000,

    "Key_Skill1": "2",
    "Key_Skill2": "3",
    "Key_Skill3": "4",
    "Key_Skill4": "r",
    "Key_Skill5": "t",
    "Key_Ult":    "1",
    "Key_Transfo": "y",

    "Food1Key": "6",
    "Food2Key": "7",
    "Food3Key": "",
    "Food4Key": "",
    "Food5Key": "",
    "Food6Key": "",

    "AttackKey":        "5",
    "AttackDelay":      80,
    "RightClickEvery":  5,
    "SkillClickDelay":  80,

    "HP_X":         100,
    "HP_Y":         950,
    "HP_Color":     "0x00FF00",
    "HP_Tolerance": 30,

    "ULT_X":         960,
    "ULT_Y":         980,
    "ULT_Color":     "0xFFD700",
    "ULT_Tolerance": 30,

    "FOOD_X":              200,
    "FOOD_Y":              970,
    "FOOD_Color":          "0xFF8C00",
    "FOOD_Tolerance":      30,
    "FOOD_IMG_X1":         0,
    "FOOD_IMG_Y1":         900,
    "FOOD_IMG_X2":         400,
    "FOOD_IMG_Y2":         1080,
    "FOOD_IMG_Variation":  20,
    "FOOD_CLICK_X":        960,
    "FOOD_CLICK_Y":        540,
    "FOOD_BLOCK_X":        "",
    "FOOD_BLOCK_Y":        "",
    "FOOD_BLOCK_Color":    "",
    "FOOD_BLOCK_Tolerance": 30,
    "FOOD_BLOCK2_X":       "",
    "FOOD_BLOCK2_Y":       "",
    "FOOD_BLOCK2_Color":   "",
    "FOOD_BLOCK2_Tolerance": 30,

    "BTN_START_X":             960,
    "BTN_START_Y":             600,
    "START_DETECT_X":          960,
    "START_DETECT_Y":          600,
    "START_DETECT_Color":      "0xFFFFFF",
    "START_DETECT_Tolerance":  30,
    "START_WAIT_Timeout":      30000,

    "BTN_QUIT_X": 960,
    "BTN_QUIT_Y": 500,

    "END_X":         960,
    "END_Y":         500,
    "END_Color":     "0xFF0000",
    "END_Tolerance": 30,

    "TransfoOnStart":    1,
    "TransfoStartDelay": 4000,
    "TransfoDuration":   6000,
    "UI_Delay":          800,
    "PostTrialDelay":    5000,
    "MouseJitterPx":     8,
    "FoodCheckInterval":  10000,
    "FOOD_CheckInterval": 500,
    "FOOD_KeyDuration":   100,
    # FAT Macro
    "FAT_ClickX":        960,
    "FAT_ClickY":        540,
    "FAT_Profile":       "Burger",
    "FAT_JEnabled":      1,
    # Burger
    "FAT_BG_FoodKey":        "e",
    "FAT_BG_RClickDuration": 500,
    "FAT_BG_LClickDuration": 1500,
    "FAT_BG_FastEating":     0,
    "FAT_BG_AltKey":         "r",
    "FAT_BG_AltDuration":    2000,
    # Sushi
    "FAT_SU_FoodKey":        "e",
    "FAT_SU_RClickDuration": 500,
    "FAT_SU_LClickDuration": 1500,
    # Protein Drain
    "FAT_PD_FoodKey":        "e",
    "FAT_PD_RClickDuration": 500,
    "FAT_PD_LClickDuration": 1500,
    "AbrawlMode":         0,
    "NoM2Mode":         0,

    "F10ToggleEnabled":  1,
    "KToggleEnabled":    1,

    "GameTitle": "",
    "GameWinW":  384,
    "GameWinH":  216,

    "SB_TrainingKey":      "e",
    "SB_FightingStyleKey": "r",
    "SB_SpinDuration":     31000,
    "SB_RClickInterval":   300,
    "SB_CycleDelay":       10000,

    "RW_KeyboardLayout":  "azerty",
    "RW_TrainingKey":     "e",
    "RW_StatMode":        "speed",

    "RW_ClickX":          960,
    "RW_ClickY":          540,
    "RW_SkinDetectX":     960,
    "RW_SkinDetectY":     540,
    "RW_SpeedX":          900,
    "RW_SpeedY":          400,
    "RW_StaminaX":        1020,
    "RW_StaminaY":        400,

    "RW_StepMs_0": 400,
    "RW_StepMs_1": 2100,
    "RW_StepMs_2": 6300,
    "RW_StepMs_3": 6500,
    "RW_StepMs_4": 3120,
    "RW_StepMs_5": 2460,
    "RW_StepMs_6": 1560,
    "RW_StepMs_7": 2310,
    "RW_StepMs_8": 1740,
    "RW_StepMs_9": 2100,
    "RW_StepMs_10": 950,
    "RW_StepMs_11": 270,
    "RW_StepMs_12": 1250,
    "RW_StepMs_13": 1360,
    "RW_StepMs_14": 840,
    "RW_StepMs_15": 2770,
    "RW_StepMs_16": 700,
    "RW_StepMs_17": 100,
    "RW_StepMs_18": 1420,
    "RW_StepMs_19": 1500,
    "RW_StepMs_20": 3000,
    "RW_StepMs_21": 500,
    "RW_StepMs_22": 583,
    "RW_StepMs_23": 0,
    "RW_StepMs_24": 0,

    "RW_SpeedAdjustment": 1.0,
    "RW_DoubleTapDelay":  120,
    "RW_ClickDetectColor": "",
    "RW_ClickDetectTolerance": 12,
    "RW_ClickDetectRadius": 40,
    "RW_SprintForwardMs": 2200,
    "RW_TurnAroundMs":    400,
    "RW_PauseBetween":    100,
    "RW_Laps":            0,
    "RW_CycleDelay":      2000,
}

DURABILITY_DEFAULTS: dict = {
    "DUR_GameTitle1": "Roblox",
    "DUR_Win1W":      384,
    "DUR_Win1H":      216,
    "DUR_GameTitle2": "Roblox",
    "DUR_Win2W":      384,
    "DUR_Win2H":      216,
    "DUR_WinGap":     20,

    "DUR1_ClickX":         200,
    "DUR1_ClickY":         108,
    "DUR1_TrainingKey":    "e",
    "DUR1_FoodClickX":     192,
    "DUR1_FoodClickY":     180,
    "DUR1_Food1Key":       "6",
    "DUR1_Food2Key":       "7",
    "DUR1_Food3Key":       "",
    "DUR1_Food4Key":       "",
    "DUR1_Food5Key":       "",
    "DUR1_Food6Key":       "",
    "DUR1_Food7Key":       "",
    "DUR1_HealthX":        100,
    "DUR1_HealthY":        190,
    "DUR1_HealthColor":    "0x00FF00",
    "DUR1_HealthTol":      30,
    "DUR1_DurX":           200,
    "DUR1_DurY":           150,
    "DUR1_DurColor":       "0xFF8800",
    "DUR1_DurTol":         30,
    "DUR1_StrengthX":      280,
    "DUR1_StrengthY":      108,
    "DUR1_StrengthKey":    "r",
    "DUR1_FightStyleKey":  "f",

    "DUR2_ClickX":         200,
    "DUR2_ClickY":         108,
    "DUR2_FoodClickX":     192,
    "DUR2_FoodClickY":     180,
    "DUR2_Food1Key":       "6",
    "DUR2_Food2Key":       "7",
    "DUR2_Food3Key":       "",
    "DUR2_Food4Key":       "",
    "DUR2_Food5Key":       "",
    "DUR2_Food6Key":       "",
    "DUR2_Food7Key":       "",
    "DUR2_StaminaX":       300,
    "DUR2_StaminaY":       108,
    "DUR2_StaminaColor":   "0x00BFFF",
    "DUR2_StaminaTol":     30,
    "DUR2_FightStyleKey":  "f",
    "DUR2_FoodX":          200,
    "DUR2_FoodY":          970,
    "DUR2_FoodColor":      "0xFF8C00",
    "DUR2_FoodTol":        30,

    "DUR_SurvivorMode":    0,

    "DUR_TrainingDuration": 18.0,

    "DUR_NoRClickEnabled":  0,
    "DUR_NoRClickDuration": 3.0,

    "DUR_PostTrainingDelay": 0.5,

    # Sub-mode selector
    "DUR_SubMode": "selfish_v1",
}

DEFAULT_CONFIG.update(DURABILITY_DEFAULTS)

# ── Selfish V3 defaults ──────────────────────────────────────────────────────
SV3_DEFAULTS: dict = {
    "SV3_W2_StrBuyX":        200,   # kept for old configs — no longer used in engine
    "SV3_W2_StrBuyY":        108,
    "SV3_W1_DurBuyX":        200,   # kept for old configs — no longer used in engine
    "SV3_W1_DurBuyY":        108,
    "SV3_W2_StrStatX":       280,
    "SV3_W2_StrStatY":       108,
    "SV3_W2_DurBuyX":        200,   # kept for old configs — no longer used in engine
    "SV3_W2_DurBuyY":        108,
    # Strength stat click positions (click AFTER equipping strength training)
    "SV3_W1_StrStatClickX":  280,   # WIN1 — where to click after equipping STR training
    "SV3_W1_StrStatClickY":  108,
    "SV3_W2_StrStatClickX":  280,   # WIN2 — where to click after equipping STR training (same as orange dot)
    "SV3_W2_StrStatClickY":  108,
    # Spam click positions (where the mouse sits during combat spam loops)
    "SV3_W1_SpamX":          500,   # WIN1 — coordonnée X du spam de clics
    "SV3_W1_SpamY":          400,   # WIN1 — coordonnée Y du spam de clics
    "SV3_W2_SpamX":          500,   # WIN2 — coordonnée X du spam de clics
    "SV3_W2_SpamY":          400,   # WIN2 — coordonnée Y du spam de clics
    # Strength click spam duration (ms) — spam répété pour que Roblox détecte
    "SV3_StrClickSpamMs":    700,   # durée du spam de clics pour lancer le training STR
    "SV3_W2_FightStyleKey":  "f",
    "SV3_W1_DurTrainingKey": "e",
    "SV3_W1_StrTrainingKey": "r",
    "SV3_W2_DurTrainingKey": "e",
    "SV3_W2_StrTrainingKey": "r",
    "SV3_StrSpamDuration":   18.0,
    "SV3_DurSpamDuration":   18.0,
    "SV3_CycleEndDelay":     1000,
    "SV3_PhaseTransitionDelay": 0,   # ms to wait after phase 1 spam ends (for slower training to finish)
    "SV3_W1_Health2X":       100,
    "SV3_W1_Health2Y":       190,
    "SV3_W1_Health2Color":   "0x00FF00",
    "SV3_W1_Health2Tol":     30,
    "SV3_W2_FoodX":          200,
    "SV3_W2_FoodY":          970,
    "SV3_W2_FoodColor":      "0xFF8C00",
    "SV3_W2_FoodTol":        30,
    "SV3_W2_FoodClickX":     192,
    "SV3_W2_FoodClickY":     180,
    "SV3_W2_Food1Key":       "6",
    "SV3_W2_Food2Key":       "7",
    "SV3_W2_Food3Key":       "",
    "SV3_W2_Food4Key":       "",
    "SV3_W2_Food5Key":       "",
    "SV3_W2_Food6Key":       "",
    "SV3_W2_Food7Key":       "",
    "SV3_W2_FoodBlock1X":    "",
    "SV3_W2_FoodBlock1Y":    "",
    "SV3_W2_FoodBlock1Color":"",
    "SV3_W2_FoodBlock1Tol":  30,
    "SV3_W2_FoodBlock2X":    "",
    "SV3_W2_FoodBlock2Y":    "",
    "SV3_W2_FoodBlock2Color":"",
    "SV3_W2_FoodBlock2Tol":  30,
    # WIN2 health pixel detection (during phase 2 — WIN1 spams, WIN2 trains durability)
    "SV3_W2_HealthX":        100,
    "SV3_W2_HealthY":        190,
    "SV3_W2_HealthColor":    "0x00FF00",
    "SV3_W2_HealthTol":      30,
    # WIN2 stamina pixel detection (phase 1 — WIN2 spams, if WIN2 stamina gone → stop spam)
    "SV3_W2_StaminaX":       100,
    "SV3_W2_StaminaY":       200,
    "SV3_W2_StaminaColor":   "0x00BFFF",
    "SV3_W2_StaminaTol":     30,
    # WIN1 stamina pixel detection (phase 2 — WIN1 spams, if WIN1 stamina gone → stop spam)
    "SV3_W1_Stamina2X":      100,
    "SV3_W1_Stamina2Y":      200,
    "SV3_W1_Stamina2Color":  "0x00BFFF",
    "SV3_W1_Stamina2Tol":    30,
    # Slow M1s mode (replaces fast spam with STR-style L/R click pattern)
    "SV3_W1_SlowM1s":        0,
    "SV3_W2_SlowM1s":        0,
    "SV3_SlowM1sClickMs":    1154,   # intervalle entre L-clicks en mode Slow M1s (ms)
    "SV3_SlowM1sRClickWaitMs": 1000, # attente avant R-click en mode Slow M1s (ms)
    "SV3_SlowM1sRClickToLMs":  300,  # attente après R-click avant prochain L-click (ms)
}

DEFAULT_CONFIG.update(SV3_DEFAULTS)

STRENGTH_DEFAULTS: dict = {
    "STR_StrengthX":       280,
    "STR_StrengthY":       108,
    "STR_StrengthKey":     "r",
    "STR_FightStyleKey":   "f",

    "STR_FoodClickX":      192,
    "STR_FoodClickY":      180,
    "STR_Food1Key":        "6",
    "STR_Food2Key":        "7",
    "STR_Food3Key":        "",
    "STR_Food4Key":        "",
    "STR_Food5Key":        "",
    "STR_Food6Key":        "",
    "STR_Food7Key":        "",
    "STR_FoodX":           200,
    "STR_FoodY":           970,
    "STR_FoodColor":       "0xFF8C00",
    "STR_FoodTol":         30,

    "STR_TrainingDuration":      30.0,   # durée du spam (secondes)
    "STR_LClickInterval":        1154,   # ms entre chaque clic gauche
    "STR_RClickWait":            1000,   # ms d'attente avant le clic droit
    "STR_RClickToLClickDelay":   300,    # ms entre le clic droit et le clic gauche suivant
    "STR_ClicksPerSeries":       5,      # nb de clics gauche par série

    "STR_StaminaX":        0,
    "STR_StaminaY":        0,
    "STR_StaminaColor":    "",
    "STR_StaminaTol":      30,
    "STR_PixelGoneDelay":  0.7,
}

DEFAULT_CONFIG.update(STRENGTH_DEFAULTS)

SECTIONS = [
    ("Cooldowns", [
        ("Skill 1 (ms)",  "CD_Skill1"),
        ("Skill 2 (ms)",  "CD_Skill2"),
        ("Skill 3 (ms)",  "CD_Skill3"),
        ("Skill 4 (ms)",  "CD_Skill4"),
        ("Skill 5 (ms)",  "CD_Skill5"),
    ]),
    ("Skill Keys", [
        ("Skill 1 (empty=off)",   "Key_Skill1"),
        ("Skill 2 (empty=off)",   "Key_Skill2"),
        ("Skill 3 (empty=off)",   "Key_Skill3"),
        ("Skill 4 (empty=off)",   "Key_Skill4"),
        ("Skill 5 (empty=off)",   "Key_Skill5"),
        ("Ultimate (empty=off)",  "Key_Ult"),
        ("Transform Key",     "Key_Transfo"),
    ]),
    ("Attack & Timings", [
        ("Attack Key",       "AttackKey"),
        ("Attack Delay (ms)",   "AttackDelay"),
        ("Right Click every N","RightClickEvery"),
        ("Skill→Click Delay",    "SkillClickDelay"),
    ]),
    ("Misc", [
        ("Transform Start Delay (ms)", "TransfoStartDelay"),
        ("Transform Duration (ms)",        "TransfoDuration"),
        ("UI Delay (ms)",               "UI_Delay"),
        ("Post-Trial Delay (ms)",       "PostTrialDelay"),
        ("Mouse Jitter (px)",          "MouseJitterPx"),
    ]),
]

CUSTOMIZATION_SECTIONS = [
    ("Food — Click Coords", [
        ("Click X (after key)", "FOOD_CLICK_X"),
        ("Click Y (after key)", "FOOD_CLICK_Y"),
    ]),
    ("Ultimate Bar", [
        ("Pixel X",    "ULT_X"),
        ("Pixel Y",    "ULT_Y"),
        ("Color",    "ULT_Color"),
        ("Tolerance",  "ULT_Tolerance"),
    ]),
    ("Food (pixel)", [
        ("Pixel X",           "FOOD_X"),
        ("Pixel Y",           "FOOD_Y"),
        ("Color",           "FOOD_Color"),
        ("Tolerance",         "FOOD_Tolerance"),
        ("Image Zone X1",     "FOOD_IMG_X1"),
        ("Image Zone Y1",     "FOOD_IMG_Y1"),
        ("Image Zone X2",     "FOOD_IMG_X2"),
        ("Image Zone Y2",     "FOOD_IMG_Y2"),
        ("Color Variation", "FOOD_IMG_Variation"),
    ]),
    ("Food — Block Pixel 1", [
        ("Block Pixel X",   "FOOD_BLOCK_X"),
        ("Block Pixel Y",   "FOOD_BLOCK_Y"),
        ("Block Color",     "FOOD_BLOCK_Color"),
        ("Block Tolerance", "FOOD_BLOCK_Tolerance"),
    ]),
    ("Food — Block Pixel 2", [
        ("Block Pixel X",   "FOOD_BLOCK2_X"),
        ("Block Pixel Y",   "FOOD_BLOCK2_Y"),
        ("Block Color",     "FOOD_BLOCK2_Color"),
        ("Block Tolerance", "FOOD_BLOCK2_Tolerance"),
    ]),
    ("Start Button", [
        ("Click X",               "BTN_START_X"),
        ("Click Y",               "BTN_START_Y"),
        ("Detect X",              "START_DETECT_X"),
        ("Detect Y",              "START_DETECT_Y"),
        ("Detection Color",     "START_DETECT_Color"),
        ("Tolerance",             "START_DETECT_Tolerance"),
        ("Wait Timeout (ms)",  "START_WAIT_Timeout"),
    ]),
    ("Quit Button", [
        ("Click X", "BTN_QUIT_X"),
        ("Click Y", "BTN_QUIT_Y"),
    ]),
    ("Game Window", [
        ("Window Title", "GameTitle"),
        ("Target Width", "GameWinW"),
        ("Target Height", "GameWinH"),
    ]),
    ("End Trial Detection", [
        ("Pixel X",   "END_X"),
        ("Pixel Y",   "END_Y"),
        ("Color",   "END_Color"),
        ("Tolerance", "END_Tolerance"),
    ]),
]

class ConfigManager:

    CONFIG_DIR  = Path(os.getenv("APPDATA", ".")) / "EclipseMacros"
    ACTIVE_FILE = CONFIG_DIR / "_active_profile.txt"

    @staticmethod
    def _get_root() -> Path:
        """Racine du projet (dossier contenant main.py / assets/)."""
        import sys
        # Mode PyInstaller compilé
        if hasattr(sys, "_MEIPASS"):
            return Path(sys._MEIPASS)
        # Mode script : on remonte depuis core/config_manager.py → racine
        return Path(__file__).resolve().parent.parent

    @classmethod
    def _configs_dir(cls) -> Path:
        import sys
        # En mode compilé PyInstaller, _MEIPASS est read-only → sauvegarder dans AppData
        if hasattr(sys, "_MEIPASS"):
            d = cls.CONFIG_DIR / "configs"
            d.mkdir(parents=True, exist_ok=True)
            # Copie le Default.json embarqué si AppData n'en a pas encore
            bundled = Path(sys._MEIPASS) / "assets" / "configs" / "Default.json"
            dest = d / "Default.json"
            if bundled.exists() and not dest.exists():
                import shutil
                shutil.copy2(bundled, dest)
            return d
        # Mode script : assets/configs/ local
        return cls._get_root() / "assets" / "configs"

    def __init__(self):
        self.CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        self._current_profile = "Default"
        self._data: dict = {}
        # Restaure le dernier profil actif (évite la réinitialisation aux defaults au relancement)
        last_profile = self._load_active_profile_name()
        self.load_profile(last_profile)

    def _profile_path(self, name: str) -> Path:
        safe = "".join(c for c in name if c.isalnum() or c in "_ -")
        return self._configs_dir() / f"{safe}.json"

    def _load_active_profile_name(self) -> str:
        try:
            return self.ACTIVE_FILE.read_text().strip() or "Default"
        except Exception:
            return "Default"

    def _save_active_profile_name(self):
        try:
            self.ACTIVE_FILE.write_text(self._current_profile)
        except Exception:
            pass

    def load_profile(self, name: str):
        self._current_profile = name
        path = self._profile_path(name)
        if path.exists():
            try:
                loaded = json.loads(path.read_text(encoding="utf-8"))
                self._data = {**copy.deepcopy(DEFAULT_CONFIG), **loaded}
                self._save_active_profile_name()
                return
            except Exception:
                pass
        self._data = copy.deepcopy(DEFAULT_CONFIG)
        self._save_active_profile_name()

    def save_profile(self, name: str | None = None):
        if name:
            self._current_profile = name
        path = self._profile_path(self._current_profile)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(
            json.dumps(self._data, indent=2, ensure_ascii=False),
            encoding="utf-8")
        self._save_active_profile_name()

    def delete_profile(self, name: str):
        path = self._profile_path(name)
        if path.exists():
            path.unlink()
        if self._current_profile == name:
            self.load_profile("Default")

    def list_profiles(self) -> list[str]:
        d = self._configs_dir()
        if d.exists():
            profiles = [p.stem for p in d.glob("*.json")]
            return sorted(profiles) if profiles else ["Default"]
        return ["Default"]

    def clone_profile(self, src: str, dst: str):
        self.load_profile(src)
        old_data = copy.deepcopy(self._data)
        self._current_profile = dst
        self._data = old_data
        self.save_profile()

    def rename_profile(self, old: str, new: str):
        self.clone_profile(old, new)
        self.delete_profile(old)

    @property
    def current_profile(self) -> str:
        return self._current_profile

    def get(self, key: str, fallback=None):
        return self._data.get(key, fallback)

    def set(self, key: str, value):
        self._data[key] = value

    def update(self, d: dict):
        self._data.update(d)

    def as_dict(self) -> dict:
        return copy.deepcopy(self._data)

    def reset_to_defaults(self):
        self._data = copy.deepcopy(DEFAULT_CONFIG)

    def get_int(self, key: str) -> int:
        try:
            return int(self._data.get(key, DEFAULT_CONFIG.get(key, 0)))
        except (ValueError, TypeError):
            return 0

    def get_str(self, key: str) -> str:
        return str(self._data.get(key, DEFAULT_CONFIG.get(key, "")))

    def get_bool(self, key: str) -> bool:
        v = self._data.get(key, DEFAULT_CONFIG.get(key, 0))
        return bool(int(v)) if not isinstance(v, bool) else v
