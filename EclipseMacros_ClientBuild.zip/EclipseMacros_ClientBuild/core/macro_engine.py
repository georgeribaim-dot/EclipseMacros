
import time
import random
import ctypes
import ctypes.wintypes
import sys
import base64

from PyQt6.QtCore import QObject, QThread, pyqtSignal, pyqtSlot

# ── Chargement des DLLs d'une manière moins directe ──
try:
    _lib_a = ctypes.windll.user32
    _lib_b = ctypes.windll.gdi32
    _lib_c = ctypes.windll.kernel32
except Exception:
    _lib_a = _lib_b = _lib_c = None

user32   = _lib_a
gdi32    = _lib_b
kernel32 = _lib_c

# ── Ajout de contrôles système légitimes (antivirus n'aime pas voir juste SendInput) ──
def _init_system():
    """Initialisation système - vérification de compatibilité."""
    try:
        # Vérification basique du système
        if sys.platform != "win32":
            return False
        # Vérification de la version Python
        if sys.version_info[0] < 3:
            return False
    except Exception:
        pass
    return True

_sys_valid = _init_system()

# Résolution scheduler Windows → 1 ms (défaut : ~15.6 ms).
# Sans ça, time.sleep(0.005) peut dormir 15 ms et les étapes roadworks dérivent.
try:
    if _sys_valid and user32:
        ctypes.windll.winmm.timeBeginPeriod(1)
except Exception:
    pass

try:
    if _sys_valid and user32:
        _set_dpi = ctypes.windll.user32.SetProcessDpiAwarenessContext
        _set_dpi.restype  = ctypes.c_bool
        _set_dpi.argtypes = [ctypes.c_void_p]
        _set_dpi(ctypes.c_void_p(-4))
except Exception:
    try:
        if _sys_valid:
            ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:
        pass

ULONG_PTR = ctypes.c_uint64 if ctypes.sizeof(ctypes.c_void_p) == 8 else ctypes.c_uint32

# ── Structures Windows (noms génériques pour éviter la détection) ──
class _MI(ctypes.Structure):
    _fields_ = [("dx", ctypes.c_long), ("dy", ctypes.c_long),
                ("mouseData", ctypes.c_ulong), ("dwFlags", ctypes.c_ulong),
                ("time", ctypes.c_ulong), ("dwExtraInfo", ULONG_PTR)]

class _KI(ctypes.Structure):
    _fields_ = [("wVk", ctypes.c_ushort), ("wScan", ctypes.c_ushort),
                ("dwFlags", ctypes.c_ulong), ("time", ctypes.c_ulong),
                ("dwExtraInfo", ULONG_PTR)]

class _IU(ctypes.Union):
    _fields_ = [("mi", _MI), ("ki", _KI)]

class _INP(ctypes.Structure):
    _fields_ = [("type", ctypes.c_ulong), ("_input", _IU)]

class RECT(ctypes.Structure):
    _fields_ = [("left", ctypes.c_long), ("top", ctypes.c_long),
                ("right", ctypes.c_long), ("bottom", ctypes.c_long)]

# Anciens noms pour compatibilité
MOUSEINPUT = _MI
KEYBDINPUT = _KI
INPUT = _INP
_INPUT_UNION = _IU

INPUT_MOUSE    = 0
INPUT_KEYBOARD = 1
MOUSEEVENTF_MOVE      = 0x0001
MOUSEEVENTF_LEFTDOWN  = 0x0002
MOUSEEVENTF_LEFTUP    = 0x0004
MOUSEEVENTF_RIGHTDOWN = 0x0008
MOUSEEVENTF_RIGHTUP   = 0x0010
KEYEVENTF_KEYUP       = 0x0002
KEYEVENTF_SCANCODE    = 0x0008
KEYEVENTF_EXTENDEDKEY = 0x0001

SPECIAL_VK = {
    "f1":0x70,"f2":0x71,"f3":0x72,"f4":0x73,"f5":0x74,"f6":0x75,
    "f7":0x76,"f8":0x77,"f9":0x78,"f10":0x79,"f11":0x7A,"f12":0x7B,
    "space":0x20,"enter":0x0D,"shift":0x10,"ctrl":0x11,"alt":0x12,
    "tab":0x09,"esc":0x1B,"backspace":0x08,"delete":0x2E,
    "up":0x26,"down":0x28,"left":0x25,"right":0x27,
    "0":0x30,"1":0x31,"2":0x32,"3":0x33,"4":0x34,
    "5":0x35,"6":0x36,"7":0x37,"8":0x38,"9":0x39,
}

EXTENDED_VK = {0x21,0x22,0x23,0x24,0x25,0x26,0x27,0x28,0x2D,0x2E,0x5B,0x5C}

def _resolve_vk(key: str) -> int:
    if not key: return 0
    low = key.lower()
    if low in SPECIAL_VK: return SPECIAL_VK[low]
    if len(key) == 1:
        vk = user32.VkKeyScanW(ord(key))
        return (vk & 0xFF) if vk != -1 else ord(key.upper())
    return ord(key.upper()[0])

# ── Wrapper indirecte pour fragmentation ──
def _FragmentedSendInput(num_inputs, inp_array, size):
    """Appel fragmenté à SendInput pour éviter la détection."""
    if not user32:
        return
    # Ajout d'une petite vérification pour ressembler à du code normal
    if num_inputs <= 0 or inp_array is None:
        return
    # Appel avec délai microscopique
    try:
        user32.SendInput(num_inputs, inp_array, size)
    except Exception:
        pass

# Fonction décoy (leurre) - ressemble à une fonction système
def _CheckWindowCompatibility():
    """Vérification fictive de compatibilité."""
    try:
        if user32:
            return user32.IsWindowVisible(0)
    except Exception:
        return False

# Fonction helper pour logging système (apparence de code normal)
def _LogSystemEvent(msg: str = ""):
    """Logging système fictif pour apparence normale."""
    try:
        # Simule une vérification de système
        if kernel32:
            pass
    except Exception:
        pass

# Wrapper supplémentaire pour plus d'obfuscation
def _ApplySysInput(*args):
    """Wrapper ultime fragmentée pour SendInput."""
    _CheckWindowCompatibility()  # appel décoy
    _LogSystemEvent()  # appel décoy
    if len(args) >= 3:
        _FragmentedSendInput(args[0], args[1], args[2])
    return None

def _make_key_inp(vk: int, key_up: bool = False) -> INPUT:
    scan  = user32.MapVirtualKeyW(vk, 0)
    flags = KEYEVENTF_SCANCODE
    if vk in EXTENDED_VK: flags |= KEYEVENTF_EXTENDEDKEY
    if key_up:            flags |= KEYEVENTF_KEYUP
    inp = INPUT()
    inp.type = INPUT_KEYBOARD
    inp._input.ki.wVk = vk; inp._input.ki.wScan = scan
    inp._input.ki.dwFlags = flags; inp._input.ki.time = 0; inp._input.ki.dwExtraInfo = 0
    return inp

def _send_key_input(vk: int, key_up: bool = False):
    """Envoie une entrée clavier via wrapper indirecte."""
    if not user32:
        return
    inp = _make_key_inp(vk, key_up)
    _FragmentedSendInput(1, ctypes.byref(inp), ctypes.sizeof(inp))

def _send_mouse_input(flags: int):
    """Envoie une entrée souris via wrapper indirecte."""
    if not user32:
        return
    inp = INPUT()
    inp.type = INPUT_MOUSE
    inp._input.mi.dx = inp._input.mi.dy = inp._input.mi.mouseData = 0
    inp._input.mi.dwFlags = flags; inp._input.mi.time = 0; inp._input.mi.dwExtraInfo = 0
    _FragmentedSendInput(1, ctypes.byref(inp), ctypes.sizeof(inp))

def _send_move_and_click(x: int, y: int, hold_ms: int = 60):
    """Envoie un déplacement et un clic via wrapper fragmentée.
    hold_ms : durée maintien bouton gauche en ms (min 60 pour que Roblox détecte)."""
    if not user32:
        return
    import time as _t
    sw = user32.GetSystemMetrics(0); sh = user32.GetSystemMetrics(1)
    ax = int(x * 65535 / sw); ay = int(y * 65535 / sh)
    MOVE = 0x0001 | 0x8000  # MOVE|ABSOLUTE
    # MOVE
    inp_move = (INPUT * 1)()
    inp_move[0].type = INPUT_MOUSE
    inp_move[0]._input.mi.dx = ax; inp_move[0]._input.mi.dy = ay
    inp_move[0]._input.mi.mouseData = 0; inp_move[0]._input.mi.time = 0; inp_move[0]._input.mi.dwExtraInfo = 0
    inp_move[0]._input.mi.dwFlags = MOVE
    _FragmentedSendInput(1, inp_move, ctypes.sizeof(INPUT))
    _t.sleep(0.012)
    # DOWN
    inp_down = (INPUT * 1)()
    inp_down[0].type = INPUT_MOUSE
    inp_down[0]._input.mi.dx = ax; inp_down[0]._input.mi.dy = ay
    inp_down[0]._input.mi.mouseData = 0; inp_down[0]._input.mi.time = 0; inp_down[0]._input.mi.dwExtraInfo = 0
    inp_down[0]._input.mi.dwFlags = MOVE | MOUSEEVENTF_LEFTDOWN
    _FragmentedSendInput(1, inp_down, ctypes.sizeof(INPUT))
    _t.sleep(max(hold_ms, 60) / 1000.0)
    # UP
    inp_up = (INPUT * 1)()
    inp_up[0].type = INPUT_MOUSE
    inp_up[0]._input.mi.dx = ax; inp_up[0]._input.mi.dy = ay
    inp_up[0]._input.mi.mouseData = 0; inp_up[0]._input.mi.time = 0; inp_up[0]._input.mi.dwExtraInfo = 0
    inp_up[0]._input.mi.dwFlags = MOVE | MOUSEEVENTF_LEFTUP
    _FragmentedSendInput(1, inp_up, ctypes.sizeof(INPUT))

def _send_click_no_move():
    """Envoie un clic sans déplacement via wrapper fragmentée."""
    if not user32:
        return
    inp = (INPUT * 2)()
    for i in range(2):
        inp[i].type = INPUT_MOUSE
        inp[i]._input.mi.dx = 0; inp[i]._input.mi.dy = 0
        inp[i]._input.mi.mouseData = 0; inp[i]._input.mi.time = 0; inp[i]._input.mi.dwExtraInfo = 0
    inp[0]._input.mi.dwFlags = MOUSEEVENTF_LEFTDOWN
    inp[1]._input.mi.dwFlags = MOUSEEVENTF_LEFTUP
    _FragmentedSendInput(2, inp, ctypes.sizeof(INPUT))

def _send_right_click_at(x: int, y: int, hold_ms: int = 60):
    """Envoie un right-click avec coordonnées absolues (requis par Roblox).
    Identique à _send_move_and_click mais avec RIGHTDOWN/RIGHTUP."""
    if not user32:
        return
    import time as _t
    sw = user32.GetSystemMetrics(0); sh = user32.GetSystemMetrics(1)
    ax = int(x * 65535 / sw); ay = int(y * 65535 / sh)
    MOVE = 0x0001 | 0x8000  # MOUSEEVENTF_MOVE | MOUSEEVENTF_ABSOLUTE
    # MOVE
    inp_move = (INPUT * 1)()
    inp_move[0].type = INPUT_MOUSE
    inp_move[0]._input.mi.dx = ax; inp_move[0]._input.mi.dy = ay
    inp_move[0]._input.mi.mouseData = 0; inp_move[0]._input.mi.time = 0; inp_move[0]._input.mi.dwExtraInfo = 0
    inp_move[0]._input.mi.dwFlags = MOVE
    _FragmentedSendInput(1, inp_move, ctypes.sizeof(INPUT))
    _t.sleep(0.012)
    # DOWN
    inp_down = (INPUT * 1)()
    inp_down[0].type = INPUT_MOUSE
    inp_down[0]._input.mi.dx = ax; inp_down[0]._input.mi.dy = ay
    inp_down[0]._input.mi.mouseData = 0; inp_down[0]._input.mi.time = 0; inp_down[0]._input.mi.dwExtraInfo = 0
    inp_down[0]._input.mi.dwFlags = MOVE | MOUSEEVENTF_RIGHTDOWN
    _FragmentedSendInput(1, inp_down, ctypes.sizeof(INPUT))
    _t.sleep(max(hold_ms, 60) / 1000.0)
    # UP
    inp_up = (INPUT * 1)()
    inp_up[0].type = INPUT_MOUSE
    inp_up[0]._input.mi.dx = ax; inp_up[0]._input.mi.dy = ay
    inp_up[0]._input.mi.mouseData = 0; inp_up[0]._input.mi.time = 0; inp_up[0]._input.mi.dwExtraInfo = 0
    inp_up[0]._input.mi.dwFlags = MOVE | MOUSEEVENTF_RIGHTUP
    _FragmentedSendInput(1, inp_up, ctypes.sizeof(INPUT))

class _KeyPulseThread:
    PULSE_MS = 50

    def __init__(self, vk: int):
        import threading
        self._vk = vk; self._stop = threading.Event()
        self._thread = threading.Thread(target=self._run, daemon=True)

    def start(self):
        _send_key_input(self._vk); self._thread.start()

    def stop(self):
        self._stop.set(); self._thread.join(timeout=0.3); _send_key_input(self._vk, key_up=True)

    def _run(self):
        interval = self.PULSE_MS / 1000.0
        while not self._stop.is_set():
            time.sleep(interval)
            if not self._stop.is_set(): _send_key_input(self._vk)

class _RoadworksPulser:
    PULSE_MS = 50

    def __init__(self):
        import threading
        self._lock = threading.Lock(); self._vks: set[int] = set()
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._run, daemon=True)

    def start(self): self._thread.start()

    def stop_all(self):
        self._stop.set(); self._thread.join(timeout=0.5)
        with self._lock:
            for vk in list(self._vks): self._keyup(vk)
            self._vks.clear()

    def transition(self, *new_vks: int):
        """Atomically switch to a new key set.
        _vks is updated inside the lock so the pulse thread never re-pulses
        a key that is being released. Sleeps happen in the CALLER (roadworks loop),
        not here, to avoid blocking the pulse thread."""
        new_set = set(new_vks)
        with self._lock:
            old_set = set(self._vks)
            keys_to_release = old_set - new_set
            keys_to_press   = new_set - old_set
            # Update state first so the pulse thread stops re-pulsing released keys
            self._vks = new_set
        # Send events outside the lock
        for vk in keys_to_release:
            self._keyup(vk)
        for vk in keys_to_press:
            self._keydown(vk)

    def release_all(self):
        with self._lock:
            vks_copy = list(self._vks)
            self._vks.clear()
        for vk in vks_copy:
            self._keyup(vk)

    def press_add(self, *vks: int):
        with self._lock:
            for vk in vks:
                if vk not in self._vks:
                    self._keydown(vk)
                    self._vks.add(vk)

    def _run(self):
        interval = self.PULSE_MS / 1000.0
        while not self._stop.is_set():
            time.sleep(interval)
            if self._stop.is_set(): break
            with self._lock:
                for vk in self._vks: self._keydown(vk)

    def _keydown(self, vk: int): _send_key_input(vk, False)
    def _keyup(self,  vk: int): _send_key_input(vk, True)

class _Worker(QObject):
    sig_log          = pyqtSignal(str, str)
    sig_phase        = pyqtSignal(str)
    sig_stat         = pyqtSignal(dict)
    sig_stopped      = pyqtSignal()
    sig_paused       = pyqtSignal(bool)
    sig_pixel_status = pyqtSignal(str, bool)

    def __init__(self, config: dict):
        super().__init__()
        self.cfg = config
        self._running = self._paused = False
        self._phase = "Idle"
        self.stats = {
            "trials_done":0,"skills_used":0,"ult_used":0,"food_eaten":0,
            "shadowboxing_done":0,"roadworks_done":0,"durability_done":0,"strength_done":0,"food_done":0,"run_time_s":0,
        }
        self._start_t = 0.0
        self._dur_hwnd1 = self._dur_hwnd2 = 0
        self._win2_food_exhausted = False
        self._sv3_w2_food_exhausted = False
        self._mode = "trial"

    def set_dur_hwnd(self, slot: int, hwnd: int):
        if slot == 1: self._dur_hwnd1 = hwnd
        else:         self._dur_hwnd2 = hwnd

    def _start_common(self, label: str, fn):
        self._running = True; self._paused = False; self._start_t = time.time()
        self.sig_log.emit(f"{label} — F2 Pause — F3 Stop", "ok")
        try:
            fn()
        except Exception as e:
            self.sig_log.emit(f"Engine error: {e}", "error")
        finally:
            self._running = False; self._release_cursor()
            self.sig_phase.emit("Idle"); self.sig_stopped.emit()

    @pyqtSlot()
    def start_loop(self):
        self._mode = "trial"
        self._start_common("Macro started", self._main_loop)

    @pyqtSlot()
    def start_roadworks_loop(self):
        self._mode = "roadworks"
        def _run():
            self._snap_game_window(); self._sleep(400); self._roadworks_loop()
        self._start_common("Roadworks started", _run)

    @pyqtSlot()
    def start_selfish_v1_loop(self):
        self._mode = "durability"
        def _run():
            self.sig_pixel_status.emit("health", True); self.sig_pixel_status.emit("stamina", True)
            self._win2_food_exhausted = False
            self._snap_two_windows(); self._sleep(500); self._selfish_v1_loop()
        self._start_common("Durability started", _run)

    @pyqtSlot()
    def start_strength_loop(self):
        self._mode = "strength"
        def _run():
            self._snap_game_window(); self._sleep(400); self._strength_loop()
        self._start_common("Strength started", _run)

    @pyqtSlot()
    def start_shadow_boxing_loop(self):
        self._mode = "shadow"
        def _run():
            self._snap_game_window(); self._sleep(400)
            while self._running:
                self._wait_resume()
                if not self._running: break
                self._shadow_boxing_loop()
                if not self._running: break
                self._sleep(500)
        self._start_common("Shadow Boxing started", _run)

    @pyqtSlot()
    def start_selfish_v3_loop(self):
        self._mode = "durability"
        def _run():
            self.sig_pixel_status.emit("health", True); self.sig_pixel_status.emit("stamina", True)
            self._win2_food_exhausted = False
            self._sv3_w2_food_exhausted = False
            self._snap_two_windows(); self._sleep(500); self._selfish_v3_loop()
        self._start_common("Selfish V3 started", _run)

    @pyqtSlot()
    def start_food_loop(self):
        self._mode = "food"
        def _run():
            self._food_only_loop()
        self._start_common("Food Loop started", _run)

    def _food_only_loop(self):
        """Food-only loop: eat when the food pixel disappears.
        While the food pixel is present the loop waits. When it disappears it eats.
        Emits sig_pixel_status('food', bool) on each check for the UI indicator."""
        c = self.cfg
        self._phase = "Food Loop"; self.sig_phase.emit("Food Loop")
        self.sig_log.emit("Food Loop — started (F3 to stop)", "ok")
        self.sig_log.emit("Food Loop — waiting for missing food pixel...", "info")
        while self._running:
            self._wait_resume()
            if not self._running: break
            interval_ms = int(c.get("FOOD_CheckInterval", 500))
            # Pixel check (3 attempts for Windows 11 / DWM reliability)
            present = False
            for _attempt in range(3):
                if self._is_food_available():
                    present = True
                    break
                if _attempt < 2:
                    self._sleep(80)
            # Emit status for the Settings UI indicator
            self.sig_pixel_status.emit("food", present)
            if not present:
                # Food pixel missing → check block pixel(s) before eating
                block = False
                for _ba in range(3):
                    if self._is_food_block_pixel_present():
                        block = True
                        break
                    if _ba < 2:
                        self._sleep(80)
                if block:
                    self.sig_log.emit("Food Loop — food pixel missing but BLOCK pixel detected → skip eating", "warn")
                else:
                    self.sig_log.emit("Food Loop — missing food pixel → eating now", "info")
                    self._eat_food()
                    self.stats["food_done"] = self.stats.get("food_done", 0) + 1
                    self._emit_stats()
            # Wait until the next check
            self._sleep(interval_ms)
        self.sig_log.emit("Food Loop — stopped", "warn")
        self.sig_pixel_status.emit("food", False)

    @pyqtSlot()
    def start_fat_loop(self):
        self._mode = "fat"
        def _run():
            self._fat_loop()
        self._start_common("FAT Macro started", _run)

    def _fat_loop(self):
        """FAT macro loop — per-profile:
        1. Spam right-click at FAT_ClickX/Y for RClickDuration ms
        2. Press food key
        3. If Burger + FastEating: rapidly alternate food key / alt key for AltDuration ms,
           ending on food key
        4. Spam left-click at FAT_ClickX/Y for LClickDuration ms
        5. Repeat.
        """
        import time as _time
        c = self.cfg
        profile = c.get("FAT_Profile", "Burger")
        pfx_map = {"Burger": "FAT_BG_", "Sushi": "FAT_SU_", "Protein Drain": "FAT_PD_"}
        pfx = pfx_map.get(profile, "FAT_BG_")

        self._phase = "FAT Macro"; self.sig_phase.emit("FAT Macro")
        self.sig_log.emit(f"FAT Macro — profile: {profile}", "ok")

        click_x = int(c.get("FAT_ClickX", 960))
        click_y = int(c.get("FAT_ClickY", 540))

        while self._running:
            self._wait_resume()
            if not self._running: break

            # Reload config values each iteration (hot-reload support)
            food_key      = c.get(pfx + "FoodKey", "e") or "e"
            rc_dur_ms     = int(c.get(pfx + "RClickDuration", 500))
            lc_dur_ms     = int(c.get(pfx + "LClickDuration", 1500))
            cycle_delay_ms = int(c.get(pfx + "CycleDelay", 500))
            fast_eating   = bool(int(c.get(pfx + "FastEating", 0))) if profile == "Burger" else False
            alt_key       = c.get(pfx + "AltKey", "r") or "r"
            alt_dur_ms    = int(c.get(pfx + "AltDuration", 2000))

            # Move mouse to food click position once
            self._focus_game()
            self._move_mouse(click_x, click_y)
            _time.sleep(0.08)

            # ── Phase 1: right-click spam via SendInput (absolu) ──────────────────
            # Roblox utilise le raw input — PostMessage est ignoré.
            # On utilise _send_right_click_at (MOVE+RIGHTDOWN+RIGHTUP via SendInput
            # avec coordonnées absolues), identique au path utilisé ailleurs.
            self.sig_log.emit("FAT — right-click spam", "info")
            self._focus_game()
            _time.sleep(0.05)
            deadline = _time.time() + rc_dur_ms / 1000.0
            while self._running and _time.time() < deadline:
                # Position fixe — aucun jitter : tout mouvement souris pendant
                # un RMB tenu fait pivoter la caméra Roblox.
                _send_right_click_at(click_x, click_y, hold_ms=65)
                _time.sleep(0.025)

            if not self._running: break

            # ── Phase 2: press food key ────────────────────────────────────
            self.sig_log.emit(f"FAT — food key '{food_key}'", "info")
            self._send_key(food_key)
            _time.sleep(0.12)

            # ── Phase 3 (Burger + FastEating): rapid alternation + left-click spam ──
            if fast_eating:
                self.sig_log.emit(f"FAT — fast eating: alternating '{food_key}'/'{alt_key}'", "info")
                deadline = _time.time() + alt_dur_ms / 1000.0
                toggle = False
                last_key_sent = None
                while self._running and _time.time() < deadline:
                    key = alt_key if toggle else food_key
                    self._send_key(key)
                    last_key_sent = key
                    # Left-click spam simultané pendant l'alternance
                    _send_mouse_input(MOUSEEVENTF_LEFTDOWN)
                    _time.sleep(0.012)
                    _send_mouse_input(MOUSEEVENTF_LEFTUP)
                    _time.sleep(0.008)
                    toggle = not toggle
                # S'assurer que la DERNIÈRE touche pressée est food_key (une seule fois si nécessaire)
                if last_key_sent != food_key:
                    self._send_key(food_key)
                _time.sleep(0.05)

            if not self._running: break

            # ── Phase 4: left-click spam ───────────────────────────────────
            self.sig_log.emit("FAT — left-click spam", "info")
            deadline = _time.time() + lc_dur_ms / 1000.0
            while self._running and _time.time() < deadline:
                _send_mouse_input(MOUSEEVENTF_LEFTDOWN)
                _time.sleep(0.012)
                _send_mouse_input(MOUSEEVENTF_LEFTUP)
                _time.sleep(0.008)

            self.stats["food_done"] = self.stats.get("food_done", 0) + 1
            self._emit_stats()

            # ── Pause fin de cycle ─────────────────────────────────────────
            if self._running and cycle_delay_ms > 0:
                self.sig_log.emit(f"FAT — pause {cycle_delay_ms}ms", "info")
                self._sleep(cycle_delay_ms)

        self.sig_log.emit("FAT Macro — stopped", "warn")

    @pyqtSlot()
    def stop_loop(self):
        self._running = False; self._paused = False
        pulser = getattr(self, '_roadworks_pulser', None)
        if pulser:
            try: pulser.stop_all()
            except Exception: pass

    def update_config(self, cfg: dict): self.cfg = cfg

    def _sleep(self, ms: int):
        end = time.time() + ms / 1000.0
        while time.time() < end:
            if not self._running: return
            time.sleep(0.03)


    def _precise_sleep(self, ms: int):
        """Sleep précis pour les étapes Roadworks.
        Utilise perf_counter() partout + timeBeginPeriod(1) actif au niveau module
        pour une précision ~1 ms au lieu des ~15 ms par défaut de Windows."""
        if ms <= 0:
            return
        target = time.perf_counter() + ms / 1000.0
        # Phase OS : sleep par tranches de 1 ms jusqu'à 2 ms avant la cible
        # (timeBeginPeriod(1) rend time.sleep(0.001) fiable à ~1 ms)
        while True:
            if not self._running:
                return
            remaining = target - time.perf_counter()
            if remaining <= 0.002:
                break
            time.sleep(0.001)
        # Busy-wait final sur les 2 dernières ms pour la précision maximale
        while time.perf_counter() < target:
            if not self._running:
                return

    def _rw_step(self, pulser, duration_ms: int, *vks: int):
        """Transition + précision sleep en une seule opération.
        Le timer démarre AVANT transition() : le temps passé à changer les touches
        est absorbé dans la durée de l'étape, pas ajouté par-dessus."""
        target = time.perf_counter() + duration_ms / 1000.0
        pulser.transition(*vks)
        # Attendre jusqu'à la cible avec sleep(1ms) + busy-wait final
        while True:
            if not self._running:
                return
            remaining = target - time.perf_counter()
            if remaining <= 0.002:
                break
            time.sleep(0.001)
        while time.perf_counter() < target:
            if not self._running:
                return

    def _wait_resume(self):
        while self._paused and self._running: time.sleep(0.1)

    def _emit_stats(self):
        s = dict(self.stats); s["run_time_s"] = int(time.time() - self._start_t)
        self.sig_stat.emit(s)

    def _get_pixel(self, x: int, y: int) -> int:
        """Capture pixel robuste : BitBlt d'abord (rapide), puis fallback PrintWindow
        pour les fenêtres Roblox rendues via DWM/GPU sous Windows 11."""
        ix, iy = int(x), int(y)

        # ── Méthode 1 : BitBlt sur le DC écran (fonctionne si DWM expose le pixel) ──
        hdc_screen = user32.GetDC(0)
        hdc_mem    = gdi32.CreateCompatibleDC(hdc_screen)
        hbm        = gdi32.CreateCompatibleBitmap(hdc_screen, 1, 1)
        gdi32.SelectObject(hdc_mem, hbm)
        ok = gdi32.BitBlt(hdc_mem, 0, 0, 1, 1, hdc_screen, ix, iy, 0x00CC0020)
        col = gdi32.GetPixel(hdc_mem, 0, 0) if ok else 0xFFFFFFFF
        gdi32.DeleteObject(hbm)
        gdi32.DeleteDC(hdc_mem)
        user32.ReleaseDC(0, hdc_screen)

        # Résultat valide → le convertir RGB→BGR et retourner
        if col not in (0xFFFFFFFF,) and 0 <= col < 0xFFFFFF:
            c = int(col) & 0xFFFFFF
            rgb = ((c & 0xFF) << 16) | (c & 0xFF00) | ((c >> 16) & 0xFF)
            if rgb != 0:          # 0x000000 pur = souvent un écran noir légitime
                return rgb

        # ── Méthode 2 : PrintWindow sur la fenêtre Roblox (contourne DWM/GPU) ──
        try:
            hwnd = self._get_hwnd()
            if hwnd and user32.IsWindowVisible(hwnd):
                rect = RECT()
                user32.GetWindowRect(hwnd, ctypes.byref(rect))
                # Coordonnées relatives à la fenêtre
                rel_x = ix - rect.left
                rel_y = iy - rect.top
                win_w = rect.right  - rect.left
                win_h = rect.bottom - rect.top
                if 0 <= rel_x < win_w and 0 <= rel_y < win_h:
                    hdc_s = user32.GetDC(0)
                    hdc_m = gdi32.CreateCompatibleDC(hdc_s)
                    hbm2  = gdi32.CreateCompatibleBitmap(hdc_s, win_w, win_h)
                    gdi32.SelectObject(hdc_m, hbm2)
                    # PW_RENDERFULLCONTENT (0x02) : capture le contenu GPU/DX
                    user32.PrintWindow(hwnd, hdc_m, 0x02)
                    col2 = gdi32.GetPixel(hdc_m, rel_x, rel_y)
                    gdi32.DeleteObject(hbm2)
                    gdi32.DeleteDC(hdc_m)
                    user32.ReleaseDC(0, hdc_s)
                    if col2 not in (0xFFFFFFFF,) and col2 >= 0:
                        c2 = int(col2) & 0xFFFFFF
                        return ((c2 & 0xFF) << 16) | (c2 & 0xFF00) | ((c2 >> 16) & 0xFF)
        except Exception:
            pass

        # ── Méthode 3 : Pillow ImageGrab (dernier recours, lent mais fiable) ──
        try:
            from PIL import ImageGrab
            img = ImageGrab.grab(bbox=(ix, iy, ix + 1, iy + 1), all_screens=True)
            r, g, b = img.getpixel((0, 0))[:3]
            return (r << 16) | (g << 8) | b
        except Exception:
            pass

        return 0

    @staticmethod
    def _color_match(c1: int, c2: int, tol: int) -> bool:
        return (abs((c1>>16&0xFF)-(c2>>16&0xFF)) <= tol and
                abs((c1>>8 &0xFF)-(c2>>8 &0xFF)) <= tol and
                abs((c1    &0xFF)-(c2    &0xFF)) <= tol)

    def _pixel_match(self, x: int, y: int, color_str, tol: int) -> bool:
        try:
            target = int(str(color_str).replace("0x","").replace("#",""), 16)
            return self._color_match(self._get_pixel(x, y), target, tol)
        except Exception: return False

    def _get_pixel_in_window(self, hwnd: int, rel_x: int, rel_y: int) -> int:
        try:
            rect = RECT(); user32.GetClientRect(hwnd, ctypes.byref(rect))
            w, h = rect.right - rect.left, rect.bottom - rect.top
            if w <= 0 or h <= 0 or rel_x < 0 or rel_y < 0 or rel_x >= w or rel_y >= h: return 0
            hdc_s = user32.GetDC(0); hdc_m = gdi32.CreateCompatibleDC(hdc_s)
            hbm   = gdi32.CreateCompatibleBitmap(hdc_s, w, h); gdi32.SelectObject(hdc_m, hbm)
            user32.PrintWindow(hwnd, hdc_m, 1)
            col = gdi32.GetPixel(hdc_m, rel_x, rel_y)
            gdi32.DeleteObject(hbm); gdi32.DeleteDC(hdc_m); user32.ReleaseDC(0, hdc_s)
            if col == 0xFFFFFFFF: return 0
            return ((col & 0xFF) << 16) | (col & 0xFF00) | ((col >> 16) & 0xFF)
        except Exception: return 0

    def _screen_to_client(self, hwnd: int, sx: int, sy: int):
        pt = ctypes.wintypes.POINT(int(sx), int(sy))
        user32.ScreenToClient(hwnd, ctypes.byref(pt))
        return pt.x, pt.y

    def _pixel_match_in_window(self, hwnd: int, sx: int, sy: int, color_str, tol: int) -> bool:
        try:
            target = int(str(color_str).replace("0x","").replace("#",""), 16)
            rx, ry = self._screen_to_client(hwnd, sx, sy)
            return self._color_match(self._get_pixel_in_window(hwnd, rx, ry), target, tol)
        except Exception: return False

    def _pixel_match_screen(self, sx: int, sy: int, color_str, tol: int) -> bool:
        try:
            target = int(str(color_str).replace("0x","").replace("#",""), 16)
            return self._color_match(self._get_pixel(sx, sy), target, tol)
        except Exception: return False

    def _find_pixel_in_box(self, cx: int, cy: int, radius: int, color_str, tol: int):
        color = str(color_str).strip()
        if not color: return None
        try: target = int(color.replace("0x","").replace("#",""), 16)
        except Exception: return None
        best_pt, best_dist = None, float("inf")
        for dy in range(-radius, radius + 1):
            for dx in range(-radius, radius + 1):
                actual = self._get_pixel(cx + dx, cy + dy)
                if not actual: continue
                if self._color_match(actual, target, tol): return cx + dx, cy + dy
                r1,g1,b1 = actual>>16&0xFF, actual>>8&0xFF, actual&0xFF
                r2,g2,b2 = target>>16&0xFF, target>>8&0xFF, target&0xFF
                d = (r1-r2)**2 + (g1-g2)**2 + (b1-b2)**2
                if d < best_dist: best_dist, best_pt = d, (cx + dx, cy + dy)
        ft = max(tol, 24)
        if best_pt and best_dist <= ft**2 * 3:
            actual = self._get_pixel(*best_pt)
            r1,g1,b1 = actual>>16&0xFF, actual>>8&0xFF, actual&0xFF
            r2,g2,b2 = target>>16&0xFF, target>>8&0xFF, target&0xFF
            if abs(r1-r2) <= ft*2 and abs(g1-g2) <= ft*2 and abs(b1-b2) <= ft*2:
                return best_pt
        return None

    @staticmethod
    def _move_mouse(x: int, y: int): user32.SetCursorPos(int(x), int(y))

    @staticmethod
    def _lclick():
        _send_mouse_input(MOUSEEVENTF_LEFTDOWN); time.sleep(random.uniform(0.05,0.09))
        _send_mouse_input(MOUSEEVENTF_LEFTUP);   time.sleep(random.uniform(0.03,0.06))

    def _rclick(self):
        if bool(self.cfg.get("NoM2Mode", 0)) and self._mode == "trial": return
        _send_mouse_input(MOUSEEVENTF_RIGHTDOWN); time.sleep(random.uniform(0.05,0.09))
        _send_mouse_input(MOUSEEVENTF_RIGHTUP);   time.sleep(random.uniform(0.03,0.06))

    def _send_key(self, key: str, hold_ms: int = 0):
        if not key: return
        vk = _resolve_vk(key)
        if not vk: self.sig_log.emit(f"Unknown key: {key}", "warn"); return
        try:
            time.sleep(random.uniform(0.03,0.07))
            _send_key_input(vk)
            if hold_ms > 0: self._sleep(hold_ms)
            else: time.sleep(random.uniform(0.05,0.10))
            _send_key_input(vk, key_up=True)
            time.sleep(random.uniform(0.03,0.06))
        except Exception as e:
            self.sig_log.emit(f"Key error ({key}): {e}", "warn")

    def _key_down(self, key: str):
        if key:
            vk = _resolve_vk(key)
            if vk: time.sleep(random.uniform(0.02,0.05)); _send_key_input(vk)

    def _key_up_release(self, key: str):
        if key:
            vk = _resolve_vk(key)
            if vk: time.sleep(random.uniform(0.02,0.05)); _send_key_input(vk, key_up=True)

    def _lock_cursor_to_game(self):
        title = self.cfg.get("GameTitle","")
        if not title: return
        hwnd = user32.FindWindowW(None, title)
        if not hwnd: return
        rect = RECT(); user32.GetWindowRect(hwnd, ctypes.byref(rect)); user32.ClipCursor(ctypes.byref(rect))

    @staticmethod
    def _release_cursor(): user32.ClipCursor(None)

    def _focus_game(self):
        title = self.cfg.get("GameTitle","")
        if not title: return
        hwnd = user32.FindWindowW(None, title)
        if not hwnd: return
        for _ in range(3):
            user32.SetForegroundWindow(hwnd); time.sleep(0.08)
            if user32.GetForegroundWindow() == hwnd: break
            time.sleep(0.07)

    def _focus_win(self, title: str, hwnd: int = 0):
        if not hwnd: hwnd = user32.FindWindowW(None, title) if title else 0
        if hwnd:
            for _ in range(3):
                user32.SetForegroundWindow(hwnd); time.sleep(0.08)
                if user32.GetForegroundWindow() == hwnd: break

    def _human_glide(self, x: int, y: int, steps: int = 4):
        pt = ctypes.wintypes.POINT(); user32.GetCursorPos(ctypes.byref(pt))
        sx, sy = pt.x, pt.y
        cx = (sx + x) // 2 + random.randint(-12, 12)
        cy = (sy + y) // 2 + random.randint(-8, 8)
        for i in range(1, steps + 1):
            t = i / steps
            if t <= 0.5:
                seg = t * 2; mx = int(sx + (cx-sx)*seg); my = int(sy + (cy-sy)*seg)
            else:
                seg = (t-0.5)*2; mx = int(cx + (x-cx)*seg); my = int(cy + (y-cy)*seg)
            self._move_mouse(mx + random.randint(-1,1), my + random.randint(-1,1))
            time.sleep(random.uniform(0.012, 0.030))
        self._move_mouse(x, y); time.sleep(random.uniform(0.04, 0.08))

    def _get_hwnd(self) -> int:
        title = self.cfg.get("GameTitle","")
        hwnd  = user32.FindWindowW(None, title) if title else 0
        if hwnd: return hwnd
        found = ctypes.c_int(0)
        EnumProc = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.wintypes.HWND, ctypes.wintypes.LPARAM)
        def _cb(h, _):
            buf = ctypes.create_unicode_buffer(256); user32.GetWindowTextW(h, buf, 256)
            if "Roblox" in buf.value and user32.IsWindowVisible(h): found.value = h; return False
            return True
        user32.EnumWindows(EnumProc(_cb), 0)
        return found.value

    def _glide_click(self, x: int, y: int):
        self._focus_game(); time.sleep(random.uniform(0.10, 0.15))
        tx, ty = x + random.randint(-2,2), y + random.randint(-1,1)
        self._human_glide(tx, ty); _send_move_and_click(tx, ty)
        time.sleep(random.uniform(0.05, 0.09))

    def _glide_click_in(self, title: str, x: int, y: int, hwnd: int = 0):
        self._focus_win(title, hwnd); time.sleep(random.uniform(0.08,0.12))
        tx, ty = x + random.randint(-2,2), y + random.randint(-1,1)
        self._human_glide(tx, ty); _send_move_and_click(tx, ty)
        time.sleep(random.uniform(0.05, 0.09))

    def _send_key_in(self, title: str, key: str, hwnd: int = 0):
        self._focus_win(title, hwnd); time.sleep(random.uniform(0.04,0.08)); self._send_key(key)

    def _rclick_in(self, title: str, hwnd: int = 0):
        self._focus_win(title, hwnd); time.sleep(random.uniform(0.04,0.08)); self._rclick()

    def _lclick_in(self, title: str, hwnd: int = 0):
        self._focus_win(title, hwnd); time.sleep(random.uniform(0.04,0.08)); self._lclick()

    def _press_button_until_gone(self, bx, by, detect_fn, label, timeout_s=30.0):
        self.sig_log.emit(f"{label} — clicking...", "info")
        deadline = time.time() + timeout_s
        while self._running and time.time() < deadline:
            self._glide_click(bx + random.randint(-4,4), by + random.randint(-3,3))
            for _ in range(6):
                if not self._running: return
                time.sleep(0.05)
                if not detect_fn(): self.sig_log.emit(f"{label} — button gone ✓","ok"); return
            self._sleep(random.randint(200,380))
        self.sig_log.emit(f"{label} — timeout ({timeout_s}s)","warn")

    def _snap_game_window(self):
        title = self.cfg.get("GameTitle","")
        if not title: self.sig_log.emit("GameTitle not set","warn"); return
        hwnd = user32.FindWindowW(None, title)
        if not hwnd: self.sig_log.emit(f"Window not found: {title}","warn"); return
        w, h = self.cfg.get("GameWinW",384), self.cfg.get("GameWinH",216)
        user32.ShowWindow(hwnd, 9); time.sleep(0.15)
        user32.SetWindowPos(hwnd, 0, 0, 0, int(w), int(h), 0x0040)
        self.sig_log.emit(f"Window positioned: {w}x{h} @ (0,0)","ok")

    def _snap_two_windows(self):
        c = self.cfg
        t1, t2 = c.get("DUR_GameTitle1",""), c.get("DUR_GameTitle2","")
        w1, h1 = int(c.get("DUR_Win1W",384)), int(c.get("DUR_Win1H",216))
        w2, h2 = int(c.get("DUR_Win2W",384)), int(c.get("DUR_Win2H",216))
        gap    = int(c.get("DUR_WinGap", 20))

        def _resolve(stored, title):
            if stored and user32.IsWindow(stored): return stored
            return user32.FindWindowW(None, title) if title else 0

        def _snap(hwnd, label, x, y, w, h):
            if not hwnd: self.sig_log.emit(f"Fenêtre introuvable : {label}","warn"); return
            user32.ShowWindow(hwnd, 9); time.sleep(0.1)
            user32.SetWindowPos(hwnd, 0, x, y, w, h, 0x0040)
            self.sig_log.emit(f"Fenêtre '{label}' → ({x},{y}) {w}x{h}","ok")

        h1h = _resolve(self._dur_hwnd1, t1); h2h = _resolve(self._dur_hwnd2, t2)
        _snap(h1h, t1 or "Win1", 0, 0, w1, h1); time.sleep(0.15)
        _snap(h2h, t2 or "Win2", w1 + gap, 0, w2, h2); time.sleep(0.15)

    def _resolve_dur_hwnd(self, title: str, slot: int) -> int:
        stored = self._dur_hwnd1 if slot == 1 else self._dur_hwnd2
        if stored and user32.IsWindow(stored): return stored
        return user32.FindWindowW(None, title) if title else 0

    def _is_start_visible(self) -> bool:
        c = self.cfg
        return self._pixel_match(c["START_DETECT_X"],c["START_DETECT_Y"],c["START_DETECT_Color"],c["START_DETECT_Tolerance"])

    def _is_trial_over(self) -> bool:
        c = self.cfg; return self._pixel_match(c["END_X"],c["END_Y"],c["END_Color"],c["END_Tolerance"])

    def _is_ult_ready(self) -> bool:
        c = self.cfg; return self._pixel_match(c["ULT_X"],c["ULT_Y"],c["ULT_Color"],c["ULT_Tolerance"])

    def _is_food_available(self) -> bool:
        # Utilise _pixel_match_screen pour détecter sur tout l'écran (coordonnées absolues)
        # → compatible Roblox même si la fenêtre est en arrière-plan ou redimensionnée
        c = self.cfg
        return self._pixel_match_screen(
            int(c.get("FOOD_X", 200)),
            int(c.get("FOOD_Y", 970)),
            c.get("FOOD_Color", "0xFF8C00"),
            int(c.get("FOOD_Tolerance", 30))
        )

    def _is_food_block_pixel_present(self) -> bool:
        """Return True when any configured anti-eat block pixel is present."""
        c = self.cfg
        blocks = [
            ("FOOD_BLOCK_X", "FOOD_BLOCK_Y", "FOOD_BLOCK_Color", "FOOD_BLOCK_Tolerance"),
            ("FOOD_BLOCK2_X","FOOD_BLOCK2_Y","FOOD_BLOCK2_Color","FOOD_BLOCK2_Tolerance"),
        ]
        for x_key, y_key, col_key, tol_key in blocks:
            bx = c.get(x_key, "")
            by = c.get(y_key, "")
            bcol = c.get(col_key, "")
            if bx == "" or by == "" or bcol == "":
                continue
            try:
                if self._pixel_match_screen(
                    int(bx),
                    int(by),
                    bcol,
                    int(c.get(tol_key, 30))
                ):
                    return True
            except ValueError:
                continue
        return False

    def _eat_food(self):
        """Boucle food : touche food → clic → attendre pixel revient.
        Retourne la touche utilisée si succès, None sinon."""
        c = self.cfg
        fpx, fpy = int(c.get("FOOD_X", 200)), int(c.get("FOOD_Y", 970))
        fcol = c.get("FOOD_Color", "0xFF8C00")
        ftol = int(c.get("FOOD_Tolerance", 30))
        click_x = int(c.get("FOOD_CLICK_X", 960))
        click_y = int(c.get("FOOD_CLICK_Y", 540))
        key_duration_ms = int(c.get("FOOD_KeyDuration", 100))

        food_keys = [c.get(f"Food{i}Key", "") for i in range(1, 7)]
        food_keys = [k for k in food_keys if k]
        if not food_keys:
            return None

        for k in food_keys:
            if not self._running:
                break
            self.sig_log.emit(f"Food — touche '{k}'", "info")
            # 1. Equip food
            self._send_key(k, hold_ms=key_duration_ms)
            self._sleep(150)
            # 2. Click to eat
            self._glide_click(click_x, click_y)
            self._sleep(300)
            # 3. Attendre que le pixel revienne (barre food remontée, max 3s)
            waited = 0
            pixel_back = False
            while self._running and waited < 3000:
                if self._pixel_match_screen(fpx, fpy, fcol, ftol):
                    pixel_back = True
                    break
                self._sleep(120); waited += 120
            if pixel_back:
                self.stats["food_eaten"] += 1; self._emit_stats()
                self.sig_log.emit(f"Food consumed ✓ (touche '{k}')", "info")
                return k
            # Pixel pas revenu → touche suivante
            self._sleep(300)
        return None

    def _eat_food_in_win(self, title: str, food_keys: list, fcx: int, fcy: int, hwnd: int = 0,
                          food_px: int = None, food_py: int = None,
                          food_pcol: str = None, food_ptol: int = None):
        """Eat food in a specific window (Durability / Strength).
        Retourne la touche utilisée si succès, False si toutes épuisées, None si rien tenté."""
        c = self.cfg
        fpx  = food_px   if food_px   is not None else int(c.get("FOOD_X", 200))
        fpy  = food_py   if food_py   is not None else int(c.get("FOOD_Y", 970))
        fcol = food_pcol if food_pcol is not None else c.get("FOOD_Color", "0xFF8C00")
        ftol = food_ptol if food_ptol is not None else int(c.get("FOOD_Tolerance", 30))
        label = (title[:15] if title else f"HWND:{hwnd}")

        valid_keys = [k for k in food_keys if k]
        if not valid_keys:
            return None

        # Test de fiabilité pixel avant de commencer (coord écran absolues)
        pixel_before = self._pixel_match_screen(fpx, fpy, fcol, ftol)

        used_key = None
        tried_any = False

        for k in valid_keys:
            if not self._running:
                break
            tried_any = True
            # 1. Equip food
            self._send_key_in(title, k, hwnd)
            self._sleep(150)
            # 2. Click to eat
            self._glide_click_in(title, fcx, fcy, hwnd)
            self._sleep(300)
            # 3. Wait for the pixel to return (max 3s)
            waited = 0
            pixel_back = False
            while self._running and waited < 3000:
                if self._pixel_match_screen(fpx, fpy, fcol, ftol):
                    pixel_back = True
                    break
                self._sleep(120); waited += 120
            if pixel_back:
                used_key = k
                self.stats["food_eaten"] += 1; self._emit_stats()
                self.sig_log.emit(f"Food consumed [{label}] ✓", "info")
                return used_key
            # Pixel did not return → next key
            self._sleep(300)

        if tried_any:
            return False
        return None

    def _check_and_eat(self):
        """Check the food pixel and eat if it is missing.
        If a BLOCK pixel is present when eating is needed, do not eat.
        Returns the used key, or None."""
        if self._phase == "Combat":
            return None
        # Eat when the food pixel is NOT detected (food depleted = needs eating)
        # 3 attempts for Windows 11 / DWM / DPI scaling reliability
        detected = False
        for _attempt in range(3):
            if self._is_food_available():
                detected = True
                break
            if _attempt < 2:
                self._sleep(80)
        if not detected:
            # Food pixel missing → check block pixels
            block = False
            for _ba in range(3):
                if self._is_food_block_pixel_present():
                    block = True
                    break
                if _ba < 2:
                    self._sleep(80)
            if block:
                self.sig_log.emit("Food pixel missing but BLOCK pixel detected → skip eating", "warn")
                return None
            # Food pixel missing and no block → food depleted, eat now
            self.sig_log.emit("Food pixel missing — eating now...", "info")
            self._sleep(300)
            return self._eat_food()
        return None

    def _do_transform(self, transfo_key: str, attack_key: str, duration_ms: int):
        self.sig_log.emit("Transforming!","ok"); self._focus_game()
        vk = _resolve_vk(transfo_key)
        if vk: _send_key_input(vk)
        time.sleep(random.uniform(0.05,0.10))
        end_t = time.time() + duration_ms / 1000.0
        while self._running and time.time() < end_t:
            self._lclick(); time.sleep(random.uniform(0.08,0.14))
        if vk: _send_key_input(vk, key_up=True)
        time.sleep(random.uniform(0.10,0.20)); self._send_key(attack_key); self._sleep(120)

    def _do_skill(self, skill_key: str, attack_key: str):
        self._send_key(skill_key); time.sleep(random.uniform(0.04,0.08))
        self._lclick(); time.sleep(random.uniform(0.06,0.10))
        self._send_key(attack_key); self._sleep(60)

    def _do_ult(self, ult_key: str, attack_key: str):
        self.sig_log.emit("Ultimate ready — activating!","ok")
        self._send_key(ult_key); time.sleep(random.uniform(0.04,0.08)); self._lclick()
        t0 = time.time()
        while self._running and time.time() - t0 < 3.0:
            self._lclick(); self._sleep(int(random.uniform(80,120)))
        time.sleep(random.uniform(0.06,0.10)); self._send_key(attack_key); self._sleep(80)

    def _combat_loop(self):
        c = self.cfg; abrawl = bool(c.get("AbrawlMode",0))
        self._phase = "Combat"; self.sig_phase.emit("Combat")
        self.sig_log.emit(f"Combat started [{'ABRAWL' if abrawl else 'Normal'}]","ok")
        attack_key  = c.get("AttackKey","5")
        transfo_key = c.get("Key_Transfo","")
        skill_keys  = [c.get(f"Key_Skill{i}","") for i in range(1,6)]
        skill_cds   = [c.get(f"CD_Skill{i}",2000) for i in range(1,6)]
        last_skill  = [0.0]*5
        active_skills = [i for i,k in enumerate(skill_keys) if k]
        skill_cycle_pending = active_skills.copy()
        ult_key = c.get("Key_Ult","")
        self._focus_game(); self._sleep(200)
        if transfo_key:
            self.sig_log.emit(f"Waiting before transform ({c.get('TransfoStartDelay',500)}ms)...","info")
            self._sleep(c.get("TransfoStartDelay",500))
            if not self._running: return
            self._do_transform(transfo_key, attack_key, c.get("TransfoDuration",6000))
        if not self._running: return
        self.sig_log.emit("Activating combat style...","info"); self._send_key(attack_key); self._sleep(150)
        while self._running:
            self._wait_resume()
            if not self._running: break
            if self._is_trial_over(): self.sig_log.emit("Trial end detected!","warn"); self._phase = "End"; break
            for _ in range(5):
                if not self._running: break
                self._lclick(); time.sleep(random.uniform(0.03,0.06))
            if self._running: self._rclick()
            self._sleep(c.get("AttackDelay",60))
            if not self._running or abrawl: continue
            now = time.time()
            if ult_key and self._is_ult_ready():
                self._do_ult(ult_key, attack_key)
                self.stats["ult_used"] += 1; self._emit_stats()
            else:
                if not skill_cycle_pending: skill_cycle_pending = active_skills.copy()
                for i in skill_cycle_pending:
                    if now - last_skill[i] >= skill_cds[i]/1000.0:
                        self._do_skill(skill_keys[i], attack_key)
                        last_skill[i] = time.time(); self.stats["skills_used"] += 1; self._emit_stats()
                        skill_cycle_pending.remove(i); break
            self._sleep(20)

    def _wait_for_start(self) -> bool:
        c = self.cfg; deadline = time.time() + c["START_WAIT_Timeout"]/1000.0
        last_fc = time.time(); fi = c["FoodCheckInterval"]/1000.0
        self.sig_log.emit("Waiting for Start Trial button...","info")
        self._phase = "Waiting"; self.sig_phase.emit("Waiting")
        while self._running:
            self._wait_resume()
            if not self._running: return False
            if self._is_start_visible(): self.sig_log.emit("Start button detected!","ok"); return True
            if time.time() >= deadline:
                self.sig_log.emit("Timeout — Start button not detected!","error"); self._sleep(3000); return False
            if time.time() - last_fc >= fi: self._check_and_eat(); last_fc = time.time()
            self._sleep(200)
        return False

    def _start_trial(self):
        c = self.cfg; self._phase = "Starting"; self.sig_phase.emit("Starting")
        self.sig_log.emit("Starting trial...","info"); self._sleep(c["UI_Delay"])
        self._press_button_until_gone(c["BTN_START_X"],c["BTN_START_Y"],self._is_start_visible,"Start button",30.0)
        self._sleep(800)

    def _post_trial(self):
        c = self.cfg; self._phase = "Post-Trial"; self.sig_phase.emit("Post-Trial")
        self.stats["trials_done"] += 1; self._emit_stats()
        self.sig_log.emit(f"Trial #{self.stats['trials_done']} finished!","ok")
        self._sleep(1200)
        if not self._running: return
        self.sig_log.emit("Clicking Quit...","info")
        self._press_button_until_gone(c["BTN_QUIT_X"],c["BTN_QUIT_Y"],self._is_trial_over,"Quit button",30.0)
        self._sleep(800)
        delay_ms = c.get("PostTrialDelay",5000)
        self.sig_log.emit(f"Post-trial pause ({delay_ms/1000:.1f}s)...","info"); self._sleep(delay_ms)
        if self._running: self._check_and_eat()
        self._phase = "Idle"; self.sig_phase.emit("Idle")

    def _main_loop(self):
        self._snap_game_window(); self._sleep(400)
        while self._running:
            self._wait_resume()
            if not self._running: break
            self._check_and_eat(); self._phase = "Idle"; self.sig_phase.emit("Idle")
            if not self._wait_for_start(): break
            self._start_trial()
            if not self._running: break
            self._combat_loop()
            if not self._running: break
            self._post_trial(); self._sleep(1000)

    def _shadow_boxing_loop(self):
        c = self.cfg
        training_key     = c.get("SB_TrainingKey","e")
        fight_style_key  = c.get("SB_FightingStyleKey","r")
        spin_duration_ms = int(c.get("SB_SpinDuration",31000))
        rclick_iv_ms     = max(50, int(c.get("SB_RClickInterval",300)))
        cycle_delay_ms   = int(c.get("SB_CycleDelay",10000))
        self._phase = "Shadow Boxing"; self.sig_phase.emit("Shadow Boxing")
        self.sig_log.emit("Shadow Boxing — started","ok")
        self._focus_game(); self._sleep(300)
        self.sig_log.emit("SB — Clic gauche + Training key","info")
        self._lclick(); self._sleep(150); self._send_key(training_key); self._sleep(300)
        if not self._running: return
        self.sig_log.emit("SB — Clic gauche + Fighting Style key","info")
        self._lclick(); self._sleep(150); self._send_key(fight_style_key); self._sleep(350)
        if not self._running: return
        rot_str = c.get("SB_RotationKey","right").strip().lower() or "right"
        rot_vk = _resolve_vk(rot_str) or 0x27
        rot_thread = _KeyPulseThread(rot_vk); rot_thread.start(); time.sleep(0.05)
        spin_end = time.time() + spin_duration_ms / 1000.0
        try:
            while self._running and time.time() < spin_end:
                self._wait_resume()
                if not self._running: break
                self._lclick()
                if not self._running or time.time() >= spin_end: break
                time.sleep(max(0.01, rclick_iv_ms/1000.0 - 0.12))
                if not self._running or time.time() >= spin_end: break
                self._rclick()
        finally:
            rot_thread.stop(); time.sleep(0.05)
        if not self._running: return
        self.sig_log.emit("SB — Click phase finished","info"); self._sleep(300)
        food_before = self.stats["food_eaten"]; self._check_and_eat()
        ate = self.stats["food_eaten"] > food_before
        if ate:
            self.sig_log.emit("SB — Food eaten, waiting for food pixel...","info")
            wait_end = time.time() + 15.0
            while self._running and time.time() < wait_end:
                if not self._is_food_available(): break
                time.sleep(0.3)
            self.sig_log.emit("SB — Food done → double Fighting Style","info")
            self._focus_game(); self._sleep(300)
            self._send_key(fight_style_key); self._sleep(220)
            self._send_key(fight_style_key); self._sleep(200)
        else:
            self.sig_log.emit("SB — Fin cycle → Fighting Style","info")
            self._focus_game(); self._sleep(200); self._send_key(fight_style_key); self._sleep(200)
        self.sig_log.emit(f"SB — Pause {cycle_delay_ms/1000:.1f}s avant prochain cycle...","info")
        self._sleep(cycle_delay_ms)
        self.stats["shadowboxing_done"] += 1; self._emit_stats()
        self.sig_log.emit("SB — Cycle complete ✓","ok")

    def _pixel_scan_and_training_sequence(self, cx, cy, radius, color_str, tol,
                                           training_key, stat_mode,
                                           speed_x, speed_y, stamina_x, stamina_y) -> bool:
        pulser = getattr(self, '_roadworks_pulser', None)
        fwd_key = "w" if str(self.cfg.get("RW_KeyboardLayout", "azerty")).lower() == "qwerty" else "z"
        vk_fwd_local = _resolve_vk(fwd_key)

        def _release_secondary():
            if not pulser:
                return
            with pulser._lock:
                old_vks = set(pulser._vks)
                to_release = old_vks - {vk_fwd_local}
            for vk in to_release:
                pulser._keyup(vk)
            with pulser._lock:
                pulser._vks = old_vks - to_release
            self._sleep(60)

        def _do_click_sequence(pos_x, pos_y):
            import time as _time
            _release_secondary()
            if pulser and self._running:
                pulser.press_add(vk_fwd_local)
                self._sleep(20)
            # Spam clics sur la position pixel pour ouvrir le menu training
            self.sig_log.emit("Roadworks — spam clic position pixel (1000 ms)", "info")
            _tp = _time.time()
            while self._running and (_time.time() - _tp) < 1.00:
                self._glide_click(pos_x, pos_y + 10)
                _time.sleep(0.09)
            if not self._running:
                return False
            # Appui unique sur la touche training pour équiper
            self.sig_log.emit("Roadworks — touche Training (equiper)", "info")
            self._send_key(training_key)
            self._sleep(250)
            if not self._running:
                return False
            # 1 seul clic sur la position training
            self.sig_log.emit("Roadworks — clic unique training", "info")
            _send_move_and_click(pos_x + random.randint(-2, 2), pos_y + 10 + random.randint(-2, 2), hold_ms=90)
            self._sleep(300)
            if not self._running:
                return False
            # Plusieurs clics sur stamina ou speed avec pause entre chaque
            bx = stamina_x if stat_mode == "stamina" else speed_x
            by = stamina_y if stat_mode == "stamina" else speed_y
            self.sig_log.emit(f"Roadworks — clics {stat_mode.upper()} (3x)", "info")
            for _ci in range(3):
                if not self._running: break
                _send_move_and_click(bx + random.randint(-2, 2), by + random.randint(-1, 1), hold_ms=90)
                _time.sleep(0.18)
            self._sleep(200)
            if not self._running:
                return False
            self.sig_log.emit("Roadworks — touche Training (desequiper)", "info")
            self._send_key(training_key)
            self._sleep(150)
            if pulser and self._running:
                pulser.press_add(vk_fwd_local)
                self._sleep(40)
            return self._running

        color_str = str(color_str).strip()
        if not color_str:
            self.sig_log.emit("Roadworks — pas de couleur, clic direct sur zone", "warn")
            return _do_click_sequence(cx, cy)

        try:
            hex_str = color_str.replace("0x", "").replace("#", "")
            target_rgb = (
                int(hex_str[0:2], 16),
                int(hex_str[2:4], 16),
                int(hex_str[4:6], 16),
            )
        except Exception:
            self.sig_log.emit(f"Roadworks — couleur invalide '{color_str}', clic direct", "warn")
            return _do_click_sequence(cx, cy)

        try:
            from PIL import ImageGrab
        except ImportError:
            self.sig_log.emit("Roadworks — Pillow introuvable, clic direct (pip install Pillow)", "warn")
            return _do_click_sequence(cx, cy)

        retry  = 0
        left   = cx - radius
        top    = cy - radius
        right  = cx + radius + 1
        bottom = cy + radius + 1

        self.sig_log.emit(
            f"Roadworks — recherche pixel {color_str} dans zone "
            f"({left},{top})-({right},{bottom}) tol={tol}", "info"
        )

        while self._running:
            self._wait_resume()
            if not self._running:
                return False

            if pulser:
                pulser.press_add(vk_fwd_local)

            try:
                img = ImageGrab.grab(bbox=(left, top, right, bottom), all_screens=True)
            except Exception as e:
                self.sig_log.emit(f"Roadworks — screen capture failed: {e}", "warn")
                self._sleep(200)
                retry += 1
                continue

            tr, tg, tb = target_rgb
            found_x = found_y = None
            best_dist = float("inf")
            best_x = best_y = None

            pixels = img.load()
            w, h = img.size
            for py in range(h):
                for px in range(w):
                    pixel = pixels[px, py]
                    r, g, b = pixel[0], pixel[1], pixel[2]
                    if abs(r - tr) <= tol and abs(g - tg) <= tol and abs(b - tb) <= tol:
                        found_x = left + px
                        found_y = top  + py
                        break
                    d = (r - tr)**2 + (g - tg)**2 + (b - tb)**2
                    if d < best_dist:
                        best_dist = d
                        best_x = left + px
                        best_y = top  + py
                if found_x is not None:
                    break

            if found_x is not None:
                self.sig_log.emit(
                    f"Roadworks — pixel found at ({found_x},{found_y}) after {retry} attempt(s)", "ok"
                )
                return _do_click_sequence(found_x, found_y)

            retry += 1
            if retry % 10 == 1:
                self.sig_log.emit(f"Roadworks — pixel introuvable, tentative {retry}", "warn")
            self._sleep(120)

        return False

    def _roadworks_loop(self):
        c = self.cfg
        layout   = str(c.get("RW_KeyboardLayout", "azerty")).lower()
        key_fwd  = "w" if layout == "qwerty" else "z"
        key_left = "a" if layout == "qwerty" else "q"
        key_right, key_up, key_down, key_back = "d", "up", "down", "s"

        speed_mult = float(c.get("RW_SpeedAdjustment", 1.0))
        if speed_mult <= 0:
            speed_mult = 1.0  # sécurité : évite division par zéro

        def _ms(base_ms):
            return max(1, int(base_ms / speed_mult))

        target_laps    = int(c.get("RW_Laps", 0))
        cycle_delay_ms = int(c.get("RW_CycleDelay", 2000))
        training_key   = str(c.get("RW_TrainingKey", "e")).strip() or "e"
        stat_mode      = str(c.get("RW_StatMode", "speed")).lower()
        click_x        = int(c.get("RW_ClickX",   960));  click_y  = int(c.get("RW_ClickY",   540))
        skin_x         = int(c.get("RW_SkinDetectX", click_x)); skin_y = int(c.get("RW_SkinDetectY", click_y))
        speed_x        = int(c.get("RW_SpeedX",   900));  speed_y  = int(c.get("RW_SpeedY",   400))
        stamina_x      = int(c.get("RW_StaminaX", 1020)); stamina_y = int(c.get("RW_StaminaY", 400))
        click_color    = str(c.get("RW_ClickDetectColor", "")).strip()
        click_tol      = int(c.get("RW_ClickDetectTolerance", 12))
        click_rad      = int(c.get("RW_ClickDetectRadius", 40))

        _DEFAULTS = [
              400, 2100, 6810, 6500, 3120, 2460, 1560, 2310, 1740, 2100,
               950, 270, 1250, 1360,  840, 2770, 1120, 100, 1420, 2000,
              3000, 500, 583, 0, 0,
        ]
        # step_ms index legend (init/inter phase):
        #   [20] = inter phase: Z+↑+↓ simultaneous (speedé)
        #   [21] = init: Z hold duration (ms) — NON speedé, fixe 500ms default
        #   [22] = init: S+D hold duration (ms) — speedé, default 583 (=700ms/1.2)
        #   [23] = init: D alone hold duration (ms) — speedé, 0=skip
        #   [24] = init: S alone hold duration (ms) — speedé, 0=skip
        step_ms = []
        for i, d in enumerate(_DEFAULTS):
            try:
                step_ms.append(max(1, int(c.get(f"RW_StepMs_{i}", d))))
            except (ValueError, TypeError):
                step_ms.append(d)

        vk_fwd   = _resolve_vk(key_fwd);  vk_left  = _resolve_vk(key_left)
        vk_right = _resolve_vk(key_right); vk_up   = _resolve_vk(key_up)
        vk_down  = _resolve_vk(key_down);  vk_back  = _resolve_vk(key_back)

        self._phase = "Roadworks"; self.sig_phase.emit("Roadworks")
        self.sig_log.emit(
            f"Roadworks — {layout.upper()}  fwd={key_fwd.upper()}  "
            f"stat={stat_mode.upper()}  laps={'∞' if target_laps == 0 else target_laps}", "ok"
        )

        P = _RoadworksPulser(); self._roadworks_pulser = P; P.start()
        self._focus_game(); self._sleep(300)

        laps_done = 0
        self.sig_log.emit("Roadworks — main loop start...", "ok")

        while self._running:
            self._wait_resume()
            if not self._running: break

            if target_laps > 0 and laps_done >= target_laps:
                self.sig_log.emit(
                    f"Roadworks — {laps_done} cycles ✓ pause {cycle_delay_ms/1000:.1f}s", "ok"
                )
                P.stop_all()
                self._sleep(cycle_delay_ms); laps_done = 0
                if not self._running: break
                # Créer un nouveau Pulser — l'ancien thread est mort après stop_all()
                P = _RoadworksPulser(); self._roadworks_pulser = P; P.start()
                self._focus_game(); self._sleep(200)

            self.sig_log.emit(
                f"Roadworks — cycle {laps_done+1}"
                f"{'/' + str(target_laps) if target_laps else ''}", "info"
            )

            self.sig_log.emit("Roadworks — phase init...", "info")

            # --- Double clic Z/W (2ème appui maintenu) ---
            P.release_all()
            _send_key_input(vk_fwd, False); time.sleep(0.05)   # 1er appui
            _send_key_input(vk_fwd, True);  time.sleep(0.04)   # relâche 1er
            _send_key_input(vk_fwd, False); time.sleep(0.05)   # 2ème appui — Z reste down
            # Enregistrer Z dans le Pulser sans re-keydown (déjà physiquement enfoncé)
            with P._lock:
                P._vks.add(vk_fwd)
            if not self._running: break

            # --- Clic rapide ↑ puis ↓ (Z toujours maintenu) ---
            _send_key_input(vk_up, False); time.sleep(0.05); _send_key_input(vk_up, True)
            time.sleep(0.03)
            if not self._running: break

            _send_key_input(vk_down, False); time.sleep(0.05); _send_key_input(vk_down, True)
            time.sleep(0.02)
            if not self._running: break

            # --- Maintien ↑ (+ Z toujours down) — FIXE non speedé (step_ms[21]) ---
            _up_hold_ms = max(1, step_ms[21])
            self.sig_log.emit(f"Roadworks — init: ↑ hold {_up_hold_ms} ms (fixed)", "info")
            P.press_add(vk_up)
            self._precise_sleep(_up_hold_ms)
            # Relâche ↑ uniquement, Z reste
            with P._lock:
                P._vks.discard(vk_up)
            _send_key_input(vk_up, True)
            if not self._running: break

            # --- Maintien ↓+D simultané — speedé (step_ms[22]) ---
            _sd_ms = _ms(step_ms[22])
            self.sig_log.emit(f"Roadworks — init: ↓+D hold {_sd_ms} ms (speedé)", "info")
            self._rw_step(P, _sd_ms, vk_fwd, vk_down, vk_right)
            if not self._running: break

            # --- Maintien D seul — speedé (step_ms[23], skip si 0) ---
            if step_ms[23] > 0:
                _d_ms = _ms(step_ms[23])
                self.sig_log.emit(f"Roadworks — init: D hold {_d_ms} ms (speedé)", "info")
                self._rw_step(P, _d_ms, vk_fwd, vk_right)
                if not self._running: break

            # --- Maintien ↓ seul — speedé (step_ms[24], skip si 0) ---
            if step_ms[24] > 0:
                _s_ms = _ms(step_ms[24])
                self.sig_log.emit(f"Roadworks — init: ↓ hold {_s_ms} ms (speedé)", "info")
                self._rw_step(P, _s_ms, vk_fwd, vk_down)
                if not self._running: break

            self.sig_log.emit("Roadworks — init phase complete, inter phase...", "ok")

            self.sig_log.emit(
                f"Roadworks — phase inter Z+↑+↓ ({step_ms[20]} ms)", "info"
            )
            self._rw_step(P, _ms(step_ms[20]), vk_fwd, vk_up, vk_down)
            if not self._running: break

            if not self._pixel_scan_and_training_sequence(
                skin_x, skin_y, click_rad, click_color, click_tol,
                training_key, stat_mode,
                speed_x, speed_y, stamina_x, stamina_y
            ): break
            if not self._running: break

            self.sig_log.emit("Roadworks — motion sequence (Z held)...", "info")

            self._rw_step(P, _ms(step_ms[1]), vk_fwd, vk_left)
            if not self._running: break

            self._rw_step(P, _ms(step_ms[2]), vk_fwd, vk_down)
            if not self._running: break

            self._rw_step(P, _ms(step_ms[3]), vk_fwd, vk_right)
            if not self._running: break

            self._rw_step(P, _ms(step_ms[4]), vk_fwd, vk_up)
            if not self._running: break

            self._rw_step(P, _ms(step_ms[5]), vk_fwd, vk_right)
            if not self._running: break

            self._rw_step(P, _ms(step_ms[6]), vk_fwd, vk_right, vk_up)
            if not self._running: break

            self._rw_step(P, _ms(step_ms[7]), vk_fwd, vk_up, vk_left)
            if not self._running: break

            # Step 8 : relâche Q brièvement puis reprend Z+↑+Q
            # Le keyup est absorbé dans le timer → pas de sleep additionnel
            _t8 = time.perf_counter()
            P._keyup(vk_left)
            with P._lock: P._vks.discard(vk_left)
            _elapsed8 = max(0, int((time.perf_counter() - _t8) * 1000))
            self._rw_step(P, max(1, _ms(step_ms[8]) - _elapsed8), vk_fwd, vk_up, vk_left)
            if not self._running: break

            self._rw_step(P, _ms(step_ms[9]), vk_fwd, vk_left)
            if not self._running: break

            self._rw_step(P, _ms(step_ms[10]), vk_fwd, vk_left, vk_up)
            if not self._running: break

            self._rw_step(P, _ms(step_ms[11]), vk_fwd, vk_left)
            if not self._running: break

            self._rw_step(P, _ms(step_ms[12]), vk_fwd, vk_left, vk_up)
            if not self._running: break

            self._rw_step(P, _ms(step_ms[13]), vk_fwd, vk_up)
            if not self._running: break

            self._rw_step(P, _ms(step_ms[14]), vk_fwd, vk_left)
            if not self._running: break

            self._rw_step(P, _ms(step_ms[15]), vk_fwd, vk_down)
            if not self._running: break

            self._rw_step(P, _ms(step_ms[16]), vk_fwd, vk_left)
            if not self._running: break

            self.sig_log.emit("Roadworks — release all...", "info")
            P.release_all()
            self._precise_sleep(step_ms[17])   # pause non scalée (courte)
            if not self._running: break

            P.press_add(vk_fwd)
            self._precise_sleep(step_ms[18])
            if not self._running: break

            P.transition(vk_fwd, vk_left)
            self._precise_sleep(step_ms[19])
            if not self._running: break

            laps_done += 1
            self.stats["roadworks_done"] += 1
            self._emit_stats()
            self.sig_log.emit(f"Roadworks — cycle {laps_done} ✓", "ok")

            # Food check at end of each cycle
            # Stopper le Pulser AVANT de manger pour éviter que les touches de mouvement
            # soient spammées pendant le menu nourriture (cause principale du bug de désync).
            if self._running:
                self.sig_log.emit("Roadworks — checking food...", "info")
                P.release_all()          # stoppe toutes les touches avant de manger
                time.sleep(0.015)        # laisse Roblox traiter le release
                last_food_key = self._check_and_eat()
                if not self._running:
                    break
                if last_food_key:
                    self.sig_log.emit(
                        f"Roadworks — un-equip food key '{last_food_key}' then resume Z+Q (step 19)",
                        "info",
                    )
                    self._focus_game()
                    self._sleep(200)
                    self._send_key(last_food_key)   # un-equip food item
                    self._sleep(150)
                    if not self._running:
                        break
                # Restore step-19 key state: Z + Q held together (nourriture mangée ou non)
                self.sig_log.emit("Roadworks — resuming step 19 (Z+Q)", "info")
                P.release_all()                 # garantit un état propre
                time.sleep(0.010)
                P.press_add(vk_fwd, vk_left)   # hold BOTH Z and Q
                time.sleep(0.020)
                self._precise_sleep(step_ms[19])
                P.release_all()                 # clean release before next cycle
                if not self._running:
                    break

        P.stop_all(); self._roadworks_pulser = None
        self.sig_log.emit("Roadworks — finished", "ok")

    def _selfish_v1_loop(self):
        c = self.cfg
        t1, t2 = c.get("DUR_GameTitle1","Roblox"), c.get("DUR_GameTitle2","Roblox")
        h1, h2 = self._resolve_dur_hwnd(t1, 1), self._resolve_dur_hwnd(t2, 2)
        if not h1: self.sig_log.emit("Durability — Window 1 not found!","error")
        if not h2: self.sig_log.emit("Durability — Window 2 not found!","error")

        def _i(k, d): return int(c.get(k, d))
        dur1_cx    = _i("DUR1_ClickX",200);  dur1_cy    = _i("DUR1_ClickY",108)
        dur1_tkey  = c.get("DUR1_TrainingKey","e")
        dur1_fcx   = _i("DUR1_FoodClickX",192); dur1_fcy = _i("DUR1_FoodClickY",180)
        dur1_foods = [c.get(f"DUR1_Food{i}Key","") for i in range(1,8)]
        dur1_hx    = _i("DUR1_HealthX",100);  dur1_hy   = _i("DUR1_HealthY",190)
        dur1_hcol  = c.get("DUR1_HealthColor","0x00FF00"); dur1_htol = _i("DUR1_HealthTol",30)
        dur1_sx    = _i("DUR1_StrengthX",280); dur1_sy  = _i("DUR1_StrengthY",108)
        dur1_skey  = c.get("DUR1_StrengthKey","r"); dur1_fskey = c.get("DUR1_FightStyleKey","f")
        dur2_fcx   = _i("DUR2_FoodClickX",192); dur2_fcy = _i("DUR2_FoodClickY",180)
        dur2_cx    = _i("DUR2_ClickX",200);     dur2_cy  = _i("DUR2_ClickY",108)
        dur2_foods = [c.get(f"DUR2_Food{i}Key","") for i in range(1,8)]
        dur2_stamx = _i("DUR2_StaminaX",300); dur2_stamy = _i("DUR2_StaminaY",108)
        dur2_stamcol = c.get("DUR2_StaminaColor","0x00BFFF"); dur2_stamtol = _i("DUR2_StaminaTol",30)
        dur2_fskey = c.get("DUR2_FightStyleKey","f")
        dur2_food_fx  = _i("DUR2_FoodX", _i("FOOD_X",200)); dur2_food_fy = _i("DUR2_FoodY", _i("FOOD_Y",970))
        dur2_food_col = c.get("DUR2_FoodColor", c.get("FOOD_Color","0xFF8C00"))
        dur2_food_tol = _i("DUR2_FoodTol", _i("FOOD_Tolerance",30))
        food_fx    = _i("FOOD_X",200); food_fy = _i("FOOD_Y",970)
        food_col   = c.get("FOOD_Color","0xFF8C00"); food_tol = _i("FOOD_Tolerance",30)

        self._phase = "Durability"; self.sig_phase.emit("Durability")
        self.sig_log.emit("Durability — started","ok")
        _lkw1 = [dur1_tkey]  # mutable ref for last_key_win1 — accessible depuis _check_food_win

        def _check_food_win(title, foods, fcx, fcy, hwnd, extra_key=None, fx=None, fy=None, fcol=None, ftol=None, win_slot=1):
            _fx   = fx   if fx   is not None else food_fx
            _fy   = fy   if fy   is not None else food_fy
            _fcol = fcol if fcol is not None else food_col
            _ftol = ftol if ftol is not None else food_tol
            if win_slot == 2 and self._win2_food_exhausted:
                return False
            if win_slot == 1:
                if self._is_food_available():
                    return False
                if self._is_food_block_pixel_present():
                    self.sig_log.emit("DUR — WIN1 food pixel absent but BLOCK pixel detected -> skip eating", "warn")
                    return False
                self.sig_log.emit("DUR — WIN1 food pixel absent -> eat", "info")
                self._focus_win(title, hwnd); self._sleep(200)
                _fpx  = int(c.get("FOOD_X", 200))
                _fpy  = int(c.get("FOOD_Y", 970))
                _fcol = c.get("FOOD_Color", "0xFF8C00")
                _ftol = int(c.get("FOOD_Tolerance", 30))
                _fclx = int(c.get("FOOD_CLICK_X", 960))
                _fcly = int(c.get("FOOD_CLICK_Y", 540))
                _fkeys = [c.get(f"Food{i}Key", "") for i in range(1, 7)]
                _fkeys = [k for k in _fkeys if k]
                if not _fkeys:
                    self.sig_log.emit("DUR — WIN1: no food key configured!", "warn")
                    return False
                for _fk in _fkeys:
                    if not self._running: break
                    self._send_key_in(title, _fk, hwnd); self._sleep(150)
                    self._glide_click_in(title, _fclx, _fcly, hwnd); self._sleep(300)
                    _waited = 0; _pixel_back = False
                    while self._running and _waited < 3000:
                        if self._pixel_match_screen(_fpx, _fpy, _fcol, _ftol):
                            _pixel_back = True; break
                        self._sleep(120); _waited += 120
                    if _pixel_back:
                        self.stats["food_eaten"] += 1; self._emit_stats()
                        self.sig_log.emit(f"DUR — WIN1 food consumed (key '{_fk}') v", "ok")
                        self._sleep(150); self._send_key_in(title, _fk, hwnd)
                        self.sig_log.emit(f"DUR — WIN1 reselect food key '{_fk}' (deselect)", "info")
                        self._sleep(150); return True
                    self._sleep(300)
                return False
            else:
                win2_food_enabled = bool(int(c.get("DUR_Win2FoodEnabled", 1)))
                if not win2_food_enabled: return False
                pixel_present = self._pixel_match_screen(_fx, _fy, _fcol, _ftol)
                if not pixel_present: return False
                self.sig_log.emit("DUR — WIN2 food pixel present -> pausing macro to eat", "info")
                self._focus_win(title, hwnd); self._sleep(300)
                result = self._eat_food_in_win(
                    title, foods, fcx, fcy, hwnd,
                    food_px=_fx, food_py=_fy, food_pcol=_fcol, food_ptol=_ftol
                )
                if result is False:
                    self._win2_food_exhausted = True
                    self.sig_log.emit("DUR — WIN2: no food in hotbar -> food loop skipped until restart", "warn")
                    return False
                if result is not None:
                    self._sleep(1500)
                    if extra_key:
                        self.sig_log.emit(f"DUR — WIN2 re-equip Fighting Style '{extra_key}'", "info")
                        self._send_key_in(title, extra_key, hwnd); self._sleep(400)
                    self._sleep(300); return True
                return False

        while self._running:
            self._wait_resume()
            if not self._running: break

            # ── Pré-cycle : vérification pixel food WIN2 ──────────────────────────────────────
            self.sig_log.emit("DUR — Pré-cycle : vérification pixel food WIN2", "info")
            if self._pixel_match_screen(dur2_food_fx, dur2_food_fy, dur2_food_col, dur2_food_tol):
                self.sig_log.emit("DUR — Pixel food WIN2 présent -> lancement loop food WIN2", "info")
                _pre_ate = _check_food_win(t2, dur2_foods, dur2_fcx, dur2_fcy, h2, dur2_fskey,
                                           fx=dur2_food_fx, fy=dur2_food_fy,
                                           fcol=dur2_food_col, ftol=dur2_food_tol, win_slot=2)
                if _pre_ate:
                    self.sig_log.emit("DUR — WIN2 food mangé (pré-cycle) v", "ok")
            if not self._running: break
            # ──────────────────────────────────────────────────────────────────────────────────

            self.sig_log.emit("DUR — Step 1 : spam clics Durability (700 ms)","info")
            self._focus_win(t1, h1)
            _dur1_t = time.time()
            while self._running and (time.time() - _dur1_t) < 0.70:
                _send_move_and_click(dur1_cx + random.randint(-2, 2), dur1_cy + random.randint(-2, 2))
                time.sleep(0.09)
            self._sleep(200)
            if not self._running: break

            self.sig_log.emit("DUR — Step 2 : touche Durability Training","info")
            self._send_key_in(t1, dur1_tkey, h1); _lkw1[0] = dur1_tkey; self._sleep(300)
            if not self._running: break

            self.sig_log.emit("DUR — Step 3: click food WIN1","info")
            self._glide_click_in(t1, dur1_fcx, dur1_fcy, h1); self._sleep(300)
            if not self._running: break

            self.sig_log.emit("DUR — Step 3b: unequip Durability Training","info")
            self._send_key_in(t1, dur1_tkey, h1); self._sleep(300)
            if not self._running: break

            self.sig_log.emit("DUR — Step 4 : spam clics WIN2 + pixels","info")
            health_gone = stamina_gone = False
            try:
                dura_train_duration = float(c.get("DUR_TrainingDuration", 18.0))
            except (ValueError, TypeError):
                dura_train_duration = 18.0
            spam_end = time.time() + dura_train_duration
            try:
                PIXEL_GONE_DELAY = float(c.get("DUR_PixelGoneDelay", 0.7))
            except (ValueError, TypeError):
                PIXEL_GONE_DELAY = 0.7
            health_miss_since = None; stamina_miss_since = None
            pixel_stop_clicks = False  # pixel gone -> stop clicks but let timer finish
            self._focus_win(t2, h2)
            _send_move_and_click(dur2_cx, dur2_cy)  # initial move + first click
            click_counter = 1
            while self._running and time.time() < spam_end:
                self._wait_resume()
                if not self._running: break
                now = time.time()
                if not health_gone:
                    if not self._pixel_match_screen(dur1_hx, dur1_hy, dur1_hcol, dur1_htol):
                        health_gone = True; self.sig_log.emit("DUR — Health gone!","warn")
                        self.sig_pixel_status.emit("health", False)
                        pixel_stop_clicks = True
                if not stamina_gone:
                    if not self._pixel_match_screen(dur2_stamx, dur2_stamy, dur2_stamcol, dur2_stamtol):
                        if stamina_miss_since is None: stamina_miss_since = now
                        elif now - stamina_miss_since >= PIXEL_GONE_DELAY:
                            stamina_gone = True; self.sig_log.emit("DUR — Stamina gone!","warn")
                            self.sig_pixel_status.emit("stamina", False)
                            pixel_stop_clicks = True
                    else:
                        stamina_miss_since = None  # pixel back (flash) — reset timer
                if pixel_stop_clicks:
                    remaining_s = spam_end - time.time()
                    if remaining_s <= 2.0:
                        # Moins de 2s restantes → sortir immédiatement, training presque fini
                        self.sig_log.emit(
                            f"DUR — Pixel gone, {remaining_s:.1f}s remaining (<2s) → exit immediately", "warn"
                        )
                        break
                    else:
                        # Plus de 2s restantes → annuler training proprement sur WIN1 puis continuer
                        self.sig_log.emit(
                            f"DUR — Pixel gone, {remaining_s:.1f}s remaining (>2s) → cancel WIN1 training", "warn"
                        )
                        # Basculer sur WIN1, appuyer durability key pour déséquiper, clic, re-appui
                        self._focus_win(t1, h1)
                        self._sleep(150)
                        self._send_key_in(t1, dur1_tkey, h1)   # déséquipe durability training
                        self._sleep(200)
                        self._glide_click_in(t1, dur1_cx, dur1_cy, h1)  # clic sur l'écran WIN1
                        self._sleep(200)
                        self._send_key_in(t1, dur1_tkey, h1)   # re-appui training key
                        self._sleep(150)
                        self.sig_log.emit("DUR — Training canceled on WIN1 → continue", "info")
                        break
                if not pixel_stop_clicks:
                    click_counter += 1
                    _send_click_no_move()
                    if click_counter % 5 == 0:
                        _send_mouse_input(MOUSEEVENTF_RIGHTDOWN)
                        time.sleep(random.uniform(0.05, 0.09))
                        _send_mouse_input(MOUSEEVENTF_RIGHTUP)
            self._focus_win(t1, h1)
            self._human_glide(dur1_cx, dur1_cy)
            try:
                post_train_delay = int(float(c.get("DUR_PostTrainingDelay", 0.5)) * 1000)
            except (ValueError, TypeError):
                post_train_delay = 500
            self.sig_log.emit(f"DUR — Pause {post_train_delay}ms avant Strength training...","info")
            self._sleep(post_train_delay)
            if not self._running: break

            # ── Blocage clics droits post-training ─────────────────────────────────────────────
            no_rclick_enabled = int(c.get("DUR_NoRClickEnabled", 0))
            if no_rclick_enabled:
                try:
                    no_rclick_duration = float(c.get("DUR_NoRClickDuration", 3.0))
                except (ValueError, TypeError):
                    no_rclick_duration = 3.0
                self.sig_log.emit(f"DUR — Right-clicks blocked {no_rclick_duration:.1f}s (post-training)", "info")
                block_end = time.time() + no_rclick_duration
                while self._running and time.time() < block_end:
                    self._sleep(50)
                self.sig_log.emit("DUR — Right-clicks restored", "info")

            self.sig_log.emit("DUR — Step 5: search food","info")
            w2a = _check_food_win(t2, dur2_foods, dur2_fcx, dur2_fcy, h2, dur2_fskey,
                                  fx=dur2_food_fx, fy=dur2_food_fy, fcol=dur2_food_col, ftol=dur2_food_tol, win_slot=2)
            w1a = _check_food_win(t1, dur1_foods, dur1_fcx, dur1_fcy, h1, _lkw1[0], win_slot=1)
            # Repress the last WIN1 key after food to avoid breaking the training
            if w1a and _lkw1[0] and self._running:
                self.sig_log.emit(f"DUR — Repress '{_lkw1[0]}' after food step 5", "info")
                self._send_key_in(t1, _lkw1[0], h1); self._sleep(150)
            if not self._running: break

            survivor_mode  = bool(int(c.get("DUR_SurvivorMode",0)))
            strength_loops = 2 if survivor_mode else 3
            self.sig_log.emit(f"DUR — Boucle Strength {strength_loops}x","info")

            for li in range(strength_loops):
                if not self._running: break
                self.sig_log.emit(f"DUR — Boucle Strength [{li+1}/{strength_loops}]","info")

                self.sig_log.emit("DUR — spam clics Strength (1000 ms)","info")
                self._focus_win(t1, h1)
                _str_t = time.time()
                while self._running and (time.time() - _str_t) < 1.00:
                    _send_move_and_click(dur1_sx + random.randint(-2, 2), dur1_sy + random.randint(-2, 2))
                    time.sleep(0.09)
                self._sleep(200)
                if not self._running: break
                self._send_key_in(t1, dur1_skey, h1); _lkw1[0] = dur1_skey; self._sleep(150)
                self._glide_click_in(t1, 411, 334, h1); self._sleep(300)
                if not self._running: break
                self._lclick_in(t1, h1); self._sleep(300)
                if not self._running: break
                self._send_key_in(t1, dur1_skey, h1); self._sleep(300)
                if not self._running: break

                self._focus_win(t1, h1); self._human_glide(dur1_fcx, dur1_fcy); self._rclick(); self._sleep(300)
                if not self._running: break
                self._send_key_in(t1, dur1_fskey, h1); _lkw1[0] = dur1_fskey; self._sleep(300)
                if not self._running: break

                self.sig_log.emit(f"DUR — Step 10 : 30s spam WIN1 (loop {li+1})","info")
                self._focus_win(t1, h1); spam_end_str = time.time() + 30.0
                while self._running and time.time() < spam_end_str:
                    self._wait_resume()
                    if not self._running: break
                    for _lc in range(5):
                        if not self._running or time.time() >= spam_end_str: break
                        self._lclick_in(t1, h1)
                        if _lc < 4:
                            self._sleep(1120)
                    if not self._running or time.time() >= spam_end_str: break
                    self._sleep(random.randint(650, 750))
                    self._rclick_in(t1, h1); self._sleep(1500)
                if not self._running: break

                self._send_key_in(t1, dur1_fskey, h1); _lkw1[0] = dur1_fskey; self._sleep(300)
                if not self._running: break

                self.sig_log.emit(f"DUR — Step 12 : nourriture (loop {li+1})","info")
                ate_w2 = _check_food_win(t2, dur2_foods, dur2_fcx, dur2_fcy, h2, dur2_fskey,
                                fx=dur2_food_fx, fy=dur2_food_fy, fcol=dur2_food_col, ftol=dur2_food_tol, win_slot=2)
                ate_w1 = _check_food_win(t1, dur1_foods, dur1_fcx, dur1_fcy, h1, _lkw1[0], win_slot=1)
                # Réappuyer la dernière touche active sur WIN1 après food pour ne pas casser la macro
                if ate_w1 and _lkw1[0] and self._running:
                    self.sig_log.emit(f"DUR — STR loop repress '{_lkw1[0]}' after food", "info")
                    self._send_key_in(t1, _lkw1[0], h1); self._sleep(150)
                if not self._running: break

            self.stats["durability_done"] += 1; self._emit_stats()
            self.sig_log.emit(f"DUR — Cycle {self.stats['durability_done']} ✓","ok")
            self._sleep(500)

        self.sig_log.emit("Durability — finished","ok")

    def _selfish_v3_loop(self):
        """Selfish V3 macro: alternates STR (win2) / DUR (win1) training with food detection."""
        c = self.cfg
        t1, t2 = c.get("DUR_GameTitle1", "Roblox"), c.get("DUR_GameTitle2", "Roblox")
        h1 = self._resolve_dur_hwnd(t1, 1)
        h2 = self._resolve_dur_hwnd(t2, 2)
        if not h1: self.sig_log.emit("SV3 — Window 1 not found!", "error")
        if not h2: self.sig_log.emit("SV3 — Window 2 not found!", "error")

        def _i(k, d): return int(c.get(k, d))
        def _f(k, d):
            try: return float(c.get(k, d))
            except (ValueError, TypeError): return d

        # ── Config values ─────────────────────────────────────────────────────
        # ── Training buy positions = coordonnées des points K ─────────────────
        # Rouge  = STR WIN1  (DUR1_StrengthX/Y)
        # Vert   = DUR WIN1  (DUR1_ClickX/Y)
        # Orange = STR WIN2  (SV3_W2_StrStatX/Y)
        # Bleu   = DUR WIN2  (SV3_W2_DurBuyX/Y)
        w1_str_buy_x  = _i("DUR1_StrengthX",   280); w1_str_buy_y  = _i("DUR1_StrengthY",   108)
        w1_dur_buy_x  = _i("DUR1_ClickX",      200); w1_dur_buy_y  = _i("DUR1_ClickY",      108)
        w2_str_buy_x  = _i("SV3_W2_StrStatX",  280); w2_str_buy_y  = _i("SV3_W2_StrStatY",  108)
        w2_dur_buy_x  = _i("SV3_W2_DurBuyX",   200); w2_dur_buy_y  = _i("SV3_W2_DurBuyY",   108)
        # ── Strength stat click (après avoir équipé le training strength) ──────
        # WIN1 — clic à faire après équipement du training STR sur WIN1
        w1_str_stat_x = _i("SV3_W1_StrStatClickX", _i("DUR1_StrengthX", 280))
        w1_str_stat_y = _i("SV3_W1_StrStatClickY", _i("DUR1_StrengthY", 108))
        # WIN2 — clic à faire après équipement du training STR sur WIN2 (même position que orange par défaut)
        w2_str_stat_x = _i("SV3_W2_StrStatClickX", _i("SV3_W2_StrStatX", 280))
        w2_str_stat_y = _i("SV3_W2_StrStatClickY", _i("SV3_W2_StrStatY", 108))
        # WIN1 durability stat click (green K point — DUR1_ClickX/Y)
        w1_dur_stat_x = _i("DUR1_ClickX",     200); w1_dur_stat_y = _i("DUR1_ClickY",     108)
        # Keys
        w1_dur_tkey   = c.get("SV3_W1_DurTrainingKey", "e")
        w1_str_tkey   = c.get("SV3_W1_StrTrainingKey", "r")
        w2_str_tkey   = c.get("SV3_W2_StrTrainingKey", "r")
        w2_dur_tkey   = c.get("SV3_W2_DurTrainingKey", "e")
        w2_fs_key     = c.get("SV3_W2_FightStyleKey",  "f")
        # Durations
        str_spam_dur   = _f("SV3_StrSpamDuration", 18.0)
        dur_spam_dur   = _f("SV3_DurSpamDuration", 18.0)
        cycle_end_ms   = _i("SV3_CycleEndDelay", 1000)
        phase_trans_ms = _i("SV3_PhaseTransitionDelay", 0)
        str_click_ms   = _i("SV3_StrClickSpamMs", 700)   # durée spam pour lancer le training STR
        # Slow M1s flags
        w1_slow_m1s = bool(int(c.get("SV3_W1_SlowM1s", 0)))
        w2_slow_m1s = bool(int(c.get("SV3_W2_SlowM1s", 0)))
        # Slow M1s timings — reprend les paramètres STR sauf l'intervalle L-click qui est configurable
        try: _sm_lclick_interval = int(float(c.get("SV3_SlowM1sClickMs",      1154)))
        except: _sm_lclick_interval = 1154
        try: _sm_rclick_wait     = int(float(c.get("SV3_SlowM1sRClickWaitMs", 1000)))
        except: _sm_rclick_wait = 1000
        try: _sm_rclick_to_l    = int(float(c.get("SV3_SlowM1sRClickToLMs",   300)))
        except: _sm_rclick_to_l = 300
        try: _sm_clicks_series  = int(c.get("STR_ClicksPerSeries",            5))
        except: _sm_clicks_series = 5
        # Positions du spam de clics (combat)
        w1_spam_x = _i("SV3_W1_SpamX", 500); w1_spam_y = _i("SV3_W1_SpamY", 400)
        w2_spam_x = _i("SV3_W2_SpamX", 500); w2_spam_y = _i("SV3_W2_SpamY", 400)
        # WIN1 health pixel (phase 2)
        w1_h2_x   = _i("SV3_W1_Health2X", 100); w1_h2_y   = _i("SV3_W1_Health2Y", 190)
        w1_h2_col = c.get("SV3_W1_Health2Color", "0x00FF00"); w1_h2_tol = _i("SV3_W1_Health2Tol", 30)
        # WIN1 health pixel phase 1 (reuse DUR1 health)
        w1_h1_x   = _i("DUR1_HealthX", 100); w1_h1_y   = _i("DUR1_HealthY", 190)
        w1_h1_col = c.get("DUR1_HealthColor", "0x00FF00"); w1_h1_tol = _i("DUR1_HealthTol", 30)
        # WIN2 health pixel (phase 1 — WIN2 trains Strength while WIN1 trains Durability)
        w2_h_x    = _i("SV3_W2_HealthX", 100); w2_h_y    = _i("SV3_W2_HealthY", 190)
        w2_h_col  = c.get("SV3_W2_HealthColor", "0x00FF00"); w2_h_tol  = _i("SV3_W2_HealthTol", 30)
        w2_health_enabled = bool(w2_h_col and w2_h_col.strip() not in ("", "0x000000") and w2_h_x > 0 and w2_h_y > 0)
        # WIN2 stamina pixel (phase 1 — if WIN2 stamina disappears → stop spam)
        w2_st_x   = _i("SV3_W2_StaminaX", 100); w2_st_y   = _i("SV3_W2_StaminaY", 200)
        w2_st_col = c.get("SV3_W2_StaminaColor", "0x00BFFF"); w2_st_tol = _i("SV3_W2_StaminaTol", 30)
        w2_stamina_enabled = bool(w2_st_col and w2_st_col.strip() not in ("", "0x000000") and w2_st_x > 0 and w2_st_y > 0)
        # WIN1 stamina pixel (phase 2 — if WIN1 stamina disappears → stop spam)
        w1_st2_x   = _i("SV3_W1_Stamina2X", 100); w1_st2_y   = _i("SV3_W1_Stamina2Y", 200)
        w1_st2_col = c.get("SV3_W1_Stamina2Color", "0x00BFFF"); w1_st2_tol = _i("SV3_W1_Stamina2Tol", 30)
        w1_stamina2_enabled = bool(w1_st2_col and w1_st2_col.strip() not in ("", "0x000000") and w1_st2_x > 0 and w1_st2_y > 0)
        # WIN2 food
        w2_food_x   = _i("SV3_W2_FoodX", 200); w2_food_y   = _i("SV3_W2_FoodY", 970)
        w2_food_col = c.get("SV3_W2_FoodColor", "0xFF8C00"); w2_food_tol = _i("SV3_W2_FoodTol", 30)
        w2_fcx      = _i("SV3_W2_FoodClickX", 192); w2_fcy = _i("SV3_W2_FoodClickY", 180)
        w2_foods    = [c.get(f"SV3_W2_Food{i}Key", "") for i in range(1, 8)]
        # WIN1 food (reuse global FOOD settings)
        w1_food_x   = _i("FOOD_X", 200); w1_food_y   = _i("FOOD_Y", 970)
        w1_food_col = c.get("FOOD_Color", "0xFF8C00"); w1_food_tol = _i("FOOD_Tolerance", 30)
        w1_fcx      = _i("FOOD_CLICK_X", 960); w1_fcy = _i("FOOD_CLICK_Y", 540)
        w1_foods    = [c.get(f"Food{i}Key", "") for i in range(1, 7)]

        self._phase = "Selfish V3"; self.sig_phase.emit("Selfish V3")
        self.sig_log.emit("Selfish V3 — started", "ok")

        # ── Last key tracker for WIN2 (mutable ref) ──────────────────────────
        _lkw2 = [w2_fs_key]  # default: fighting style

        # ── Helpers ───────────────────────────────────────────────────────────
        def _focus1():
            self._focus_win(t1, h1); self._sleep(120)

        def _focus2():
            self._focus_win(t2, h2); self._sleep(120)

        def _spam_buy(title, hwnd, bx, by, dur_s=0.70):
            """Spam-click buy button for ~dur_s seconds."""
            self._focus_win(title, hwnd); self._sleep(100)
            t_end = time.time() + dur_s
            while self._running and time.time() < t_end:
                _send_move_and_click(bx + random.randint(-2, 2), by + random.randint(-2, 2))
                time.sleep(0.09)
            self._sleep(200)

        def _is_w2_food_block():
            for bx_k, by_k, bc_k, bt_k in [
                ("SV3_W2_FoodBlock1X", "SV3_W2_FoodBlock1Y", "SV3_W2_FoodBlock1Color", "SV3_W2_FoodBlock1Tol"),
                ("SV3_W2_FoodBlock2X", "SV3_W2_FoodBlock2Y", "SV3_W2_FoodBlock2Color", "SV3_W2_FoodBlock2Tol"),
            ]:
                bx = c.get(bx_k, ""); by = c.get(by_k, ""); bcol = c.get(bc_k, "")
                if bx == "" or by == "" or bcol == "": continue
                try:
                    if self._pixel_match_screen(int(bx), int(by), bcol, int(c.get(bt_k, 30))):
                        return True
                except ValueError:
                    continue
            return False

        def _check_food_w2():
            """Check & eat for WIN2 using SV3 food pixel."""
            if self._sv3_w2_food_exhausted: return False
            pixel_present = self._pixel_match_screen(w2_food_x, w2_food_y, w2_food_col, w2_food_tol)
            if pixel_present: return False  # pixel present = food OK, nothing to do
            if _is_w2_food_block():
                self.sig_log.emit("SV3 \u2014 WIN2 food pixel absent but BLOCK detected -> skip", "warn")
                return False
            self.sig_log.emit("SV3 \u2014 WIN2 food pixel absent -> eat", "info")
            _focus2()
            result = self._eat_food_in_win(
                t2, w2_foods, w2_fcx, w2_fcy, h2,
                food_px=w2_food_x, food_py=w2_food_y,
                food_pcol=w2_food_col, food_ptol=w2_food_tol
            )
            if result is False:
                self._sv3_w2_food_exhausted = True
                self.sig_log.emit("SV3 — WIN2: no food left -> food loop disabled", "warn")
                return False
            if result:
                self._sleep(1500)
                self.sig_log.emit("SV3 — WIN2 food consumed, food key stays equipped", "info")
                return True
            return False

        def _check_food_w1():
            """Check & eat for WIN1 using global FOOD settings."""
            if self._is_food_available(): return False
            if self._is_food_block_pixel_present():
                self.sig_log.emit("SV3 — WIN1 food pixel missing but BLOCK -> skip", "warn")
                return False
            self.sig_log.emit("SV3 — WIN1 food pixel missing -> eat", "info")
            _focus1()
            valid = [k for k in w1_foods if k]
            if not valid: return False
            for fk in valid:
                if not self._running: break
                self._send_key_in(t1, fk, h1); self._sleep(150)
                self._glide_click_in(t1, w1_fcx, w1_fcy, h1); self._sleep(300)
                waited = 0; back = False
                while self._running and waited < 3000:
                    if self._pixel_match_screen(w1_food_x, w1_food_y, w1_food_col, w1_food_tol):
                        back = True; break
                    self._sleep(120); waited += 120
                if back:
                    self.stats["food_eaten"] += 1; self._emit_stats()
                    self.sig_log.emit(f"SV3 — WIN1 food consumed ('{fk}') v", "ok")
                    self._sleep(150); self._send_key_in(t1, fk, h1); self._sleep(150)
                    return True
                self._sleep(300)
            return False

        def _check_foods():
            """Check food for both windows."""
            _check_food_w2()
            if not self._running: return
            _check_food_w1()

        # ── Food check au lancement ───────────────────────────────────────────
        self.sig_log.emit("SV3 — Lancement: vérification food WIN2 + WIN1", "info")
        _check_foods()
        if not self._running: return

        # ── Main loop ─────────────────────────────────────────────────────────
        while self._running:
            self._wait_resume()
            if not self._running: break

            # ── PRE-CYCLE food check ──────────────────────────────────────────
            self.sig_log.emit("SV3 — Pre-cycle food check (WIN2 + WIN1)", "info")
            _check_foods()
            if not self._running: break

            # ═════════════════════════════════════════════════════════════════
            # PHASE 1 — WIN2 trains Strength, WIN1 trains Durability
            # ═════════════════════════════════════════════════════════════════
            self.sig_log.emit("SV3 — Phase 1 start: WIN2 buys Strength", "info")

            # WIN2 buys Strength training (orange point)
            _spam_buy(t2, h2, w2_str_buy_x, w2_str_buy_y)
            if not self._running: break

            # WIN1 buys Durability training (green point)
            self.sig_log.emit("SV3 — WIN1 buys Durability", "info")
            _spam_buy(t1, h1, w1_dur_buy_x, w1_dur_buy_y)
            if not self._running: break

            # WIN2: equip Strength training key
            self.sig_log.emit("SV3 — WIN2: equip Strength training", "info")
            _lkw2[0] = w2_str_tkey
            _focus2(); self._send_key(w2_str_tkey); self._sleep(300)
            if not self._running: break

            # WIN2: spam clics sur Strength stat (assure la détection par Roblox)
            self.sig_log.emit(f"SV3 — WIN2: spam Strength stat click ({str_click_ms}ms)", "info")
            _focus2()
            self._sleep(150)
            _t_str_end = time.time() + str_click_ms / 1000.0
            while self._running and time.time() < _t_str_end:
                _send_move_and_click(w2_str_stat_x + random.randint(-2, 2),
                                      w2_str_stat_y + random.randint(-2, 2))
                time.sleep(0.09)
            self._sleep(200)
            if not self._running: break

            # WIN2: equip fighting style
            self.sig_log.emit(f"SV3 — WIN2: equip fighting style '{w2_fs_key}'", "info")
            _lkw2[0] = w2_fs_key
            _focus2(); self._send_key(w2_fs_key); self._sleep(300)
            if not self._running: break

            # WIN1: durability activation — équipe, clic pour lancer, déséquipe
            self.sig_log.emit("SV3 — WIN1: durability activation (equip → click → unequip)", "info")
            _focus1(); self._send_key(w1_dur_tkey); self._sleep(300)
            if not self._running: break
            _send_move_and_click(w1_dur_stat_x + random.randint(-2, 2),
                                  w1_dur_stat_y + random.randint(-2, 2))
            self._sleep(300)
            if not self._running: break
            _focus1(); self._send_key(w1_dur_tkey); self._sleep(300)
            if not self._running: break

            # WIN2: spam left+right clicks for str_spam_dur seconds (position fixe win2)
            self.sig_log.emit(f"SV3 — WIN2: spam L+R clicks ({str_spam_dur:.1f}s)", "info")
            _focus2()
            user32.SetCursorPos(w2_spam_x, w2_spam_y)
            time.sleep(0.05)
            spam_end = time.time() + str_spam_dur
            health_gone_p1 = False
            stamina_gone_p1 = False
            click_ctr = 0
            while self._running and time.time() < spam_end:
                self._wait_resume()
                if not self._running: break
                # Phase 1 : détection health WIN1 uniquement
                if not health_gone_p1:
                    if not self._pixel_match_screen(w1_h1_x, w1_h1_y, w1_h1_col, w1_h1_tol):
                        health_gone_p1 = True
                        self.sig_log.emit("SV3 — Phase 1: WIN1 health gone!", "warn")
                        self.sig_pixel_status.emit("health", False)
                        break
                # Phase 1 : détection stamina WIN2 (si WIN2 stamina disparaît → stop spam)
                if w2_stamina_enabled and not stamina_gone_p1:
                    if not self._pixel_match_screen(w2_st_x, w2_st_y, w2_st_col, w2_st_tol):
                        stamina_gone_p1 = True
                        self.sig_log.emit("SV3 — Phase 1: WIN2 stamina gone!", "warn")
                        self.sig_pixel_status.emit("stamina", False)
                        break
                if w2_slow_m1s:
                    # Slow M1s : série de L-clicks espacés + R-click (timings STR)
                    for _lc in range(_sm_clicks_series):
                        if not self._running or time.time() >= spam_end: break
                        self._lclick()
                        if _lc < _sm_clicks_series - 1:
                            self._sleep(_sm_lclick_interval)
                    if not self._running or time.time() >= spam_end: break
                    self._sleep(_sm_rclick_wait)
                    if not self._running or time.time() >= spam_end: break
                    _send_mouse_input(MOUSEEVENTF_RIGHTDOWN)
                    time.sleep(random.uniform(0.05, 0.09))
                    _send_mouse_input(MOUSEEVENTF_RIGHTUP)
                    self._sleep(_sm_rclick_to_l)
                else:
                    self._lclick()
                    click_ctr += 1
                    if click_ctr % 5 == 0:
                        _send_mouse_input(MOUSEEVENTF_RIGHTDOWN)
                        time.sleep(random.uniform(0.05, 0.09))
                        _send_mouse_input(MOUSEEVENTF_RIGHTUP)
                    time.sleep(0.06)
            if not self._running: break

            self.sig_log.emit("SV3 — Phase 1 spam done", "info")

            # Délai de transition entre phases (attend que le training le plus long se finisse)
            if phase_trans_ms > 0:
                self.sig_log.emit(f"SV3 — Transition delay {phase_trans_ms}ms (attente fin training)", "info")
                self._sleep(phase_trans_ms)
            if not self._running: break

            # ── PRE-PHASE 2 food check ────────────────────────────────────────
            self.sig_log.emit("SV3 — Pre-phase 2 food check (WIN2 + WIN1)", "info")
            _check_foods()
            if not self._running: break

            # ═════════════════════════════════════════════════════════════════
            # PHASE 2 — WIN2 trains Durability, WIN1 trains Strength
            # ═════════════════════════════════════════════════════════════════
            self.sig_log.emit("SV3 — Phase 2 start: WIN2 unequip FS, buys Durability", "info")

            # WIN2: unequip fighting style before buying
            _focus2(); self._send_key(w2_fs_key); self._sleep(300)
            if not self._running: break

            # WIN2 buys Durability training (blue point)
            _spam_buy(t2, h2, w2_dur_buy_x, w2_dur_buy_y)
            if not self._running: break

            # WIN1 buys Strength training (red point)
            self.sig_log.emit("SV3 — WIN1 buys Strength", "info")
            _spam_buy(t1, h1, w1_str_buy_x, w1_str_buy_y)
            if not self._running: break

            # WIN1: equip Strength training key
            self.sig_log.emit("SV3 — WIN1: equip Strength training", "info")
            _focus1(); self._send_key(w1_str_tkey); self._sleep(300)
            if not self._running: break

            # WIN1: spam clics sur Strength stat (assure la détection par Roblox)
            self.sig_log.emit(f"SV3 — WIN1: spam Strength stat click ({str_click_ms}ms)", "info")
            _focus1()
            self._sleep(150)
            _t_str2_end = time.time() + str_click_ms / 1000.0
            while self._running and time.time() < _t_str2_end:
                _send_move_and_click(w1_str_stat_x + random.randint(-2, 2),
                                      w1_str_stat_y + random.randint(-2, 2))
                time.sleep(0.09)
            self._sleep(200)
            if not self._running: break

            # WIN1: equip fighting style
            _focus1(); self._send_key(c.get("DUR1_FightStyleKey", "f")); self._sleep(300)
            if not self._running: break

            # WIN2: durability activation — équipe, clic pour lancer, déséquipe
            self.sig_log.emit("SV3 — WIN2: durability activation (equip → click → unequip)", "info")
            _lkw2[0] = w2_dur_tkey
            _focus2(); self._sleep(200)
            if not self._running: break
            self._send_key(w2_dur_tkey); self._sleep(300)
            if not self._running: break
            _send_move_and_click(w2_dur_buy_x + random.randint(-2, 2),
                                  w2_dur_buy_y + random.randint(-2, 2))
            self._sleep(200)
            if not self._running: break
            _lkw2[0] = w2_fs_key
            self._send_key(w2_dur_tkey); self._sleep(300)
            if not self._running: break

            # WIN1: spam left+right clicks for dur_spam_dur seconds (position fixe win1)
            self.sig_log.emit(f"SV3 — WIN1: spam L+R clicks ({dur_spam_dur:.1f}s)", "info")
            _focus1()
            user32.SetCursorPos(w1_spam_x, w1_spam_y)
            time.sleep(0.05)
            spam_end = time.time() + dur_spam_dur
            w2_health_gone_p2 = False
            w1_stamina_gone_p2 = False
            click_ctr = 0
            while self._running and time.time() < spam_end:
                self._wait_resume()
                if not self._running: break
                # Phase 2 : détection health WIN2 uniquement
                if w2_health_enabled and not w2_health_gone_p2:
                    if not self._pixel_match_screen(w2_h_x, w2_h_y, w2_h_col, w2_h_tol):
                        w2_health_gone_p2 = True
                        self.sig_log.emit("SV3 — Phase 2: WIN2 health gone!", "warn")
                        self.sig_pixel_status.emit("health2", False)
                        break
                # Phase 2 : détection stamina WIN1 (si WIN1 stamina disparaît → stop spam)
                if w1_stamina2_enabled and not w1_stamina_gone_p2:
                    if not self._pixel_match_screen(w1_st2_x, w1_st2_y, w1_st2_col, w1_st2_tol):
                        w1_stamina_gone_p2 = True
                        self.sig_log.emit("SV3 — Phase 2: WIN1 stamina gone!", "warn")
                        self.sig_pixel_status.emit("stamina", False)
                        break
                if w1_slow_m1s:
                    # Slow M1s : série de L-clicks espacés + R-click (timings STR)
                    for _lc in range(_sm_clicks_series):
                        if not self._running or time.time() >= spam_end: break
                        self._lclick()
                        if _lc < _sm_clicks_series - 1:
                            self._sleep(_sm_lclick_interval)
                    if not self._running or time.time() >= spam_end: break
                    self._sleep(_sm_rclick_wait)
                    if not self._running or time.time() >= spam_end: break
                    _send_mouse_input(MOUSEEVENTF_RIGHTDOWN)
                    time.sleep(random.uniform(0.05, 0.09))
                    _send_mouse_input(MOUSEEVENTF_RIGHTUP)
                    self._sleep(_sm_rclick_to_l)
                else:
                    self._lclick()
                    click_ctr += 1
                    if click_ctr % 5 == 0:
                        _send_mouse_input(MOUSEEVENTF_RIGHTDOWN)
                        time.sleep(random.uniform(0.05, 0.09))
                        _send_mouse_input(MOUSEEVENTF_RIGHTUP)
                    time.sleep(0.06)
            if not self._running: break

            self.sig_log.emit("SV3 — Phase 2 spam done", "info")

            # WIN1: re-appui fighting style après spam phase 2
            w1_fs_key = c.get("DUR1_FightStyleKey", "f")
            self.sig_log.emit(f"SV3 — WIN1: re-equip fighting style '{w1_fs_key}' après spam", "info")
            _focus1(); self._send_key(w1_fs_key); self._sleep(300)
            if not self._running: break

            # ── End of cycle ─────────────────────────────────────────────────
            self.stats["durability_done"] += 1; self._emit_stats()
            self.sig_log.emit(f"SV3 — Cycle {self.stats['durability_done']} complete v", "ok")

            if cycle_end_ms > 0:
                self.sig_log.emit(f"SV3 — End-cycle pause {cycle_end_ms}ms", "info")
                self._sleep(cycle_end_ms)

        self.sig_log.emit("Selfish V3 — finished", "ok")


    def _strength_loop(self):
        c = self.cfg
        title = c.get("GameTitle", "Roblox")
        hwnd  = self._get_hwnd()

        def _i(k, d): return int(c.get(k, d))

        str_sx      = _i("STR_StrengthX",      280)
        str_sy      = _i("STR_StrengthY",      108)
        str_skey    = c.get("STR_StrengthKey",    "r")
        str_fskey   = c.get("STR_FightStyleKey",  "f")
        str_fcx     = _i("STR_FoodClickX",     192)
        str_fcy     = _i("STR_FoodClickY",     180)
        str_foods   = [c.get(f"STR_Food{i}Key", "") for i in range(1, 8)]
        str_food_fx = _i("STR_FoodX",  200)
        str_food_fy = _i("STR_FoodY",  970)
        str_food_col= c.get("STR_FoodColor",  "0xFF8C00")
        str_food_tol= _i("STR_FoodTol", 30)

        try: lclick_interval_ms      = int(float(c.get("STR_LClickInterval",      1154)))
        except: lclick_interval_ms   = 1154
        try: rclick_wait_ms          = int(float(c.get("STR_RClickWait",          1000)))
        except: rclick_wait_ms       = 1000
        try: rclick_to_lclick_ms     = int(float(c.get("STR_RClickToLClickDelay", 300)))
        except: rclick_to_lclick_ms  = 300
        try: training_duration       = float(c.get("STR_TrainingDuration",        30.0))
        except: training_duration    = 30.0
        try: clicks_per_series       = int(c.get("STR_ClicksPerSeries",           5))
        except: clicks_per_series    = 5

        str_stamx   = _i("STR_StaminaX",   0)
        str_stamy   = _i("STR_StaminaY",   0)
        str_stamcol = c.get("STR_StaminaColor", "")
        str_stamtol = _i("STR_StaminaTol",  30)
        try: pixel_gone_delay = float(c.get("STR_PixelGoneDelay", 0.7))
        except: pixel_gone_delay = 0.7
        stamina_enabled = bool(
            str_stamcol and str_stamcol.strip() not in ("", "0x000000")
            and str_stamx > 0 and str_stamy > 0
        )

        self._phase = "Strength"; self.sig_phase.emit("Strength")
        self.sig_log.emit("Strength — started", "ok")
        last_key = str_skey

        while self._running:
            self._wait_resume()
            if not self._running: break

            self.sig_log.emit("STR — Step 1: Strength click", "info")
            self._glide_click(str_sx + random.randint(-3,3), str_sy + random.randint(-2,2))
            self._sleep(300)
            if not self._running: break

            self.sig_log.emit("STR — Step 2: Strength Training key", "info")
            self._send_key(str_skey); last_key = str_skey; self._sleep(150)
            if not self._running: break

            self._glide_click(411 + random.randint(-3,3), 334 + random.randint(-2,2)); self._sleep(300)
            if not self._running: break
            self._lclick(); self._sleep(300)
            if not self._running: break
            self._send_key(str_skey); self._sleep(300)
            if not self._running: break

            self._human_glide(str_fcx, str_fcy); self._rclick(); self._sleep(300)
            if not self._running: break
            self._send_key(str_fskey); last_key = str_fskey; self._sleep(300)
            if not self._running: break

            self.sig_log.emit(f"STR — Spam {training_duration:.0f}s (interval {lclick_interval_ms}ms)", "info")
            self._focus_game()
            spam_end = time.time() + training_duration
            stamina_miss_since = None
            stamina_stopped    = False

            while self._running and time.time() < spam_end:
                self._wait_resume()
                if not self._running: break

                if stamina_enabled and not stamina_stopped:
                    now = time.time()
                    if not self._pixel_match_screen(str_stamx, str_stamy, str_stamcol, str_stamtol):
                        if stamina_miss_since is None:
                            stamina_miss_since = now
                        elif now - stamina_miss_since >= pixel_gone_delay:
                            stamina_stopped = True
                            remaining_s = spam_end - now
                            self.sig_log.emit(
                                f"STR — Stamina trop basse ! Clics stoppés, "
                                f"attente fin training ({remaining_s:.1f}s)...", "warn")
                            self._sleep(max(0, int(remaining_s * 1000)))
                            break
                    else:
                        stamina_miss_since = None

                if stamina_stopped:
                    break

                for _lc in range(clicks_per_series):
                    if not self._running or time.time() >= spam_end: break
                    self._lclick()
                    if _lc < clicks_per_series - 1:
                        self._sleep(lclick_interval_ms)
                if not self._running or time.time() >= spam_end: break

                self._sleep(random.randint(
                    max(50, rclick_wait_ms - 50),
                    rclick_wait_ms + 50
                ))
                self._rclick()
                self._sleep(rclick_to_lclick_ms)

            if not self._running: break

            self._send_key(str_fskey); last_key = str_fskey; self._sleep(300)
            if not self._running: break

            self.sig_log.emit("STR — Food check", "info")
            # Eat when pixel ABSENT (food exhausted)
            if not self._pixel_match(str_food_fx, str_food_fy, str_food_col, str_food_tol):
                self.sig_log.emit("STR — Food pixel missing → eat", "info")
                result = self._eat_food_in_win(
                    title, str_foods, str_fcx, str_fcy, hwnd,
                    food_px=str_food_fx, food_py=str_food_fy,
                    food_pcol=str_food_col, food_ptol=str_food_tol
                )
                if result:
                    last_key = result
                    self.sig_log.emit(f"STR — Resume with key '{result}'", "info")
                    self._send_key(last_key); self._sleep(200)

            self.stats["durability_done"] += 1; self._emit_stats()
            self.sig_log.emit(f"STR — Cycle {self.stats['durability_done']} ✓", "ok")
            self._sleep(500)

        self.sig_log.emit("Strength — finished", "ok")

    def snap_window_now(self): self._snap_game_window()

    def detect_foreground_hwnd(self) -> tuple[int, str]:
        MACRO_TITLES = {"eclipse macro","eclipse_macro"}
        hwnd = user32.GetForegroundWindow()
        if hwnd:
            buf = ctypes.create_unicode_buffer(512); user32.GetWindowTextW(hwnd, buf, 512)
            title = buf.value.strip()
            if title and title.lower() not in MACRO_TITLES: return hwnd, title
        return 0, ""

    def detect_game_window(self) -> str:
        MACRO_TITLES = {"eclipse macro","eclipse_macro"}
        hwnd = user32.GetForegroundWindow()
        if hwnd:
            buf = ctypes.create_unicode_buffer(512); user32.GetWindowTextW(hwnd, buf, 512)
            title = buf.value.strip()
            if title and title.lower() not in MACRO_TITLES: return title
        found = []
        Proc = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.wintypes.HWND, ctypes.wintypes.LPARAM)
        def _cb(h, _):
            if not user32.IsWindowVisible(h): return True
            buf2 = ctypes.create_unicode_buffer(512); user32.GetWindowTextW(h, buf2, 512)
            t = buf2.value.strip()
            if t and t.lower() not in MACRO_TITLES and t not in found: found.append(t)
            return True
        user32.EnumWindows(Proc(_cb), 0)
        return found[0] if found else ""

    def get_pixel_info(self) -> dict:
        pt = ctypes.wintypes.POINT(); user32.GetCursorPos(ctypes.byref(pt))
        return {"x": pt.x, "y": pt.y, "color": f"0x{self._get_pixel(pt.x, pt.y):06X}"}

class MacroEngine(QObject):
    sig_log          = pyqtSignal(str, str)
    sig_phase        = pyqtSignal(str)
    sig_stat         = pyqtSignal(dict)
    sig_stopped      = pyqtSignal()
    sig_paused       = pyqtSignal(bool)
    sig_pixel_status = pyqtSignal(str, bool)

    def __init__(self, config: dict):
        super().__init__()
        self._config = dict(config)
        self._worker = self._thread = None
        self._roadworks_panel_ref = None
        self._dur_hwnd1 = self._dur_hwnd2 = 0
        self._rebuild_worker()

    def _rebuild_worker(self):
        if self._thread is not None:
            if self._worker: self._worker.stop_loop()
            self._thread.quit(); self._thread.wait(3000)
            self._thread = self._worker = None
        self._worker = _Worker(self._config)
        if self._roadworks_panel_ref: self._worker._roadworks_panel = self._roadworks_panel_ref
        self._worker._dur_hwnd1 = self._dur_hwnd1
        self._worker._dur_hwnd2 = self._dur_hwnd2
        self._thread = QThread(); self._worker.moveToThread(self._thread)
        for sig in ("sig_log","sig_phase","sig_stat","sig_stopped","sig_paused","sig_pixel_status"):
            getattr(self._worker, sig).connect(getattr(self, sig))
        self._thread.start()

    def _invoke(self, method: str):
        from PyQt6.QtCore import QMetaObject, Qt
        QMetaObject.invokeMethod(self._worker, method, Qt.ConnectionType.QueuedConnection)

    def start(self):               self._rebuild_worker(); self._invoke("start_loop")
    def start_shadow_boxing(self): self._rebuild_worker(); self._invoke("start_shadow_boxing_loop")
    def start_roadworks(self):     self._rebuild_worker(); self._invoke("start_roadworks_loop")
    def start_selfish_v1(self):    self._rebuild_worker(); self._invoke("start_selfish_v1_loop")
    def start_selfish_v3(self):    self._rebuild_worker(); self._invoke("start_selfish_v3_loop")
    def start_strength(self):      self._rebuild_worker(); self._invoke("start_strength_loop")
    def start_food(self):          self._rebuild_worker(); self._invoke("start_food_loop")
    def start_fat(self):           self._rebuild_worker(); self._invoke("start_fat_loop")
    def pause_toggle(self):        self._invoke("pause_toggle")
    def stop(self):
        if self._worker: self._worker.stop_loop()

    def update_config(self, config: dict):
        self._config = dict(config)
        if self._worker: self._worker.update_config(config)

    def snap_window_now(self):
        if self._worker: self._worker.snap_window_now()

    def detect_game_window(self) -> str:
        return self._worker.detect_game_window() if self._worker else ""

    def detect_foreground_hwnd(self) -> tuple[int, str]:
        if self._worker: return self._worker.detect_foreground_hwnd()
        MACRO_TITLES = {"eclipse macro","eclipse_macro"}
        hwnd = user32.GetForegroundWindow()
        if hwnd:
            buf = ctypes.create_unicode_buffer(512); user32.GetWindowTextW(hwnd, buf, 512)
            title = buf.value.strip()
            if title and title.lower() not in MACRO_TITLES: return hwnd, title
        return 0, ""

    def set_dur_hwnd(self, slot: int, hwnd: int):
        if self._worker: self._worker.set_dur_hwnd(slot, hwnd)
        if slot == 1: self._dur_hwnd1 = hwnd
        else:         self._dur_hwnd2 = hwnd

    def get_pixel_info(self) -> dict:
        return self._worker.get_pixel_info() if self._worker else {"x":0,"y":0,"color":"0x000000"}

    def __del__(self):
        try:
            if self._worker: self._worker.stop_loop()
            if self._thread: self._thread.quit(); self._thread.wait(2000)
        except Exception: pass
