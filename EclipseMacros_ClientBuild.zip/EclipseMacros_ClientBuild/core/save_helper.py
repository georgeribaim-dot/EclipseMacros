"""
save_helper.py — Helper centralisé pour la sauvegarde du profil JSON.

Utilisé par tous les panneaux pour garantir que chaque modification
est bien persistée dans assets/configs/<profile>.json.
"""

import json
import os
from pathlib import Path


def save_config_to_json(config_manager) -> bool:
    """
    Sauvegarde le profil actif dans le fichier JSON correspondant.
    Retourne True si succès, False sinon.
    
    Le fichier sauvegardé est : assets/configs/<profile_name>.json
    """
    try:
        config_manager.save_profile()
        return True
    except Exception as e:
        print(f"[save_helper] Erreur sauvegarde : {e}")
        return False


def get_profile_path(config_manager) -> Path:
    """Retourne le chemin du fichier JSON du profil actif."""
    try:
        root = _get_root()
        safe = "".join(
            c for c in config_manager.current_profile
            if c.isalnum() or c in "_ -"
        )
        return root / "assets" / "configs" / f"{safe}.json"
    except Exception:
        return Path("assets") / "configs" / "Default.json"


def load_all_profiles(config_manager) -> list[str]:
    """Retourne la liste de tous les profils disponibles."""
    try:
        return config_manager.list_profiles()
    except Exception:
        return ["Default"]


def export_profile_to_file(config_manager, dest_path: str) -> bool:
    """Exporte le profil actif vers un chemin arbitraire."""
    try:
        data = config_manager.as_dict()
        with open(dest_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        return True
    except Exception as e:
        print(f"[save_helper] Erreur export : {e}")
        return False


def import_profile_from_file(config_manager, src_path: str, profile_name: str) -> bool:
    """Importe un profil depuis un fichier JSON externe."""
    try:
        with open(src_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        config_manager.update(data)
        config_manager.save_profile(profile_name)
        return True
    except Exception as e:
        print(f"[save_helper] Erreur import : {e}")
        return False


def _get_root() -> Path:
    import sys
    if hasattr(sys, "_MEIPASS"):
        return Path(sys._MEIPASS)
    return Path(__file__).resolve().parent.parent
