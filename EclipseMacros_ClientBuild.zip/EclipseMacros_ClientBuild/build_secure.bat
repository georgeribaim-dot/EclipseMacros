@echo off
setlocal EnableDelayedExpansion

title Eclipse Macros - Build SECURISE (Nuitka, gratuit)

:: =====================================================================
::  Ce script est a executer UNIQUEMENT sur TA machine (developpeur).
::  Il compile tout le projet Python en code machine natif (C/C++)
::  via Nuitka, ce qui rend la recuperation du code source quasi
::  impossible (pas de bytecode .pyc, pas de fichiers .py).
::  Le client ne recevra QUE le contenu du dossier "dist_client" genere
::  a la fin de ce script. Ne lui envoie JAMAIS les fichiers .py source.
:: =====================================================================

echo.
echo ==================================================
echo    Eclipse Macros - Build securise Nuitka (dev only)
echo ==================================================
echo.

set ROOT=%~dp0
if "%ROOT:~-1%"=="\" set ROOT=%ROOT:~0,-1%

:: --------------------------------------------------
echo [1/5] Verification de Python...
where python >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERREUR] Python introuvable dans le PATH.
    echo Installe Python 3.12 depuis https://www.python.org/downloads/
    pause
    exit /b 1
)
for /f "tokens=2 delims= " %%V in ('python --version 2^>^&1') do set PYVER=%%V
echo [OK] Python !PYVER!

:: --------------------------------------------------
echo.
echo [2/5] Installation des dependances de build...
python -m pip install --upgrade pip --quiet --no-warn-script-location
python -m pip install nuitka ordered-set zstandard --quiet --no-warn-script-location
python -m pip install -r "%ROOT%\requirements_dev.txt" --quiet --no-warn-script-location
if %errorlevel% neq 0 (
    echo [ERREUR] Echec installation dependances.
    pause
    exit /b 1
)
echo [OK] Dependances installees

:: --------------------------------------------------
echo.
echo [3/5] Nettoyage des anciens builds...
if exist "%ROOT%\dist" rmdir /s /q "%ROOT%\dist"
if exist "%ROOT%\dist_client" rmdir /s /q "%ROOT%\dist_client"
if exist "%ROOT%\main.build" rmdir /s /q "%ROOT%\main.build"
if exist "%ROOT%\main.dist" rmdir /s /q "%ROOT%\main.dist"
if exist "%ROOT%\main.onefile-build" rmdir /s /q "%ROOT%\main.onefile-build"
for /d /r "%ROOT%" %%d in (__pycache__) do (
    if exist "%%d" rmdir /s /q "%%d"
)
echo [OK] Nettoyage termine

:: --------------------------------------------------
echo.
echo [4/5] Compilation Nuitka (code natif, exe unique, sans console)...
echo (Tout le code Python est compile en C/C++ puis en binaire machine.)
echo (Aucun fichier .py ni bytecode .pyc n'est inclus dans l'exe final.)
echo Cette etape peut prendre plusieurs minutes, merci de patienter...
echo.

python -m nuitka ^
    --standalone ^
    --onefile ^
    --windows-console-mode=disable ^
    --enable-plugin=pyqt6 ^
    --windows-icon-from-ico="%ROOT%\assets\eclipse_logo.ico" ^
    --include-data-dir="%ROOT%\assets=assets" ^
    --include-module=win32api ^
    --include-module=win32con ^
    --include-module=win32gui ^
    --include-module=pywintypes ^
    --include-module=keyboard ^
    --include-module=mss ^
    --include-module=mss.windows ^
    --include-module=numpy ^
    --include-module=cv2 ^
    --include-module=PIL ^
    --include-module=PIL.Image ^
    --include-module=PIL.ImageGrab ^
    --include-module=requests ^
    --include-module=requests.adapters ^
    --include-module=urllib3 ^
    --include-package=core ^
    --include-package=ui ^
    --nofollow-import-to=tkinter ^
    --nofollow-import-to=matplotlib ^
    --nofollow-import-to=scipy ^
    --nofollow-import-to=pandas ^
    --output-dir="%ROOT%\dist" ^
    --output-filename="Eclipse Macros.exe" ^
    --remove-output ^
    --assume-yes-for-downloads ^
    "%ROOT%\main.py"

if %errorlevel% neq 0 (
    echo [ERREUR] Echec de la compilation Nuitka.
    pause
    exit /b 1
)
echo [OK] Compilation terminee

:: --------------------------------------------------
echo.
echo [5/5] Preparation du package client final...

mkdir "%ROOT%\dist_client" >nul 2>&1
copy "%ROOT%\dist\Eclipse Macros.exe" "%ROOT%\dist_client\Eclipse Macros.exe" >nul

echo.
echo ==================================================
echo   BUILD TERMINE
echo ==================================================
echo.
echo   Fichier a envoyer au client :
echo   %ROOT%\dist_client\Eclipse Macros.exe
echo.
echo   NE PARTAGE JAMAIS :
echo    - les fichiers .py source (main.py, core\, ui\, license_client.py)
echo    - le dossier server\ et admin.py
echo    - le dossier dist\ (contient les fichiers intermediaires de build)
echo    - le dossier build\ ou les .spec
echo.
echo   Le client ne doit recevoir QUE le contenu de dist_client\
echo ==================================================
echo.
pause
exit /b 0
