import os
import hashlib
import platform
import subprocess
import requests
from pathlib import Path
import sys

SERVER_URL    = "https://web-production-ab129.up.railway.app"
CLIENT_SECRET = "eclipse_client_2025"
LICENSE_FILE  = Path(os.getenv("APPDATA", ".")) / "EclipseMacro" / "license.key"
TIMEOUT       = 10

def _fragmented_post(url: str, json_data: dict, headers: dict, timeout: int) -> dict:
    try:
        if not url or not isinstance(json_data, dict):
            return {"error": "Invalid parameters"}
        response = requests.post(
            url, json=json_data, headers=headers, timeout=timeout, verify=True
        )
        return response.json()
    except Exception as e:
        return {"error": str(e)}

def get_device_id() -> str:
    parts = []
    try:
        import winreg
        key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography")
        guid, _ = winreg.QueryValueEx(key, "MachineGuid")
        winreg.CloseKey(key)
        parts.append(guid)
    except Exception:
        pass
    try:
        result = subprocess.check_output(
            ["wmic", "diskdrive", "get", "SerialNumber"],
            stderr=subprocess.DEVNULL, timeout=5
        ).decode(errors="ignore")
        serial = " ".join(result.split()).replace("SerialNumber", "").strip()
        if serial:
            parts.append(serial)
    except Exception:
        pass
    parts.append(platform.node())
    combined = "|".join(parts) or "fallback-unknown"
    return hashlib.sha256(combined.encode()).hexdigest()

def _load_saved_key() -> str | None:
    try:
        if LICENSE_FILE.exists():
            return LICENSE_FILE.read_text().strip()
    except Exception:
        pass
    return None

def _save_key(key: str) -> None:
    try:
        LICENSE_FILE.parent.mkdir(parents=True, exist_ok=True)
        LICENSE_FILE.write_text(key.strip())
    except Exception:
        pass

def _headers() -> dict:
    return {"Content-Type": "application/json", "X-API-Secret": CLIENT_SECRET}

def activate_license(key: str, device_id: str) -> tuple[bool, str]:
    try:
        data = _fragmented_post(
            f"{SERVER_URL}/activate",
            {"license_key": key, "device_id": device_id},
            _headers(), TIMEOUT
        )
        return data.get("valid", False), data.get("message", "Erreur inconnue")
    except requests.exceptions.ConnectionError:
        return False, "Impossible de joindre le serveur de licences."
    except Exception as e:
        return False, f"Erreur : {e}"

def verify_license_online(key: str, device_id: str) -> bool:
    try:
        data = _fragmented_post(
            f"{SERVER_URL}/verify",
            {"license_key": key, "device_id": device_id},
            _headers(), TIMEOUT
        )
        if data.get("expired"):
            return False
        return data.get("valid", False)
    except Exception:
        # Si serveur inaccessible ET clé sauvegardée → autoriser (mode offline)
        return False

def _ask_key_qt() -> str | None:
    try:
        from PyQt6.QtWidgets import QApplication, QInputDialog, QMessageBox
        while True:
            key, ok = QInputDialog.getText(
                None,
                "Eclipse Macro — Activation",
                "Entrez votre clé de licence :\n(Format : ABCD-EFGH-IJKL-MNOP)",
            )
            if not ok:
                return None
            key = key.strip().upper()
            if key:
                return key
            QMessageBox.warning(
                None,
                "Clé requise",
                "Une clé de licence valide est obligatoire pour utiliser Eclipse Macro.\nVeuillez entrer votre clé."
            )
    except Exception:
        while True:
            key = input("  Clé de licence (obligatoire) : ").strip().upper()
            if key:
                return key
            print("  [ERREUR] Une clé est obligatoire.")

def verify_license() -> bool:
    device_id = get_device_id()
    saved_key = _load_saved_key()

    # Rejeter les anciennes clés "mode local" (héritage v1)
    if saved_key and saved_key.startswith("LOCAL"):
        try:
            LICENSE_FILE.unlink(missing_ok=True)
        except Exception:
            pass
        saved_key = None

    if saved_key:
        # Tenter vérification en ligne
        try:
            if verify_license_online(saved_key, device_id):
                return True
        except Exception:
            pass
        # Si serveur inaccessible, autoriser avec clé sauvegardée (mode offline)
        try:
            resp = requests.get(SERVER_URL + "/ping", timeout=3)
            server_up = resp.status_code < 500
        except Exception:
            server_up = False

        if not server_up:
            # Serveur inaccessible → mode offline, utiliser la clé locale
            return True

        # Serveur accessible mais clé invalide → réactiver
        try:
            LICENSE_FILE.unlink(missing_ok=True)
        except Exception:
            pass

    key = _ask_key_qt()
    if not key:
        return False

    ok, message = activate_license(key, device_id)
    if ok:
        _save_key(key)
        return True
    else:
        # Serveur inaccessible → autoriser quand même avec la clé fournie
        try:
            resp = requests.get(SERVER_URL + "/ping", timeout=3)
            server_up = resp.status_code < 500
        except Exception:
            server_up = False

        if not server_up:
            _save_key(key)
            return True

        try:
            from PyQt6.QtWidgets import QMessageBox
            QMessageBox.critical(None, "Licence invalide", f"Activation échouée :\n{message}")
        except Exception:
            print(f"\n[LICENCE] Échec : {message}")
        return False
