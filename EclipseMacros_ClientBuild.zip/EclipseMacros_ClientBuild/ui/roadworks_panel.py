
import os
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame,
    QPushButton, QLineEdit, QScrollArea,
    QGridLayout,
)
from PyQt6.QtCore import Qt, pyqtSignal, QTimer
from PyQt6.QtGui import QPixmap, QDoubleValidator, QIntValidator

from .theme import COLORS
from .widgets import AnimatedToggle
from core.config_manager import ConfigManager

def _roadworks_pixmap(size: int) -> QPixmap:
    assets = os.path.join(os.path.dirname(os.path.dirname(__file__)), "assets")
    path   = os.path.join(assets, "roadworks_logo.png")
    if os.path.isfile(path):
        pm = QPixmap(path)
        return pm.scaled(size, size,
                         Qt.AspectRatioMode.KeepAspectRatio,
                         Qt.TransformationMode.SmoothTransformation)
    pm = QPixmap(size, size)
    pm.fill(Qt.GlobalColor.transparent)
    return pm

def _sec(txt):
    l = QLabel(txt)
    l.setStyleSheet(
        f"color:{COLORS['accent_gold']};font-size:10px;"
        f"font-weight:700;letter-spacing:2px;padding-bottom:4px;"
    )
    return l

def _fld(txt):
    l = QLabel(txt)
    l.setStyleSheet(f"color:{COLORS['text_secondary']};font-size:11px;")
    return l

def _le(ph="", int_only=False, float_only=False, w=None):
    e = QLineEdit()
    e.setPlaceholderText(ph)
    if int_only:
        e.setValidator(QIntValidator(0, 9999))
    elif float_only:
        v = QDoubleValidator(0.1, 10.0, 2)
        e.setValidator(v)
    e.setFixedHeight(28)
    if w:
        e.setFixedWidth(w)
    e.setStyleSheet(f"""
        QLineEdit{{background:{COLORS['bg_elevated']};
        border:1px solid {COLORS['bg_border']};border-radius:6px;
        color:{COLORS['text_primary']};font-size:12px;padding:0 8px;}}
        QLineEdit:focus{{border:1px solid {COLORS['accent']};}}
    """)
    return e

def _card_frame():
    f = QFrame()
    f.setStyleSheet(
        f"QFrame{{background:{COLORS['bg_elevated']};"
        f"border:1px solid {COLORS['bg_border']};border-radius:10px;}}"
    )
    return f

def _sec_btn():
    return (
        f"QPushButton{{background:{COLORS['bg_elevated']};"
        f"color:{COLORS['text_primary']};border:1px solid {COLORS['bg_border']};"
        f"border-radius:8px;font-size:12px;}}"
        f"QPushButton:hover{{border-color:{COLORS.get('accent','#888')};}}"
    )

def _toggle_row_widget(label: str) -> tuple:
    row = QWidget()
    row.setStyleSheet(
        f"background:{COLORS['bg_base']};"
        f"border:1px solid {COLORS['bg_border']};border-radius:8px;"
    )
    lay = QHBoxLayout(row)
    lay.setContentsMargins(14, 10, 14, 10)
    lbl = QLabel(label)
    lbl.setStyleSheet(f"color:{COLORS['text_primary']};font-size:13px;font-weight:600;")
    lay.addWidget(lbl)
    lay.addStretch()
    tgl = AnimatedToggle(checked=False)
    lay.addWidget(tgl)
    return row, tgl, lbl

class RoadworksPanel(QWidget):
    sig_select_rw = pyqtSignal()
    sig_saved     = pyqtSignal()

    def __init__(self, cfg: ConfigManager, parent=None):
        super().__init__(parent)
        self.cfg     = cfg
        self._active = False
        self._build_ui()
        self._load_values()

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(20, 16, 20, 16)
        root.setSpacing(14)

        tr = QHBoxLayout(); tr.setSpacing(12)
        ll = QLabel()
        ll.setPixmap(_roadworks_pixmap(44))
        ll.setFixedSize(44, 44)
        tr.addWidget(ll)
        col = QVBoxLayout(); col.setSpacing(2)
        t = QLabel("Roadworks")
        t.setStyleSheet(f"color:{COLORS['text_primary']};font-size:16px;font-weight:700;")
        col.addWidget(t)
        sub = QLabel("Running Training Automation — Asura")
        sub.setStyleSheet(f"color:{COLORS['text_secondary']};font-size:11px;")
        col.addWidget(sub)
        tr.addLayout(col); tr.addStretch()
        root.addLayout(tr)

        self._btn_select = QPushButton("🚧  Select Roadworks  (F1 / F2 / F3)")
        self._btn_select.setFixedHeight(42)
        self._btn_select.setStyleSheet(self._select_style(False))
        self._btn_select.clicked.connect(self._on_select)
        root.addWidget(self._btn_select)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setStyleSheet("background:transparent;")
        inner = QWidget(); inner.setStyleSheet("background:transparent;")
        il = QVBoxLayout(inner)
        il.setContentsMargins(0, 0, 8, 0); il.setSpacing(16)

        kc = _card_frame(); kl = QVBoxLayout(kc)
        kl.setContentsMargins(16, 14, 16, 14); kl.setSpacing(10)
        kl.addWidget(_sec("KEYBOARD LAYOUT"))

        kb_row, self._kb_toggle, self._kb_label = _toggle_row_widget("AZERTY")
        self._kb_toggle.toggled.connect(self._on_kb_toggle)
        kl.addWidget(kb_row)

        self._kb_hint = QLabel()
        self._kb_hint.setStyleSheet(
            f"color:{COLORS['accent_gold']};font-size:10px;"
            f"background:{COLORS['bg_base']};border-radius:6px;padding:6px 10px;"
        )
        kl.addWidget(self._kb_hint)
        il.addWidget(kc)

        tc = _card_frame(); tl = QVBoxLayout(tc)
        tl.setContentsMargins(16, 14, 16, 14); tl.setSpacing(12)
        tl.addWidget(_sec("TRAINING CONFIGURATION"))

        tr2 = QHBoxLayout()
        tr2.addWidget(_fld("Training Key  (default: E)"))
        self._ed_training_key = _le("e", w=60)
        self._ed_training_key.setToolTip("Key pressed to open Training menu in Asura (e.g. E, T...)")
        tr2.addWidget(self._ed_training_key)
        tr2.addStretch()
        tl.addLayout(tr2)

        stat_row, self._stat_toggle, self._stat_label = _toggle_row_widget("Speed")
        self._stat_toggle.toggled.connect(self._on_stat_toggle)
        tl.addWidget(stat_row)

        il.addWidget(tc)

        pc = _card_frame(); pl = QVBoxLayout(pc)
        pl.setContentsMargins(16, 14, 16, 14); pl.setSpacing(10)
        pl.addWidget(_sec("CLICK POSITIONS"))
        pos_info = QLabel(
            "Screen coordinates (pixels) for macro clicks.\n"
            "Use the Pixel Info tool in the dashboard to find them."
        )
        pos_info.setStyleSheet(f"color:{COLORS['text_dim']};font-size:10px;")
        pos_info.setWordWrap(True)
        pl.addWidget(pos_info)

        pg = QGridLayout(); pg.setHorizontalSpacing(8); pg.setVerticalSpacing(8)

        pos_rows = [
            ("Click zone  X",      "RW_ClickX",      "960"),
            ("Click zone  Y",      "RW_ClickY",       "540"),
            ("Pixel Detection  X", "RW_SkinDetectX", "960"),
            ("Pixel Detection  Y", "RW_SkinDetectY", "540"),
            ("Click Speed  X",     "RW_SpeedX",       "900"),
            ("Click Speed  Y",     "RW_SpeedY",       "400"),
            ("Click Stamina  X",   "RW_StaminaX",    "1020"),
            ("Click Stamina  Y",   "RW_StaminaY",     "400"),
        ]
        self._pos_eds: dict[str, QLineEdit] = {}
        for i, (label, key, default) in enumerate(pos_rows):
            pg.addWidget(_fld(label), i, 0)
            ed = _le(default, int_only=True, w=80)
            self._pos_eds[key] = ed
            pg.addWidget(ed, i, 1)
            pg.setColumnStretch(2, 1)

        pg.addWidget(_fld("Pixel Detection — Color (hex)"), len(pos_rows), 0)
        self._ed_click_detect_color = _le("", w=120)
        self._ed_click_detect_color.setToolTip(
            "Color to detect around the click point. Example: #FF0000 or 0xFF0000"
        )
        pg.addWidget(self._ed_click_detect_color, len(pos_rows), 1)

        pg.addWidget(_fld("Color Tolerance"), len(pos_rows) + 1, 0)
        self._ed_click_detect_tol = _le("12", int_only=True, w=80)
        self._ed_click_detect_tol.setToolTip(
            "Color tolerance for pixel detection."
        )
        pg.addWidget(self._ed_click_detect_tol, len(pos_rows) + 1, 1)

        pg.addWidget(_fld("Search radius (px)"), len(pos_rows) + 2, 0)
        self._ed_click_detect_rad = _le("40", int_only=True, w=80)
        self._ed_click_detect_rad.setToolTip(
            "Radius around RW_ClickX / RW_ClickY to search for the pixel."
        )
        pg.addWidget(self._ed_click_detect_rad, len(pos_rows) + 2, 1)

        pl.addLayout(pg)
        il.addWidget(pc)

        vc = _card_frame(); vl = QVBoxLayout(vc)
        vl.setContentsMargins(16, 14, 16, 14); vl.setSpacing(10)
        vl.addWidget(_sec("SPEED ADJUSTMENT"))
        speed_info = QLabel(
            "Step speed multiplier.\n"
            "1.0 = default speed  |  1.32 = 32% faster  |  0.85 = 15% slower\n"
            "Steps NOT affected: 0, pixel detection/training, 18, 19."
        )
        speed_info.setStyleSheet(f"color:{COLORS['text_dim']};font-size:10px;")
        speed_info.setWordWrap(True)
        vl.addWidget(speed_info)
        sg = QGridLayout(); sg.setHorizontalSpacing(16); sg.setVerticalSpacing(8)
        sg.addWidget(_fld("Speed Multiplier (e.g. 1.0)"), 0, 0)
        self._ed_speed_adjust = _le("1.0", float_only=True, w=80)
        sg.addWidget(self._ed_speed_adjust, 0, 1)
        vl.addLayout(sg)
        il.addWidget(vc)

        cc = _card_frame(); cl = QVBoxLayout(cc)
        cl.setContentsMargins(16, 14, 16, 14); cl.setSpacing(10)
        cl.addWidget(_sec("CYCLES"))
        cg = QGridLayout(); cg.setHorizontalSpacing(16); cg.setVerticalSpacing(8)
        cycle_rows = [
            ("Cycle Count (0 = infinitete)", "RW_Laps",      "Repeat cycle N times. 0 = infinitete loop until F3."),
            ("Inter-cycle Pause (ms)",        "RW_CycleDelay","Pause after completing all cycles (if > 0)."),
        ]
        self._cycle_eds: dict[str, QLineEdit] = {}
        for i, (label, key, tip) in enumerate(cycle_rows):
            cg.addWidget(_fld(label), i, 0)
            ed = _le(int_only=True)
            ed.setToolTip(tip)
            self._cycle_eds[key] = ed
            cg.addWidget(ed, i, 1)
        cl.addLayout(cg)
        il.addWidget(cc)

        self._step_eds: list[QLineEdit] = []
        # NOTE: step_ms[0] removed (Step 0 supprimé) — index 0 placeholder conservé
        # pour maintenir la compatibilité des indices [1..24].
        # On ajoute un QLineEdit caché pour index 0 afin de ne pas décaler le tableau.
        _ee0_hidden = _le("400", int_only=True, w=90)
        _ee0_hidden.setVisible(False)
        self._step_eds.append(_ee0_hidden)

        _ec1 = _card_frame(); _el1 = QVBoxLayout(_ec1)
        _el1.setContentsMargins(16, 10, 16, 10); _el1.setSpacing(6)
        _el1.addWidget(_sec('Step 1  — Z + Q (left)  |  2,10 s'))
        _er1 = QHBoxLayout()
        _ef1 = _fld("Duration (ms) — default: 2100  (Q 2.10s)")
        _er1.addWidget(_ef1)
        _ee1 = _le("2100", int_only=True, w=90)
        _ee1.setToolTip('Z maintenu + Q (left) pendant cette duration.')
        _er1.addWidget(_ee1)
        _er1.addStretch()
        _el1.addLayout(_er1)
        il.addWidget(_ec1)
        self._step_eds.append(_ee1)

        _ec2 = _card_frame(); _el2 = QVBoxLayout(_ec2)
        _el2.setContentsMargins(16, 10, 16, 10); _el2.setSpacing(6)
        _el2.addWidget(_sec('Step 2  — Z + ↓  |  6,81 s'))
        _er2 = QHBoxLayout()
        _ef2 = _fld("Duration (ms) — default: 6810  (↓ 6.81s)")
        _er2.addWidget(_ef2)
        _ee2 = _le("6300", int_only=True, w=90)
        _ee2.setToolTip('Sprint forward + down.')
        _er2.addWidget(_ee2)
        _er2.addStretch()
        _el2.addLayout(_er2)
        il.addWidget(_ec2)
        self._step_eds.append(_ee2)

        _ec3 = _card_frame(); _el3 = QVBoxLayout(_ec3)
        _el3.setContentsMargins(16, 10, 16, 10); _el3.setSpacing(6)
        _el3.addWidget(_sec('Step 3  — Z + D (right)  |  6,50 s'))
        _er3 = QHBoxLayout()
        _ef3 = _fld("Duration (ms) — default: 6500  (D 6.50s)")
        _er3.addWidget(_ef3)
        _ee3 = _le("6500", int_only=True, w=90)
        _ee3.setToolTip('Sprint avant + right.')
        _er3.addWidget(_ee3)
        _er3.addStretch()
        _el3.addLayout(_er3)
        il.addWidget(_ec3)
        self._step_eds.append(_ee3)

        _ec4 = _card_frame(); _el4 = QVBoxLayout(_ec4)
        _el4.setContentsMargins(16, 10, 16, 10); _el4.setSpacing(6)
        _el4.addWidget(_sec('Step 4  — Z + ↑  |  3,12 s'))
        _er4 = QHBoxLayout()
        _ef4 = _fld("Duration (ms) — default: 3120  (↑ 3.12s)")
        _er4.addWidget(_ef4)
        _ee4 = _le("3120", int_only=True, w=90)
        _ee4.setToolTip('Sprint forward + up.')
        _er4.addWidget(_ee4)
        _er4.addStretch()
        _el4.addLayout(_er4)
        il.addWidget(_ec4)
        self._step_eds.append(_ee4)

        _ec5 = _card_frame(); _el5 = QVBoxLayout(_ec5)
        _el5.setContentsMargins(16, 10, 16, 10); _el5.setSpacing(6)
        _el5.addWidget(_sec('Step 5  — Z + D (right)  |  2,46 s'))
        _er5 = QHBoxLayout()
        _ef5 = _fld("Duration (ms) — default: 2460  (D 2.46s)")
        _er5.addWidget(_ef5)
        _ee5 = _le("2460", int_only=True, w=90)
        _ee5.setToolTip('Sprint avant + right.')
        _er5.addWidget(_ee5)
        _er5.addStretch()
        _el5.addLayout(_er5)
        il.addWidget(_ec5)
        self._step_eds.append(_ee5)

        _ec6 = _card_frame(); _el6 = QVBoxLayout(_ec6)
        _el6.setContentsMargins(16, 10, 16, 10); _el6.setSpacing(6)
        _el6.addWidget(_sec('Step 6  — Z + D + ↑  |  1,56 s'))
        _er6 = QHBoxLayout()
        _ef6 = _fld("Duration (ms) — default : 1560  (D+↑ 1,56s)")
        _er6.addWidget(_ef6)
        _ee6 = _le("1560", int_only=True, w=90)
        _ee6.setToolTip('Sprint forward + right + up.')
        _er6.addWidget(_ee6)
        _er6.addStretch()
        _el6.addLayout(_er6)
        il.addWidget(_ec6)
        self._step_eds.append(_ee6)

        _ec7 = _card_frame(); _el7 = QVBoxLayout(_ec7)
        _el7.setContentsMargins(16, 10, 16, 10); _el7.setSpacing(6)
        _el7.addWidget(_sec('Step 7  — Z + ↑ + Q  |  2,31 s'))
        _er7 = QHBoxLayout()
        _ef7 = _fld("Duration (ms) — default : 2310  (↑+Q 2,31s)")
        _er7.addWidget(_ef7)
        _ee7 = _le("2310", int_only=True, w=90)
        _ee7.setToolTip('Sprint forward + up + left.')
        _er7.addWidget(_ee7)
        _er7.addStretch()
        _el7.addLayout(_er7)
        il.addWidget(_ec7)
        self._step_eds.append(_ee7)

        _ec8 = _card_frame(); _el8 = QVBoxLayout(_ec8)
        _el8.setContentsMargins(16, 10, 16, 10); _el8.setSpacing(6)
        _el8.addWidget(_sec('Step 8  — release Q → resume Z + ↑ + Q  |  1,74 s'))
        _er8 = QHBoxLayout()
        _ef8 = _fld("Duration (ms) — default : 1740  (↑+Q 1,74s)")
        _er8.addWidget(_ef8)
        _ee8 = _le("1740", int_only=True, w=90)
        _ee8.setToolTip('Sprint forward + up + left.')
        _er8.addWidget(_ee8)
        _er8.addStretch()
        _el8.addLayout(_er8)
        il.addWidget(_ec8)
        self._step_eds.append(_ee8)

        _ec9 = _card_frame(); _el9 = QVBoxLayout(_ec9)
        _el9.setContentsMargins(16, 10, 16, 10); _el9.setSpacing(6)
        _el9.addWidget(_sec('Step 9  — Z + Q  |  2,10 s'))
        _er9 = QHBoxLayout()
        _ef9 = _fld("Duration (ms) — default: 2100  (Q 2.10s)")
        _er9.addWidget(_ef9)
        _ee9 = _le("2100", int_only=True, w=90)
        _ee9.setToolTip('Z maintenu + Q (left) pendant cette duration.')
        _er9.addWidget(_ee9)
        _er9.addStretch()
        _el9.addLayout(_er9)
        il.addWidget(_ec9)
        self._step_eds.append(_ee9)

        _ec10 = _card_frame(); _el10 = QVBoxLayout(_ec10)
        _el10.setContentsMargins(16, 10, 16, 10); _el10.setSpacing(6)
        _el10.addWidget(_sec('Step 10 — Z + Q + ↑  |  0,95 s'))
        _er10 = QHBoxLayout()
        _ef10 = _fld("Duration (ms) — default : 950  (Q+↑ 0,95s)")
        _er10.addWidget(_ef10)
        _ee10 = _le("950", int_only=True, w=90)
        _ee10.setToolTip('Sprint forward + left + up.')
        _er10.addWidget(_ee10)
        _er10.addStretch()
        _el10.addLayout(_er10)
        il.addWidget(_ec10)
        self._step_eds.append(_ee10)

        _ec11 = _card_frame(); _el11 = QVBoxLayout(_ec11)
        _el11.setContentsMargins(16, 10, 16, 10); _el11.setSpacing(6)
        _el11.addWidget(_sec('Step 11 — Z + Q  |  0,27 s'))
        _er11 = QHBoxLayout()
        _ef11 = _fld("Duration (ms) — default : 270  (Q 0,27s)")
        _er11.addWidget(_ef11)
        _ee11 = _le("270", int_only=True, w=90)
        _ee11.setToolTip('Z maintenu + Q (left) pendant cette duration.')
        _er11.addWidget(_ee11)
        _er11.addStretch()
        _el11.addLayout(_er11)
        il.addWidget(_ec11)
        self._step_eds.append(_ee11)

        _ec12 = _card_frame(); _el12 = QVBoxLayout(_ec12)
        _el12.setContentsMargins(16, 10, 16, 10); _el12.setSpacing(6)
        _el12.addWidget(_sec('Step 12 — Z + Q + ↑  |  1,25 s'))
        _er12 = QHBoxLayout()
        _ef12 = _fld("Duration (ms) — default : 1250  (Q+↑ 1,25s)")
        _er12.addWidget(_ef12)
        _ee12 = _le("1250", int_only=True, w=90)
        _ee12.setToolTip('Sprint forward + left + up.')
        _er12.addWidget(_ee12)
        _er12.addStretch()
        _el12.addLayout(_er12)
        il.addWidget(_ec12)
        self._step_eds.append(_ee12)

        _ec13 = _card_frame(); _el13 = QVBoxLayout(_ec13)
        _el13.setContentsMargins(16, 10, 16, 10); _el13.setSpacing(6)
        _el13.addWidget(_sec('Step 13 — Z alone  |  1,36 s'))
        _er13 = QHBoxLayout()
        _ef13 = _fld("Duration (ms) — default : 1360  (Z alone 1,36s)")
        _er13.addWidget(_ef13)
        _ee13 = _le("1360", int_only=True, w=90)
        _ee13.setToolTip('Sprint forward + up.')
        _er13.addWidget(_ee13)
        _er13.addStretch()
        _el13.addLayout(_er13)
        il.addWidget(_ec13)
        self._step_eds.append(_ee13)

        _ec14 = _card_frame(); _el14 = QVBoxLayout(_ec14)
        _el14.setContentsMargins(16, 10, 16, 10); _el14.setSpacing(6)
        _el14.addWidget(_sec('Step 14 — Z + Q  |  0,84 s'))
        _er14 = QHBoxLayout()
        _ef14 = _fld("Duration (ms) — default : 840  (Q 0,84s)")
        _er14.addWidget(_ef14)
        _ee14 = _le("840", int_only=True, w=90)
        _ee14.setToolTip('Z maintenu + Q (left) pendant cette duration.')
        _er14.addWidget(_ee14)
        _er14.addStretch()
        _el14.addLayout(_er14)
        il.addWidget(_ec14)
        self._step_eds.append(_ee14)

        _ec15 = _card_frame(); _el15 = QVBoxLayout(_ec15)
        _el15.setContentsMargins(16, 10, 16, 10); _el15.setSpacing(6)
        _el15.addWidget(_sec('Step 15 — Z + ↓  |  2,77 s'))
        _er15 = QHBoxLayout()
        _ef15 = _fld("Duration (ms) — default : 2770  (↓ 2,77s)")
        _er15.addWidget(_ef15)
        _ee15 = _le("2770", int_only=True, w=90)
        _ee15.setToolTip('Sprint forward + down.')
        _er15.addWidget(_ee15)
        _er15.addStretch()
        _el15.addLayout(_er15)
        il.addWidget(_ec15)
        self._step_eds.append(_ee15)

        _ec16 = _card_frame(); _el16 = QVBoxLayout(_ec16)
        _el16.setContentsMargins(16, 10, 16, 10); _el16.setSpacing(6)
        _el16.addWidget(_sec('Step 16 — Z + Q  |  1,12 s'))
        _er16 = QHBoxLayout()
        _ef16 = _fld("Duration (ms) — default : 1120  (Q 1,12s)")
        _er16.addWidget(_ef16)
        _ee16 = _le("700", int_only=True, w=90)
        _ee16.setToolTip('Z maintenu + Q (left) pendant cette duration.')
        _er16.addWidget(_ee16)
        _er16.addStretch()
        _el16.addLayout(_er16)
        il.addWidget(_ec16)
        self._step_eds.append(_ee16)

        _ec17 = _card_frame(); _el17 = QVBoxLayout(_ec17)
        _el17.setContentsMargins(16, 10, 16, 10); _el17.setSpacing(6)
        _el17.addWidget(_sec('Step 17 — Pause (release ALL, including Z)'))
        _er17 = QHBoxLayout()
        _ef17 = _fld("Duration (ms) — default: 100  (pause after release)")
        _er17.addWidget(_ef17)
        _ee17 = _le("100", int_only=True, w=90)
        _ee17.setToolTip('Duration of the pause after secondary keys are released (Z held).')
        _er17.addWidget(_ee17)
        _er17.addStretch()
        _el17.addLayout(_er17)
        il.addWidget(_ec17)
        self._step_eds.append(_ee17)

        _ec18 = _card_frame(); _el18 = QVBoxLayout(_ec18)
        _el18.setContentsMargins(16, 10, 16, 10); _el18.setSpacing(6)
        _el18.addWidget(_sec('Step 18 — Z alone  |  1,42 s'))
        _er18 = QHBoxLayout()
        _ef18 = _fld("Duration (ms) — default : 1420  (Z alone 1,42s)")
        _er18.addWidget(_ef18)
        _ee18 = _le("1420", int_only=True, w=90)
        _ee18.setToolTip('Sprint forward alone (Z only).')
        _er18.addWidget(_ee18)
        _er18.addStretch()
        _el18.addLayout(_er18)
        il.addWidget(_ec18)
        self._step_eds.append(_ee18)

        _ec19 = _card_frame(); _el19 = QVBoxLayout(_ec19)
        _el19.setContentsMargins(16, 10, 16, 10); _el19.setSpacing(6)
        _el19.addWidget(_sec('Step 19 — Z + Q (end of cycle)  |  2,00 s'))
        _er19 = QHBoxLayout()
        _ef19 = _fld("Duration (ms) — default : 2000  (Z+Q 2,00s)")
        _er19.addWidget(_ef19)
        _ee19 = _le("1500", int_only=True, w=90)
        _ee19.setToolTip('Sprint forward + left. End of cycle.')
        _er19.addWidget(_ee19)
        _er19.addStretch()
        _el19.addLayout(_er19)
        il.addWidget(_ec19)
        self._step_eds.append(_ee19)

        sep_inter = QFrame()
        sep_inter.setFrameShape(QFrame.Shape.HLine)
        sep_inter.setStyleSheet(f"color:{COLORS['bg_border']};")
        il.addWidget(sep_inter)
        lbl_inter = QLabel("INTER PHASE — Z + ↑ + ↓ (before pixel detection)")
        lbl_inter.setStyleSheet(
            f"color:{COLORS['accent_gold']};font-size:11px;font-weight:700;"
            f"letter-spacing:1px;padding:4px 0;"
        )
        il.addWidget(lbl_inter)

        _ec20 = _card_frame(); _el20 = QVBoxLayout(_ec20)
        _el20.setContentsMargins(16, 10, 16, 10); _el20.setSpacing(6)
        _el20.addWidget(_sec('Step 20 — Z + ↑ + ↓ simultaneous  |  3.00 s  (wait before click)'))
        _er20 = QHBoxLayout()
        _ef20 = _fld("Duration (ms) — default : 3000  (wait 3s)")
        _er20.addWidget(_ef20)
        _ee20 = _le("1000", int_only=True, w=90)
        _ee20.setToolTip(
            'Hold Z + Up Arrow + Down Arrow together for this duration, '
            'just before pixel detection and area click.'
        )
        _er20.addWidget(_ee20)
        _er20.addStretch()
        _el20.addLayout(_er20)
        il.addWidget(_ec20)
        self._step_eds.append(_ee20)

        sep_init = QFrame()
        sep_init.setFrameShape(QFrame.Shape.HLine)
        sep_init.setStyleSheet(f"color:{COLORS['bg_border']};")
        il.addWidget(sep_init)
        lbl_init = QLabel("INIT PHASE — exécutée à chaque cycle")
        lbl_init.setStyleSheet(
            f"color:{COLORS['accent_gold']};font-size:11px;font-weight:700;"
            f"letter-spacing:1px;padding:4px 0;"
        )
        il.addWidget(lbl_init)
        lbl_init_desc = QLabel(
            "Séquence : double clic Z → clic ↑ → clic ↓ → maintien Z (fixe) → maintien S+D (speedé) → D seul (speedé, 0=skip) → S seul (speedé, 0=skip)"
        )
        lbl_init_desc.setWordWrap(True)
        lbl_init_desc.setStyleSheet(f"color:{COLORS['text_dim']};font-size:10px;padding:0 0 4px 0;")
        il.addWidget(lbl_init_desc)

        _ec21 = _card_frame(); _el21 = QVBoxLayout(_ec21)
        _el21.setContentsMargins(16, 10, 16, 10); _el21.setSpacing(6)
        _el21.addWidget(_sec('Init 21 — Maintien ↑ seul (fixe, non speedé)  |  500 ms'))
        _er21 = QHBoxLayout()
        _ef21 = _fld("Duration (ms) — default : 500  (NON affecté par speed)")
        _er21.addWidget(_ef21)
        _ee21 = _le("500", int_only=True, w=90)
        _ee21.setToolTip('Maintien de ↑ seul après le double clic Z et les clics ↑↓. NON affecté par le multiplicateur de vitesse.')
        _er21.addWidget(_ee21)
        _er21.addStretch()
        _el21.addLayout(_er21)
        il.addWidget(_ec21)
        self._step_eds.append(_ee21)

        _ec22 = _card_frame(); _el22 = QVBoxLayout(_ec22)
        _el22.setContentsMargins(16, 10, 16, 10); _el22.setSpacing(6)
        _el22.addWidget(_sec('Init 22 — Maintien ↓+D simultané (speedé)  |  583 ms (≈700ms à ×1.2)'))
        _er22 = QHBoxLayout()
        _ef22 = _fld("Duration (ms) — default : 583  (700ms ÷ 1.2, affecté par speed)")
        _er22.addWidget(_ef22)
        _ee22 = _le("583", int_only=True, w=90)
        _ee22.setToolTip('Maintien de Z + ↓ + D simultanément. Affecté par le multiplicateur de vitesse.')
        _er22.addWidget(_ee22)
        _er22.addStretch()
        _el22.addLayout(_er22)
        il.addWidget(_ec22)
        self._step_eds.append(_ee22)

        _ec23 = _card_frame(); _el23 = QVBoxLayout(_ec23)
        _el23.setContentsMargins(16, 10, 16, 10); _el23.setSpacing(6)
        _el23.addWidget(_sec('Init 23 — Maintien D seul (speedé)  |  0 = désactivé'))
        _er23 = QHBoxLayout()
        _ef23 = _fld("Duration (ms) — default : 0  (0 = skip, affecté par speed)")
        _er23.addWidget(_ef23)
        _ee23 = _le("0", int_only=True, w=90)
        _ee23.setToolTip('Maintien de Z + D seul après S+D. 0 = étape ignorée. Affecté par le multiplicateur de vitesse.')
        _er23.addWidget(_ee23)
        _er23.addStretch()
        _el23.addLayout(_er23)
        il.addWidget(_ec23)
        self._step_eds.append(_ee23)

        _ec24 = _card_frame(); _el24 = QVBoxLayout(_ec24)
        _el24.setContentsMargins(16, 10, 16, 10); _el24.setSpacing(6)
        _el24.addWidget(_sec('Init 24 — Maintien ↓ seul (speedé)  |  0 = désactivé'))
        _er24 = QHBoxLayout()
        _ef24 = _fld("Duration (ms) — default : 0  (0 = skip, affecté par speed)")
        _er24.addWidget(_ef24)
        _ee24 = _le("0", int_only=True, w=90)
        _ee24.setToolTip('Maintien de Z + ↓ seul. 0 = étape ignorée. Affecté par le multiplicateur de vitesse.')
        _er24.addWidget(_ee24)
        _er24.addStretch()
        _el24.addLayout(_er24)
        il.addWidget(_ec24)
        self._step_eds.append(_ee24)

        il.addStretch()
        scroll.setWidget(inner)
        root.addWidget(scroll)

        self._btn_save = QPushButton("💾  Save Settings")
        self._btn_save.setFixedHeight(34)
        self._btn_save.setStyleSheet(_sec_btn())
        self._btn_save.clicked.connect(self._save_values)
        root.addWidget(self._btn_save)

        self._update_kb_hint()

    def _on_kb_toggle(self, is_qwerty: bool):
        if is_qwerty:
            self._kb_label.setText("QWERTY")
            self._kb_hint.setText(
                "⌨  Keys:  W = sprint  |  A = left  |  D = right  |  ↑ ↓ arrows"
            )
        else:
            self._kb_label.setText("AZERTY")
            self._kb_hint.setText(
                "⌨  Keys:  Z = sprint  |  Q = left  |  D = right  |  ↑ ↓ arrows"
            )

    def _on_stat_toggle(self, is_stamina: bool):
        self._stat_label.setText("Stamina" if is_stamina else "Speed")

    def _update_kb_hint(self):
        self._on_kb_toggle(self._kb_toggle.isChecked())

    @staticmethod
    def _select_style(active: bool) -> str:
        if active:
            return (
                "QPushButton{background:#1a2e3a;color:#FF8C00;"
                "border:2px solid #FF8C00;border-radius:8px;"
                "font-size:13px;font-weight:700;}"
                "QPushButton:hover{background:#1e3545;}"
            )
        return (
            f"QPushButton{{background:{COLORS['bg_elevated']};"
            f"color:{COLORS['text_primary']};"
            f"border:1px solid {COLORS['bg_border']};"
            f"border-radius:8px;font-size:13px;}}"
            f"QPushButton:hover{{border-color:{COLORS.get('accent','#888')};}}"
        )

    def _load_values(self):
        is_qwerty = str(self.cfg.get("RW_KeyboardLayout", "azerty")).lower() == "qwerty"
        self._kb_toggle.setChecked(is_qwerty)
        self._on_kb_toggle(is_qwerty)

        self._ed_training_key.setText(str(self.cfg.get("RW_TrainingKey", "e")))

        is_stamina = str(self.cfg.get("RW_StatMode", "speed")).lower() == "stamina"
        self._stat_toggle.setChecked(is_stamina)
        self._on_stat_toggle(is_stamina)

        pos_defaults = {
            "RW_ClickX":      960, "RW_ClickY":      540,
            "RW_SkinDetectX": 960, "RW_SkinDetectY": 540,
            "RW_SpeedX":      900, "RW_SpeedY":      400,
            "RW_StaminaX":   1020, "RW_StaminaY":    400,
        }
        for key, ed in self._pos_eds.items():
            ed.setText(str(self.cfg.get(key, pos_defaults.get(key, 0))))

        self._ed_click_detect_color.setText(
            str(self.cfg.get("RW_ClickDetectColor", ""))
        )
        self._ed_click_detect_tol.setText(
            str(self.cfg.get("RW_ClickDetectTolerance", 12))
        )
        self._ed_click_detect_rad.setText(
            str(self.cfg.get("RW_ClickDetectRadius", 40))
        )

        cycle_defaults = {"RW_Laps": 0, "RW_CycleDelay": 2000}
        for key, ed in self._cycle_eds.items():
            ed.setText(str(self.cfg.get(key, cycle_defaults.get(key, 0))))

        self._ed_speed_adjust.setText(str(self.cfg.get("RW_SpeedAdjustment", 1.0)))

        _STEP_DEFAULTS = [400, 2100, 6810, 6500, 3120, 2460, 1560, 2310, 1740,
                          2100, 950, 270, 1250, 1360, 840, 2770, 1120, 100, 1420, 2000,
                          3000, 500, 583, 0, 0]
        for i, ed in enumerate(self._step_eds):
            ed.setText(str(self.cfg.get(f"RW_StepMs_{i}", _STEP_DEFAULTS[i])))

        self._update_kb_hint()

    def _save_values(self):
        self.cfg.set("RW_KeyboardLayout", "qwerty" if self._kb_toggle.isChecked() else "azerty")

        tk = self._ed_training_key.text().strip() or "e"
        self.cfg.set("RW_TrainingKey", tk)

        self.cfg.set("RW_StatMode", "stamina" if self._stat_toggle.isChecked() else "speed")

        pos_defaults = {
            "RW_ClickX":      960, "RW_ClickY":      540,
            "RW_SkinDetectX": 960, "RW_SkinDetectY": 540,
            "RW_SpeedX":      900, "RW_SpeedY":      400,
            "RW_StaminaX":   1020, "RW_StaminaY":    400,
        }
        for key, ed in self._pos_eds.items():
            try:
                self.cfg.set(key, int(ed.text() or pos_defaults.get(key, 0)))
            except ValueError:
                self.cfg.set(key, pos_defaults.get(key, 0))

        self.cfg.set("RW_ClickDetectColor", self._ed_click_detect_color.text().strip())
        try:
            self.cfg.set(
                "RW_ClickDetectTolerance",
                int(self._ed_click_detect_tol.text() or 12)
            )
        except ValueError:
            self.cfg.set("RW_ClickDetectTolerance", 12)
        try:
            self.cfg.set(
                "RW_ClickDetectRadius",
                int(self._ed_click_detect_rad.text() or 40)
            )
        except ValueError:
            self.cfg.set("RW_ClickDetectRadius", 40)

        cycle_defaults = {"RW_Laps": 0, "RW_CycleDelay": 2000}
        for key, ed in self._cycle_eds.items():
            try:
                self.cfg.set(key, int(ed.text() or cycle_defaults.get(key, 0)))
            except ValueError:
                self.cfg.set(key, cycle_defaults.get(key, 0))

        try:
            speed_adjust = float(self._ed_speed_adjust.text().replace(",", ".") or "1.0")
            speed_adjust = max(0.1, min(5.0, speed_adjust))  # 0.1× à 5.0×, never 0
        except ValueError:
            speed_adjust = 1.0
        self.cfg.set("RW_SpeedAdjustment", speed_adjust)

        _STEP_DEFAULTS = [400, 2100, 6810, 6500, 3120, 2460, 1560, 2310, 1740,
                          2100, 950, 270, 1250, 1360, 840, 2770, 1120, 100, 1420, 2000,
                          3000, 500, 583, 0, 0]
        for i, ed in enumerate(self._step_eds):
            try:
                self.cfg.set(f"RW_StepMs_{i}", max(0, int(ed.text() or _STEP_DEFAULTS[i])))
            except ValueError:
                self.cfg.set(f"RW_StepMs_{i}", _STEP_DEFAULTS[i])
        self.cfg.save_profile()
        self.sig_saved.emit()
        self._btn_save.setText("✓  Saved!")
        QTimer.singleShot(2000,
            lambda: self._btn_save.setText("💾  Save Settings"))

    def _on_select(self):
        if not self._active:
            self.sig_select_rw.emit()

    def set_active(self, active: bool):
        self._active = active
        if active:
            self._btn_select.setText("✅  Roadworks — ACTIVE  (F1 / F2 / F3)")
        else:
            self._btn_select.setText("🚧  Select Roadworks  (F1 / F2 / F3)")
        self._btn_select.setStyleSheet(self._select_style(active))

    def refresh_from_config(self):
        self._load_values()
