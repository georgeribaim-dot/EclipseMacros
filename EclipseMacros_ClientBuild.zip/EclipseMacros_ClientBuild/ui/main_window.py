
import ctypes
import ctypes.wintypes
import os
import math

from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QHBoxLayout, QVBoxLayout,
    QPushButton, QLabel, QFrame, QStackedWidget,
    QSizePolicy, QGraphicsDropShadowEffect,
)
from PyQt6.QtCore import Qt, QTimer, pyqtSlot, QSize, QPropertyAnimation, QEasingCurve
from PyQt6.QtGui import QColor, QIcon, QFont, QPixmap, QPainter, QLinearGradient, QPainterPath, QRadialGradient, QPen, QBrush

from .theme import COLORS, sidebar_btn_style, action_btn_style
from .widgets import StatusIndicator, NeonSeparator
from .dashboard import DashboardPanel
from .config_panel import ConfigPanel
from .profiles_panel import ProfilesPanel
from .hotkeys_panel import HotkeysPanel
from .shadow_boxing_panel import ShadowBoxingPanel
from .roadworks_panel import RoadworksPanel
from .durability_panel import DurabilityPanel
from .strength_panel import StrengthPanel
from .durability_calibration_overlay import DurabilityCalibrationOverlay
from .chrono_panel import ChronoPanel
from .food_panel import FoodPanel
from .food_calibration_overlay import FoodCalibrationOverlay
from .webhook_panel import WebhookPanel

from core.macro_engine import MacroEngine
from core.config_manager import ConfigManager
from core.hotkey_manager import HotkeyManager

def try_enable_mica(hwnd: int):
    try:
        DWMWA_USE_IMMERSIVE_DARK_MODE = 20
        DWMWA_SYSTEMBACKDROP_TYPE     = 38
        DWM_SYSTEMBACKDROP_MICA       = 2
        dwmapi = ctypes.windll.dwmapi
        dark    = ctypes.c_int(1)
        dwmapi.DwmSetWindowAttribute(hwnd, DWMWA_USE_IMMERSIVE_DARK_MODE,
                                     ctypes.byref(dark), ctypes.sizeof(dark))
        backdrop = ctypes.c_int(DWM_SYSTEMBACKDROP_MICA)
        dwmapi.DwmSetWindowAttribute(hwnd, DWMWA_SYSTEMBACKDROP_TYPE,
                                     ctypes.byref(backdrop), ctypes.sizeof(backdrop))
    except Exception:
        pass

def _logo_pixmap(size: int) -> QPixmap:
    assets_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "assets")
    path = os.path.join(assets_dir, "eclipse_logo.png")
    if os.path.isfile(path):
        pm = QPixmap(path)
        scaled = pm.scaled(size * 2, size * 2, Qt.AspectRatioMode.KeepAspectRatio,
                           Qt.TransformationMode.SmoothTransformation)
        sw, sh = scaled.width(), scaled.height()
        cx, cy = (sw - min(sw, sh)) // 2, (sh - min(sw, sh)) // 2
        cropped = scaled.copy(cx, cy, min(sw, sh), min(sw, sh))
        return cropped.scaled(size, size, Qt.AspectRatioMode.KeepAspectRatio,
                              Qt.TransformationMode.SmoothTransformation)
    pm = QPixmap(size, size)
    pm.fill(Qt.GlobalColor.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(QColor("#9030D0"))
    p.drawEllipse(2, 2, size - 4, size - 4)
    p.setBrush(QColor("#050505"))
    p.drawEllipse(size // 5, 2, size - 4, size - 4)
    p.end()
    return pm

def _macro_icon_pixmap(name: str, size: int = 28) -> QPixmap:
    assets_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "assets")
    path = os.path.join(assets_dir, name)
    if os.path.isfile(path):
        pm = QPixmap(path)
        return pm.scaled(size, size, Qt.AspectRatioMode.KeepAspectRatio,
                         Qt.TransformationMode.SmoothTransformation)
    return QPixmap()

class EclipseBackground(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self._angle = 0.0
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)
        self._timer.start(50)

    def _tick(self):
        self._angle = (self._angle + 0.5) % 360
        self.update()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        w, h = self.width(), self.height()
        cx, cy = w // 2, h // 2
        r = min(w, h) * 0.42
        ar = math.radians(self._angle)

        rg = QRadialGradient(cx, cy, r * 1.1)
        rg.setColorAt(0,    QColor(80, 0, 140, 0))
        rg.setColorAt(0.75, QColor(80, 0, 140, 8))
        rg.setColorAt(0.92, QColor(140, 30, 220, 18))
        rg.setColorAt(1.0,  QColor(80, 0, 140, 0))
        p.setBrush(QBrush(rg))
        p.setPen(Qt.PenStyle.NoPen)
        p.drawEllipse(int(cx - r * 1.1), int(cy - r * 1.1),
                      int(r * 2.2), int(r * 2.2))

        ring_pen = QPen(QColor(160, 40, 255, 30), 1.5)
        p.setPen(ring_pen)
        p.setBrush(Qt.BrushStyle.NoBrush)
        from PyQt6.QtCore import QRectF
        rect = QRectF(cx - r, cy - r, r * 2, r * 2)
        p.drawArc(rect, int(self._angle * 16), int(220 * 16))

        bright_pen = QPen(QColor(210, 80, 255, 90), 2)
        p.setPen(bright_pen)
        p.drawArc(rect, int(self._angle * 16), int(40 * 16))
        p.end()

class SidebarNav(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedWidth(210)
        self.setStyleSheet(
            f"background:{COLORS['sidebar_bg']};"
            f"border-right:1px solid {COLORS['bg_border']};"
        )
        self._btns:  list[QPushButton] = []
        self._active = 0

        self._bg = EclipseBackground(self)
        self._bg.setGeometry(0, 0, 210, 600)
        self._bg.lower()

        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)

        header = QWidget()
        header.setFixedHeight(96)
        header.setStyleSheet(
            f"background: qlineargradient(x1:0, y1:0, x2:1, y2:1,"
            f"stop:0 {COLORS['bg_elevated']}, stop:1 {COLORS['sidebar_bg']});"
            f"border-bottom:1px solid {COLORS['neon_border']};"
        )
        h_lay = QHBoxLayout(header)
        h_lay.setContentsMargins(14, 12, 14, 12)
        h_lay.setSpacing(10)

        lbl_logo = QLabel()
        lbl_logo.setPixmap(_logo_pixmap(58))
        lbl_logo.setFixedSize(60, 56)
        lbl_logo.setScaledContents(False)
        lbl_logo.setStyleSheet("background: transparent;")
        lbl_logo.setAlignment(Qt.AlignmentFlag.AlignCenter)
        h_lay.addWidget(lbl_logo)

        txt_col = QVBoxLayout(); txt_col.setSpacing(1)
        lbl_title = QLabel("ECLIPSE")
        lbl_title.setStyleSheet(
            f"color:{COLORS['accent_gold']};"
            f"font-size:13px;font-weight:300;letter-spacing:4px;"
        )
        txt_col.addWidget(lbl_title)
        lbl_sub = QLabel("ASURA MACRO")
        lbl_sub.setStyleSheet(
            f"color:{COLORS['text_dim']};font-size:7px;letter-spacing:2px;"
        )
        txt_col.addWidget(lbl_sub)
        h_lay.addLayout(txt_col)
        lay.addWidget(header)

        ver_w = QWidget()
        ver_w.setStyleSheet("background: transparent;")
        ver_lay = QHBoxLayout(ver_w)
        ver_lay.setContentsMargins(14, 4, 14, 4)
        ver_lbl = QLabel("v3.2  ·  WINDOWS")
        ver_lbl.setStyleSheet(
            f"color:{COLORS['text_dim']};font-size:8px;letter-spacing:2px;"
        )
        ver_lay.addWidget(ver_lbl)
        ver_lay.addStretch()
        lay.addWidget(ver_w)

        lay.addWidget(NeonSeparator())

        nav_section = QLabel("NAVIGATION")
        nav_section.setStyleSheet(
            f"color:{COLORS['text_dim']};font-size:8px;font-weight:700;"
            f"letter-spacing:2px;padding:10px 16px 4px 16px;"
        )
        lay.addWidget(nav_section)

        self._lay = lay
        lay.addStretch()

        bottom = QWidget()
        bottom.setStyleSheet(
            f"background:{COLORS['bg_surface']};"
            f"border-top:1px solid {COLORS['bg_border']};"
        )
        b_lay = QVBoxLayout(bottom)
        b_lay.setContentsMargins(14, 10, 14, 10)
        b_lay.setSpacing(4)

        status_row = QHBoxLayout()
        self._status_dot = StatusIndicator()
        status_row.addWidget(self._status_dot)
        self._status_lbl = QLabel("Ready")
        self._status_lbl.setStyleSheet(f"color:{COLORS['text_secondary']};font-size:11px;")
        status_row.addWidget(self._status_lbl)
        status_row.addStretch()
        b_lay.addLayout(status_row)

        self._mode_lbl = QLabel("Mode: Trials")
        self._mode_lbl.setStyleSheet(f"color:{COLORS['text_dim']};font-size:9px;letter-spacing:1px;")
        b_lay.addWidget(self._mode_lbl)

        hint = QLabel("F1  Start   ·   F3  Stop")
        hint.setStyleSheet(f"color:{COLORS['text_dim']};font-size:8px;letter-spacing:0.5px;")
        b_lay.addWidget(hint)

        lay.addWidget(bottom)

    def resizeEvent(self, e):
        super().resizeEvent(e)
        self._bg.setGeometry(0, 0, self.width(), self.height())

    def add_nav_button(self, icon, text, index, on_click, img_file=None):
        btn = QWidget()
        btn.setFixedHeight(42)
        btn.setCursor(Qt.CursorShape.PointingHandCursor)
        btn.setObjectName(f"nav_btn_{index}")

        btn_layout = QHBoxLayout(btn)
        btn_layout.setContentsMargins(14, 0, 0, 0)
        btn_layout.setSpacing(9)

        if img_file:
            assets_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "assets")
            path = os.path.join(assets_dir, img_file)
            if os.path.isfile(path):
                pm = QPixmap(path).scaled(24, 24, Qt.AspectRatioMode.KeepAspectRatio,
                                          Qt.TransformationMode.SmoothTransformation)
                lbl_ic = QLabel()
                lbl_ic.setPixmap(pm)
                lbl_ic.setFixedSize(24, 24)
                lbl_ic.setStyleSheet("background: transparent;")
                btn_layout.addWidget(lbl_ic)
            else:
                lbl_ic = QLabel(icon)
                lbl_ic.setStyleSheet(f"color:{COLORS['text_dim']};font-size:11px;background:transparent;")
                btn_layout.addWidget(lbl_ic)
        else:
            lbl_ic = QLabel(icon)
            lbl_ic.setStyleSheet(f"color:{COLORS['text_dim']};font-size:11px;background:transparent;")
            btn_layout.addWidget(lbl_ic)

        lbl_txt = QLabel(text)
        lbl_txt.setObjectName(f"nav_lbl_{index}")
        lbl_txt.setStyleSheet(f"color:{COLORS['sidebar_txt']};font-size:11px;letter-spacing:1px;background:transparent;")
        btn_layout.addWidget(lbl_txt)
        btn_layout.addStretch()

        self._accent_bars = getattr(self, '_accent_bars', {})
        self._accent_bars[index] = lbl_txt

        def _click(e=None, idx=index): on_click(idx)
        btn.mousePressEvent = _click

        self._lay.insertWidget(self._lay.count() - 2, btn)
        self._btns.append(btn)
        return btn

    def set_active(self, index: int):
        self._active = index
        c = COLORS
        for i, btn in enumerate(self._btns):
            selected = (i == index)
            if selected:
                btn.setStyleSheet(
                    f"QWidget#nav_btn_{i} {{"
                    f"background: qlineargradient(x1:0,y1:0,x2:1,y2:0,"
                    f"stop:0 {c['bg_active']}, stop:1 transparent);"
                    f"border-left: 2px solid {c['accent_glow']};"
                    f"border-top: none; border-bottom: none; border-right: none;}}"
                )
            else:
                btn.setStyleSheet(
                    f"QWidget#nav_btn_{i} {{"
                    f"background: transparent;"
                    f"border: none;}}"
                )
            lbl = getattr(self, '_accent_bars', {}).get(i)
            if lbl:
                if selected:
                    lbl.setStyleSheet(f"color:{c['accent_gold']};font-size:11px;font-weight:600;letter-spacing:1px;background:transparent;")
                else:
                    lbl.setStyleSheet(f"color:{c['sidebar_txt']};font-size:11px;letter-spacing:1px;background:transparent;")

    def set_status(self, running: bool, paused: bool = False):
        if running and not paused:
            self._status_dot.set_state("running")
            self._status_lbl.setText("Running")
            self._status_lbl.setStyleSheet(f"color:{COLORS['accent_ok']};font-size:11px;")
        elif running and paused:
            self._status_dot.set_state("paused")
            self._status_lbl.setText("Paused")
            self._status_lbl.setStyleSheet(f"color:{COLORS['accent_warn']};font-size:11px;")
        else:
            self._status_dot.set_state("idle")
            self._status_lbl.setText("Ready")
            self._status_lbl.setStyleSheet(f"color:{COLORS['text_secondary']};font-size:11px;")

    def set_mode_label(self, mode: str):
        labels = {
            "trial":     "Mode: Trials",
            "shadow":    "Mode: Shadow Boxing",
            "roadworks": "Mode: Roadworks",
            "durability":"Mode: Durability",
            "strength":  "Mode: Strength",
            "food":      "Mode: Food",
        }
        self._mode_lbl.setText(labels.get(mode, "Mode: Unknown"))

class MainWindow(QMainWindow):
    def __init__(self, config: ConfigManager):
        super().__init__()
        self.cfg          = config
        self.engine       = MacroEngine(config.as_dict())
        self.hotkey_mgr   = HotkeyManager()
        # Restore saved hotkeys from config
        saved_bindings = {}
        for action in ["start", "pause", "stop", "show_ui", "pixel", "calibration"]:
            val = config.get_str(f"HK_{action}")
            if val:
                saved_bindings[action] = val
        if saved_bindings:
            self.hotkey_mgr.update_bindings(saved_bindings)
        self._is_running  = False
        self._is_paused   = False
        self._macro_mode  = "trial"
        self._k_enabled   = bool(config.get_int("DUR_KToggleEnabled") if config.get("DUR_KToggleEnabled") is not None else 1)
        self._j_enabled   = bool(int(config.get("FAT_JEnabled", 1)))
        self._food_overlay = FoodCalibrationOverlay(config)
        self._food_overlay.point_updated = self._on_food_point_updated
        self._f10_enabled = bool(config.get_int("F10ToggleEnabled")   if config.get("F10ToggleEnabled")   is not None else 1)

        self._calibration_overlay = DurabilityCalibrationOverlay(config)
        self._calibration_overlay.points_updated.connect(self._on_calibration_points_updated)
        # Restore sub_mode from config so overlay knows which points to show on K press
        _saved_submode = config.get("DUR_SubMode", "selfish_v1")
        self._calibration_overlay.set_sub_mode(_saved_submode)

        self._setup_window()
        self._build_ui()
        self._connect_signals()
        self._connect_hotkeys()
        self.hotkey_mgr.register_all()
        if not self._f10_enabled:
            self.hotkey_mgr.set_hotkey_enabled("pixel", False)
        if not self._k_enabled:
            self.hotkey_mgr.set_hotkey_enabled("calibration", False)
        if not self._j_enabled:
            self.hotkey_mgr.set_hotkey_enabled("fat_calibration", False)
        self._set_macro_mode("trial")

    def _setup_window(self):
        self.setWindowTitle("Eclipse — Asura Macro")
        self.setMinimumSize(920, 580)
        self.resize(980, 640)
        self.setStyleSheet(f"background:{COLORS['bg_base']};")

        assets_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "assets")
        for ico in ("eclipse_logo.ico", "eclipse_logo.png"):
            p = os.path.join(assets_dir, ico)
            if os.path.isfile(p):
                self.setWindowIcon(QIcon(p))
                break

        from PyQt6.QtWidgets import QApplication
        screen = QApplication.primaryScreen().geometry()
        self.move((screen.width() - 980) // 2, (screen.height() - 640) // 2)
        QTimer.singleShot(50, self._apply_mica)

    def _apply_mica(self):
        try:
            hwnd = int(self.winId())
            try_enable_mica(hwnd)
        except Exception:
            pass

    def _build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)

        root = QHBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        self.sidebar = SidebarNav()

        nav_items = [
            ("⬡", "Dashboard",     0, "dashboard_logo.png"),
            ("⛩", "Trials",        1, "trials_logo.png"),
            ("⬡", "Shadow Boxing", 2, "shadow_boxing_logo.png"),
            ("⬡", "Roadworks",     3, "roadworks_logo.png"),
            ("⬡", "Durability",    4, "durability_logo.png"),
            ("⬡", "Strength",      5, "strength_logo.png"),
            ("⬡", "Food",          6, "food_logo.png"),
            ("⧗", "Timers",        7, "timer_logo.png"),
            ("⬡", "Webhook",       8, "webhook_logo.png"),
            ("◈", "Profiles",      9, "profile_logo.png"),
            ("⚙", "Settings",     10, "settings_logo.png"),
        ]
        for icon, label, idx, img_file in nav_items:
            self.sidebar.add_nav_button(icon, label, idx, self._switch_panel, img_file)

        root.addWidget(self.sidebar)

        content_frame = QFrame()
        content_frame.setStyleSheet(f"background:{COLORS['bg_base']};")
        c_lay = QVBoxLayout(content_frame)
        c_lay.setContentsMargins(0, 0, 0, 0)
        c_lay.setSpacing(0)

        top_bar = QFrame()
        top_bar.setFixedHeight(40)
        top_bar.setStyleSheet(
            f"background:{COLORS['bg_surface']};"
            f"border-bottom:1px solid {COLORS['bg_border']};"
        )
        tb_lay = QHBoxLayout(top_bar)
        tb_lay.setContentsMargins(16, 0, 16, 0)
        tb_lay.setSpacing(0)

        self._tb_title = QLabel("DASHBOARD")
        self._tb_title.setStyleSheet(
            f"color:{COLORS['text_dim']};font-size:9px;font-weight:700;letter-spacing:3px;"
        )
        tb_lay.addWidget(self._tb_title)
        tb_lay.addStretch()

        self._tb_status = QLabel("◉  IDLE")
        self._tb_status.setStyleSheet(
            f"color:{COLORS['text_dim']};font-size:9px;letter-spacing:1px;"
        )
        tb_lay.addWidget(self._tb_status)
        c_lay.addWidget(top_bar)

        self.stack = QStackedWidget()
        self.stack.setStyleSheet("background:transparent;")

        self.panel_dashboard  = DashboardPanel(cfg=self.cfg)
        self.panel_config     = ConfigPanel(self.cfg)
        self.panel_shadow     = ShadowBoxingPanel(self.cfg)
        self.panel_roadworks  = RoadworksPanel(self.cfg)
        self.panel_durability = DurabilityPanel(self.cfg)
        self.panel_strength   = StrengthPanel(self.cfg)
        self.engine._roadworks_panel_ref = self.panel_roadworks
        if self.engine._worker is not None:
            self.engine._worker._roadworks_panel = self.panel_roadworks
        self.panel_profiles  = ProfilesPanel(self.cfg)
        self.panel_hotkeys   = HotkeysPanel(self.hotkey_mgr.get_bindings(), self.cfg)
        self.panel_chrono    = ChronoPanel()
        self.panel_webhook   = WebhookPanel()
        self.panel_food      = FoodPanel(self.cfg)

        for panel in [
            self.panel_dashboard, self.panel_config, self.panel_shadow,
            self.panel_roadworks, self.panel_durability, self.panel_strength,
            self.panel_food, self.panel_chrono, self.panel_webhook,
            self.panel_profiles, self.panel_hotkeys,
        ]:
            self.stack.addWidget(panel)

        c_lay.addWidget(self.stack)

        status_bar = QFrame()
        status_bar.setFixedHeight(26)
        status_bar.setStyleSheet(
            f"background:{COLORS['bg_surface']};"
            f"border-top:1px solid {COLORS['bg_border']};"
        )
        sb_lay = QHBoxLayout(status_bar)
        sb_lay.setContentsMargins(14, 0, 14, 0)

        self._sb_left = QLabel(f"Profile: {self.cfg.current_profile}")
        self._sb_left.setStyleSheet(f"color:{COLORS['text_dim']};font-size:9px;letter-spacing:1px;")
        sb_lay.addWidget(self._sb_left)
        sb_lay.addStretch()

        dot = QLabel("·")
        dot.setStyleSheet(f"color:{COLORS['neon_border']};font-size:9px;")
        sb_lay.addWidget(dot)

        self._sb_right = QLabel("Eclipse Macro  ·  Phase: Idle")
        self._sb_right.setStyleSheet(f"color:{COLORS['text_dim']};font-size:9px;letter-spacing:1px;")
        sb_lay.addWidget(self._sb_right)
        c_lay.addWidget(status_bar)

        root.addWidget(content_frame)

        self.sidebar.set_active(0)
        self.panel_dashboard.set_profile_name(self.cfg.current_profile)
        self.panel_dashboard.append_log("Application initialized", "ok")
        self.panel_dashboard.append_log(f"Profile loaded: {self.cfg.current_profile}", "info")

    _PANEL_TITLES = [
        "DASHBOARD", "TRIALS", "SHADOW BOXING", "ROADWORKS",
        "DURABILITY", "STRENGTH", "FOOD", "TIMERS", "WEBHOOK", "PROFILES", "SETTINGS",
    ]

    def _switch_panel(self, index: int):
        self.stack.setCurrentIndex(index)
        self.sidebar.set_active(index)
        title = self._PANEL_TITLES[index] if index < len(self._PANEL_TITLES) else ""
        self._tb_title.setText(title)

    def _set_macro_mode(self, mode: str):
        if self._is_running:
            self._force_stop()
        self._macro_mode = mode
        self.panel_config.set_active(mode == "trial")
        self.panel_shadow.set_active(mode == "shadow")
        self.panel_roadworks.set_active(mode == "roadworks")
        self.panel_durability.set_active(mode == "durability")
        self.panel_strength.set_active(mode == "strength")
        self.panel_food.set_active(mode == "fat")
        self.sidebar.set_mode_label(mode)
        labels = {"trial": "Trials", "shadow": "Shadow Boxing",
                  "roadworks": "Roadworks", "durability": "Durability",
                  "strength": "Strength", "fat": "FAT Macro"}
        self.panel_dashboard.append_log(f"Macro selected: {labels.get(mode, mode)}", "info")

    def _force_stop(self):
        self._is_running = False
        self._is_paused  = False
        self.engine.stop()
        self.panel_dashboard.set_status(False)
        self.sidebar.set_status(False)
        self._tb_status.setText("◉  IDLE")
        self._tb_status.setStyleSheet(f"color:{COLORS['text_dim']};font-size:9px;letter-spacing:1px;")

    def _connect_signals(self):
        self.panel_dashboard.sig_start.connect(self._on_start)
        self.panel_dashboard.sig_stop.connect(self._on_stop)
        self.panel_dashboard.sig_pixel.connect(self._on_pixel_cal)
        self.panel_dashboard.sig_f10_toggle_changed.connect(self._on_f10_toggle_changed)

        self.engine.sig_log.connect(self._on_engine_log)
        self.engine.sig_pixel_status.connect(self.panel_dashboard.set_pixel_status)
        self.engine.sig_pixel_status.connect(self._on_pixel_status)
        self.engine.sig_phase.connect(self._on_phase)
        self.engine.sig_phase.connect(self.panel_webhook.on_phase_changed)
        self.engine.sig_stat.connect(self._on_stats)
        self.engine.sig_stopped.connect(self._on_engine_stopped)
        self.engine.sig_paused.connect(self._on_engine_paused)

        self.panel_config.sig_saved.connect(self._on_config_saved)
        self.panel_shadow.sig_saved.connect(self._on_config_saved)
        self.panel_roadworks.sig_saved.connect(self._on_config_saved)
        self.panel_durability.sig_saved.connect(self._on_config_saved)
        self.panel_strength.sig_saved.connect(self._on_config_saved)
        self.panel_config.sig_detect_window.connect(self._on_detect_window)
        self.panel_config.sig_snap_window.connect(self._on_snap_window)
        self.panel_config.sig_select_trial.connect(lambda: self._set_macro_mode("trial"))

        self.panel_shadow.sig_select_sb.connect(lambda: self._set_macro_mode("shadow"))
        self.panel_roadworks.sig_select_rw.connect(lambda: self._set_macro_mode("roadworks"))
        self.panel_durability.sig_select_dur.connect(lambda: self._set_macro_mode("durability"))
        self.panel_strength.sig_select_str.connect(lambda: self._set_macro_mode("strength"))

        self.panel_durability.sig_detect_win1.connect(self._on_detect_dur_win1)
        self.panel_durability.sig_detect_win2.connect(self._on_detect_dur_win2)
        self.panel_durability.sig_k_toggle_changed.connect(self._on_k_toggle_changed)
        self.panel_durability.sig_submode_changed.connect(self._on_dur_submode_changed)

        self.panel_profiles.sig_profile_loaded.connect(self._on_profile_loaded)
        self.panel_hotkeys.sig_saved.connect(self._on_hotkeys_saved)
        self.panel_hotkeys.sig_detect_window.connect(self._on_detect_window)
        self.panel_hotkeys.sig_snap_window.connect(self._on_snap_window)
        self.panel_hotkeys.sig_start_food.connect(self._on_start_food)
        self.panel_hotkeys.sig_stop_food.connect(self._on_stop_food)
        self.panel_food.sig_select_fat.connect(lambda: self._set_macro_mode("fat"))
        self.panel_food.sig_j_toggle_changed.connect(self._on_j_toggle_changed)

    def _connect_hotkeys(self):
        self.hotkey_mgr.sig_start.connect(self._on_start)
        self.hotkey_mgr.sig_stop.connect(self._on_stop)
        self.hotkey_mgr.sig_pixel.connect(self._on_pixel_cal)
        self.hotkey_mgr.sig_show_ui.connect(self.show_and_raise)
        self.hotkey_mgr.sig_calibration.connect(self._on_calibration_toggle)
        self.hotkey_mgr.sig_fat_calibration.connect(self._on_fat_calibration_toggle)

    @pyqtSlot()
    def _on_start(self):
        if self._is_running: return
        self._is_running = True
        self._is_paused  = False
        self.engine.update_config(self.cfg.as_dict())

        # Resolve durability sub-mode
        dur_submode = self.cfg.get("DUR_SubMode", "selfish_v1_dur")
        if dur_submode == "selfish_v3":
            dur_method = "start_selfish_v3"
            dur_label  = "Selfish V3 started — F3 Stop"
        else:
            dur_method = "start_selfish_v1"
            dur_label  = "Durability started — F3 Stop"

        msg_map = {
            "shadow":    ("start_shadow_boxing", "Shadow Boxing started — F3 Stop"),
            "roadworks": ("start_roadworks",     "Roadworks started — F3 Stop"),
            "durability":(dur_method,            dur_label),
            "strength":  ("start_strength",      "Strength started — F3 Stop"),
        }
        if self._macro_mode == "fat":
            self.panel_food.save_to_config()
            profile = self.cfg.get("FAT_Profile", "Burger")
            self.cfg.set("FAT_Profile", profile)
            self.engine.update_config(self.cfg.as_dict())
            self.engine.start_fat()
            self.panel_food.set_fat_running(True)
            self._macro_mode = "fat"
            self._tb_status.setText("◉  FAT MACRO")
            self._tb_status.setStyleSheet(f"color:{COLORS['accent_ok']};font-size:9px;letter-spacing:1px;")
            self.panel_dashboard.append_log(f"FAT Macro started [{profile}] — F3 Stop", "ok")
        elif self._macro_mode in msg_map:
            method, msg = msg_map[self._macro_mode]
            getattr(self.engine, method)()
            self.panel_dashboard.append_log(msg, "ok")
        else:
            self.engine.start()
            self.panel_dashboard.append_log("Trials macro started — F3 Stop", "ok")

        self.panel_dashboard.set_status(True, False)
        self.sidebar.set_status(True, False)
        self.panel_webhook.on_macro_started()
        self._tb_status.setText("◉  RUNNING")
        self._tb_status.setStyleSheet(f"color:{COLORS['accent_ok']};font-size:9px;letter-spacing:1px;")

    @pyqtSlot()
    def _on_pause(self):
        if not self._is_running: return
        self._is_paused = not self._is_paused
        self.engine.pause_toggle()
        self.panel_dashboard.set_status(True, self._is_paused)
        self.sidebar.set_status(True, self._is_paused)
        if self._is_paused:
            self._tb_status.setText("◉  PAUSED")
            self._tb_status.setStyleSheet(f"color:{COLORS['accent_warn']};font-size:9px;letter-spacing:1px;")
        else:
            self._tb_status.setText("◉  RUNNING")
            self._tb_status.setStyleSheet(f"color:{COLORS['accent_ok']};font-size:9px;letter-spacing:1px;")

    @pyqtSlot()
    def _on_stop(self):
        self._is_running = False
        self._is_paused  = False
        self.engine.stop()
        self.panel_dashboard.set_status(False)
        self.sidebar.set_status(False)
        if self._macro_mode == "fat":
            self.panel_food.set_fat_running(False)
            self.panel_food.set_active(False)
        elif self._macro_mode == "food":
            self.panel_hotkeys.set_food_running(False)
        self._tb_status.setText("◉  IDLE")
        self._tb_status.setStyleSheet(f"color:{COLORS['text_dim']};font-size:9px;letter-spacing:1px;")

    @pyqtSlot()
    def _on_start_food(self):
        if self._is_running:
            return
        self._is_running = True
        self._is_paused  = False
        self._macro_mode = "food"
        self.engine.update_config(self.cfg.as_dict())
        self.engine.start_food()
        self.panel_dashboard.set_status(True, False)
        self.sidebar.set_status(True, False)
        self.panel_hotkeys.set_food_running(True)
        self._tb_status.setText("◉  FOOD LOOP")
        self._tb_status.setStyleSheet(f"color:{COLORS['accent_ok']};font-size:9px;letter-spacing:1px;")
        self.panel_dashboard.append_log("Food Loop started — F3 to stop", "ok")

    @pyqtSlot()
    def _on_stop_food(self):
        self._is_running = False
        self._is_paused  = False
        self.engine.stop()
        self.panel_dashboard.set_status(False)
        self.sidebar.set_status(False)
        self.panel_hotkeys.set_food_running(False)
        self._tb_status.setText("◉  IDLE")
        self._tb_status.setStyleSheet(f"color:{COLORS['text_dim']};font-size:9px;letter-spacing:1px;")

    @pyqtSlot()
    def _on_pixel_cal(self):
        if not self._f10_enabled: return
        info = self.engine.get_pixel_info()
        from PyQt6.QtWidgets import QMessageBox
        QMessageBox.information(self, "Pixel Calibration",
            f"Mouse position:\n\n  X = {info['x']}\n  Y = {info['y']}\n  Color = {info['color']}\n\n"
            "Copy these values into Configuration → Customization.")

    @pyqtSlot(bool)
    def _on_f10_toggle_changed(self, enabled: bool):
        self._f10_enabled = enabled
        self.hotkey_mgr.set_hotkey_enabled("pixel", enabled)
        self.panel_dashboard.append_log(f"F10 key {'enabled' if enabled else 'disabled'}", "info")

    @pyqtSlot()
    def _on_fat_calibration_toggle(self):
        if self._j_enabled:
            self._food_overlay.toggle_visibility()

    @pyqtSlot(bool)
    def _on_j_toggle_changed(self, enabled: bool):
        self._j_enabled = enabled
        self.hotkey_mgr.set_hotkey_enabled("fat_calibration", enabled)
        if not enabled and self._food_overlay.is_visible():
            self._food_overlay.hide_point()
        self.panel_dashboard.append_log(f"J key {'enabled' if enabled else 'disabled'}", "info")

    def _on_food_point_updated(self, x: int, y: int):
        self.cfg.set("FAT_ClickX", x)
        self.cfg.set("FAT_ClickY", y)
        self.cfg.save_profile()
        self.engine.update_config(self.cfg.as_dict())
        self.panel_food.update_click_pos(x, y)

    @pyqtSlot(str)
    @pyqtSlot()
    def _on_calibration_toggle(self):
        if self._k_enabled:
            self._calibration_overlay.toggle_visibility()

    @pyqtSlot(bool)
    def _on_k_toggle_changed(self, enabled: bool):
        self._k_enabled = enabled
        self.hotkey_mgr.set_hotkey_enabled("calibration", enabled)
        if not enabled and self._calibration_overlay.is_visible():
            self._calibration_overlay.hide_points()
        self.panel_dashboard.append_log(f"K key {'enabled' if enabled else 'disabled'}", "info")

    @pyqtSlot(str)
    def _on_dur_submode_changed(self, mode: str):
        self.cfg.set("DUR_SubMode", mode)
        self.cfg.save_profile()
        self._calibration_overlay.set_sub_mode(mode)
        self.panel_dashboard.append_log(f"Durability mode set to: {mode}", "info")

    @pyqtSlot(str, str)
    def _on_engine_log(self, msg: str, level: str):
        self.panel_dashboard.append_log(msg, level)

    @pyqtSlot(str)
    def _on_phase(self, phase: str):
        self.panel_dashboard.set_phase(phase)
        self._sb_right.setText(f"Phase: {phase}  ·  Eclipse Macro")

    @pyqtSlot(dict)
    def _on_stats(self, stats: dict):
        self.panel_dashboard.update_stats(stats)

    @pyqtSlot()
    def _on_engine_stopped(self):
        self._is_running = False
        self._is_paused  = False
        self.panel_dashboard.set_status(False)
        self.sidebar.set_status(False)
        self.panel_dashboard.set_pixel_status("health",  True)
        self.panel_dashboard.set_pixel_status("stamina", True)
        self.panel_webhook.on_macro_stopped()
        self.panel_hotkeys.set_food_running(False)
        self._tb_status.setText("◉  IDLE")
        self._tb_status.setStyleSheet(f"color:{COLORS['text_dim']};font-size:9px;letter-spacing:1px;")

    @pyqtSlot(str, bool)
    def _on_pixel_status(self, pixel: str, present: bool):
        if pixel == "food":
            self.panel_hotkeys.set_food_pixel_status(present)

    @pyqtSlot(bool)
    def _on_engine_paused(self, paused: bool):
        self._is_paused = paused
        self.panel_dashboard.set_status(True, paused)
        self.sidebar.set_status(True, paused)

    @pyqtSlot()
    def _on_detect_window(self):
        from PyQt6.QtWidgets import QMessageBox
        msg = QMessageBox(self)
        msg.setWindowTitle("Detect Game Window")
        msg.setText(
            "<b>Click OK, then immediately click on the Roblox window.</b><br><br>"
            "Detection will happen in <b>2 seconds</b> after clicking OK."
        )
        msg.setIcon(QMessageBox.Icon.Information)
        msg.setStandardButtons(QMessageBox.StandardButton.Ok | QMessageBox.StandardButton.Cancel)
        if msg.exec() != QMessageBox.StandardButton.Ok:
            return
        self.hide()
        self._detect_gw_timer = QTimer(self)
        self._detect_gw_timer.setSingleShot(True)
        self._detect_gw_timer.timeout.connect(self._detect_window_tick)
        self._detect_gw_timer.start(2000)

    def _detect_window_tick(self):
        from PyQt6.QtWidgets import QMessageBox
        hwnd, title = self.engine.detect_foreground_hwnd()
        self.showNormal(); self.raise_(); self.activateWindow()
        if hwnd and title:
            self.panel_config.set_detected_title(title)
            self.panel_hotkeys.set_detected_title(title)
            self.panel_dashboard.append_log(f"Window detected: {title} (HWND {hwnd})", "ok")
            QMessageBox.information(self, "Window Detected",
                f"Detected window:\n\n  « {title} »\n  HWND: {hwnd}\n\n"
                "The GameTitle field has been updated.\nClick Save to confirm.")
        else:
            QMessageBox.warning(self, "Detection Failed",
                "No foreground window detected.\n"
                "Make sure the Roblox window is in focus within 2 seconds of clicking OK.")

    @pyqtSlot()
    def _on_snap_window(self):
        self.engine.update_config(self.cfg.as_dict())
        self.engine.snap_window_now()
        self.panel_dashboard.append_log("Window repositioned (1/5 screen)", "ok")

    @pyqtSlot()
    def _on_config_saved(self):
        self.engine.update_config(self.cfg.as_dict())
        self.panel_dashboard.append_log("Configuration saved", "ok")

    @pyqtSlot(dict)
    def _on_calibration_points_updated(self, updates: dict):
        """Called when calibration points are dragged — auto-saves positions."""
        for k, v in updates.items():
            self.cfg.set(k, v)
        self.cfg.save_profile()
        self.engine.update_config(self.cfg.as_dict())

    @pyqtSlot(str)
    def _on_profile_loaded(self, name: str):
        self.panel_config.refresh_from_config()
        self.panel_shadow.refresh_from_config()
        self.panel_roadworks.refresh_from_config()
        self.panel_durability.refresh_from_config()
        self.panel_hotkeys.refresh_from_config()
        self.panel_food.refresh_from_config()
        self.panel_dashboard.set_profile_name(name)
        self.engine.update_config(self.cfg.as_dict())
        self._sb_left.setText(f"Profile: {name}")
        self.panel_dashboard.append_log(f"Profile loaded: {name}", "ok")

    @pyqtSlot(dict)
    def _on_hotkeys_saved(self, bindings: dict):
        self.hotkey_mgr.update_bindings(bindings)
        self.engine.update_config(self.cfg.as_dict())
        self.panel_dashboard.append_log("Settings saved", "ok")

    @pyqtSlot()
    def show_and_raise(self):
        self.showNormal()
        self.raise_()
        self.activateWindow()

    @pyqtSlot()
    def _on_detect_dur_win1(self):
        self._start_dur_detect(slot=1)

    @pyqtSlot()
    def _on_detect_dur_win2(self):
        self._start_dur_detect(slot=2)

    def _start_dur_detect(self, slot: int):
        from PyQt6.QtWidgets import QMessageBox
        msg = QMessageBox(self)
        msg.setWindowTitle(f"Assign Window {slot}")
        msg.setText(
            f"<b>Click OK, then immediately click on Roblox window {slot}.</b><br><br>"
            f"Detection will happen in <b>2 seconds</b> after clicking OK."
        )
        msg.setIcon(QMessageBox.Icon.Information)
        msg.setStandardButtons(QMessageBox.StandardButton.Ok | QMessageBox.StandardButton.Cancel)
        if msg.exec() != QMessageBox.StandardButton.Ok:
            return
        self.hide()
        self._detect_slot = slot
        self._detect_timer = QTimer(self)
        self._detect_timer.setSingleShot(True)
        self._detect_timer.timeout.connect(self._dur_detect_tick)
        self._detect_timer.start(2000)

    def _dur_detect_tick(self):
        from PyQt6.QtWidgets import QMessageBox
        slot = self._detect_slot
        hwnd, title = self.engine.detect_foreground_hwnd()
        self.showNormal(); self.raise_(); self.activateWindow()
        if hwnd:
            self.engine.set_dur_hwnd(slot, hwnd)
            if slot == 1: self.panel_durability.set_detected_title1(title)
            else:         self.panel_durability.set_detected_title2(title)
            self.panel_dashboard.append_log(f"Window {slot} assigned: {title} (HWND {hwnd})", "ok")
            QMessageBox.information(self, f"Window {slot} Assigned",
                f"Captured window:\n\n  « {title} »\n  HWND: {hwnd}\n\n"
                f"The macro will use this HWND for window {slot}.\nClick Save to confirm.")
        else:
            QMessageBox.warning(self, "Detection Failed",
                f"No window detected for slot {slot}.\n"
                "Try again by clicking on Roblox within 3 seconds of clicking OK.")

    def closeEvent(self, event):
        if self._is_running:
            self.engine.stop()
        self.hotkey_mgr.unregister_all()
        event.accept()
