
import os
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame,
    QPushButton, QLineEdit, QScrollArea, QGridLayout, QComboBox,
)
from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QPixmap, QIntValidator

from .theme import COLORS, sidebar_btn_style
from .widgets import AnimatedToggle
from core.config_manager import ConfigManager

def _durability_pixmap(size: int) -> QPixmap:
    assets = os.path.join(os.path.dirname(os.path.dirname(__file__)), "assets")
    path   = os.path.join(assets, "durability_logo.png")
    if os.path.isfile(path):
        pm = QPixmap(path)
        return pm.scaled(size, size,
                         Qt.AspectRatioMode.KeepAspectRatio,
                         Qt.TransformationMode.SmoothTransformation)
    pm = QPixmap(size, size)
    pm.fill(Qt.GlobalColor.transparent)
    return pm

def _sec(txt):
    l = QLabel(txt)
    l.setStyleSheet(
        f"color:{COLORS['accent_gold']};font-size:10px;"
        f"font-weight:700;letter-spacing:2px;padding-bottom:4px;"
    )
    return l

def _fld(txt):
    l = QLabel(txt)
    l.setStyleSheet(f"color:{COLORS['text_secondary']};font-size:11px;")
    return l

def _dim(txt):
    l = QLabel(txt)
    l.setStyleSheet(f"color:{COLORS['text_dim']};font-size:10px;")
    return l

def _le(ph="", int_only=False, w=None):
    e = QLineEdit()
    e.setPlaceholderText(ph)
    if int_only:
        e.setValidator(QIntValidator(0, 99999))
    e.setFixedHeight(28)
    if w:
        e.setFixedWidth(w)
    e.setStyleSheet(f"""
        QLineEdit{{background:{COLORS['bg_elevated']};
        border:1px solid {COLORS['bg_border']};border-radius:6px;
        color:{COLORS['text_primary']};font-size:12px;padding:0 8px;}}
        QLineEdit:focus{{border:1px solid {COLORS['accent']};}}
    """)
    return e

def _card_frame():
    f = QFrame()
    f.setStyleSheet(
        f"QFrame{{background:{COLORS['bg_elevated']};"
        f"border:1px solid {COLORS['bg_border']};border-radius:10px;}}"
    )
    return f

def _separator():
    sep = QFrame()
    sep.setFrameShape(QFrame.Shape.HLine)
    sep.setStyleSheet(f"color:{COLORS['bg_border']};margin:2px 0;")
    return sep

def _xy_row(label, key_x, key_y, fields_dict, parent_layout):
    row = QHBoxLayout(); row.setSpacing(8)
    row.addWidget(_fld(label)); row.addStretch()
    le_x = _le(str(key_x), int_only=True, w=70)
    le_y = _le(str(key_y), int_only=True, w=70)
    row.addWidget(_dim("X")); row.addWidget(le_x)
    row.addWidget(_dim("Y")); row.addWidget(le_y)
    parent_layout.addLayout(row)
    fields_dict[key_x] = le_x
    fields_dict[key_y] = le_y

def _pixel_block(title, px_key, py_key, color_key, tol_key, fields_dict, parent_layout):
    parent_layout.addWidget(_fld(title))
    g = QGridLayout(); g.setSpacing(6); g.setContentsMargins(0, 0, 0, 4)
    for col_i, (lbl, key, ph) in enumerate([
        ("X", px_key, "960"), ("Y", py_key, "540"),
        ("Color", color_key, "0xFFFFFF"), ("Tol", tol_key, "20")
    ]):
        hdr = QLabel(lbl)
        hdr.setStyleSheet(f"color:{COLORS['text_dim']};font-size:10px;")
        g.addWidget(hdr, 0, col_i)
        is_int = key.endswith(("_X", "_Y", "_Tol", "_Tolerance"))
        le = _le(ph, int_only=is_int,
                 w=72 if col_i < 2 else 90 if col_i == 2 else 50)
        g.addWidget(le, 1, col_i)
        fields_dict[key] = le
    parent_layout.addLayout(g)

def _key_row(label, cfg_key, ph, fields_dict, parent_layout):
    row = QHBoxLayout(); row.setSpacing(8)
    row.addWidget(_fld(label))
    le = _le(ph, w=60)
    fields_dict[cfg_key] = le
    row.addWidget(le); row.addStretch()
    parent_layout.addLayout(row)

def _detect_btn(text):
    btn = QPushButton(text)
    btn.setFixedHeight(32)
    btn.setStyleSheet(
        f"QPushButton{{background:{COLORS['bg_base']};"
        f"color:{COLORS['text_secondary']};border:1px solid {COLORS['bg_border']};"
        f"border-radius:6px;font-size:11px;font-weight:600;}}"
        f"QPushButton:hover{{border-color:{COLORS['accent']};"
        f"color:{COLORS['text_primary']};}}"
    )
    return btn

# Sub-mode items: (display_label, config_value)
SUB_MODES = [
    ("Selfish V1", "selfish_v1"),
    ("Selfish V2", "selfish_v2"),
    ("Selfish V3", "selfish_v3"),
    ("Durability",  "selfish_v1_dur"),
]

# Sidebar sections common to all modes
SECTIONS_COMMON = ["Windows", "Window 1", "Window 2"]
# Extra section only for V3
SECTION_V3 = "Selfish V3"


class DurabilityPanel(QWidget):
    sig_select_dur       = pyqtSignal()
    sig_detect_win1      = pyqtSignal()
    sig_detect_win2      = pyqtSignal()
    sig_k_toggle_changed = pyqtSignal(bool)
    sig_submode_changed  = pyqtSignal(str)   # emits config value e.g. "selfish_v3"
    sig_saved            = pyqtSignal()

    def __init__(self, cfg: ConfigManager, parent=None):
        super().__init__(parent)
        self.cfg     = cfg
        self._active = False
        self._fields: dict = {}
        self._fields_v3: dict = {}
        self._sidebar_btns: list = []
        self._section_cards: list = []
        self._v3_card = None
        self._v3_sidebar_btn = None
        self._build_ui()
        self._activate_section(0)
        self._load_values()

    def _build_ui(self):
        root = QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        sidebar = QFrame()
        sidebar.setFixedWidth(165)
        sidebar.setStyleSheet(
            f"background:{COLORS['sidebar_bg']};"
            f"border-right:1px solid {COLORS['bg_border']};"
        )
        sb_lay = QVBoxLayout(sidebar)
        sb_lay.setContentsMargins(0, 8, 0, 8)
        sb_lay.setSpacing(2)

        hdr = QLabel("DURABILITY")
        hdr.setStyleSheet(
            f"color:{COLORS['text_dim']};font-size:9px;font-weight:700;"
            f"letter-spacing:1.5px;padding:8px 14px 4px 14px;"
        )
        sb_lay.addWidget(hdr)

        for i, name in enumerate(SECTIONS_COMMON):
            btn = QPushButton(f"  {name}")
            btn.setStyleSheet(sidebar_btn_style(False))
            btn.setCursor(Qt.CursorShape.PointingHandCursor)
            btn.setFixedHeight(38)
            btn.clicked.connect(lambda checked, idx=i: self._activate_section(idx))
            sb_lay.addWidget(btn)
            self._sidebar_btns.append(btn)

        # V3 section button (hidden until selfish_v3 selected)
        self._v3_sidebar_btn = QPushButton(f"  {SECTION_V3}")
        self._v3_sidebar_btn.setStyleSheet(sidebar_btn_style(False))
        self._v3_sidebar_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self._v3_sidebar_btn.setFixedHeight(38)
        self._v3_sidebar_btn.clicked.connect(lambda: self._activate_section(len(SECTIONS_COMMON)))
        self._v3_sidebar_btn.setVisible(False)
        sb_lay.addWidget(self._v3_sidebar_btn)

        sb_lay.addStretch()
        self._sb_lay = sb_lay
        root.addWidget(sidebar)

        right = QWidget()
        right.setStyleSheet(f"background:{COLORS['bg_base']};")
        c_lay = QVBoxLayout(right)
        c_lay.setContentsMargins(20, 16, 20, 16)
        c_lay.setSpacing(12)

        tr = QHBoxLayout(); tr.setSpacing(12)
        ll = QLabel(); ll.setPixmap(_durability_pixmap(44)); ll.setFixedSize(44, 44)
        tr.addWidget(ll)
        col = QVBoxLayout(); col.setSpacing(2)
        t = QLabel("Durability")
        t.setStyleSheet(f"color:{COLORS['text_primary']};font-size:16px;font-weight:700;")
        col.addWidget(t)
        sub = QLabel("Durability + Fighting Style — 2 Roblox Windows")
        sub.setStyleSheet(f"color:{COLORS['text_secondary']};font-size:11px;")
        col.addWidget(sub)
        tr.addLayout(col); tr.addStretch()

        # Sub-mode dropdown
        mode_lbl = QLabel("Mode :")
        mode_lbl.setStyleSheet(f"color:{COLORS['text_secondary']};font-size:11px;")
        tr.addWidget(mode_lbl)
        self._mode_combo = QComboBox()
        for display, _ in SUB_MODES:
            self._mode_combo.addItem(display)
        self._mode_combo.setFixedHeight(30)
        self._mode_combo.setFixedWidth(120)
        self._mode_combo.setStyleSheet(f"""
            QComboBox{{background:{COLORS['bg_elevated']};
            border:1px solid {COLORS['bg_border']};border-radius:6px;
            color:{COLORS['text_primary']};font-size:12px;padding:0 8px;}}
            QComboBox:focus{{border:1px solid {COLORS['accent']};}}
            QComboBox::drop-down{{border:none;}}
            QComboBox QAbstractItemView{{background:{COLORS['bg_elevated']};
            color:{COLORS['text_primary']};selection-background-color:{COLORS['accent']};}}
        """)
        self._mode_combo.currentIndexChanged.connect(self._on_submode_changed)
        tr.addWidget(self._mode_combo)

        c_lay.addLayout(tr)

        self._btn_select = QPushButton("💪  Select Durability  (F1 / F2 / F3)")
        self._btn_select.setFixedHeight(42)
        self._btn_select.setStyleSheet(self._select_style(False))
        self._btn_select.clicked.connect(self._on_select)
        c_lay.addWidget(self._btn_select)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setStyleSheet("background:transparent;")
        inner = QWidget(); inner.setStyleSheet("background:transparent;")
        il = QVBoxLayout(inner)
        il.setContentsMargins(0, 0, 8, 0)
        il.setSpacing(16)

        self._section_cards.append(self._build_windows_card())
        self._section_cards.append(self._build_win1_card())
        self._section_cards.append(self._build_win2_card())
        # V3 card (hidden initially)
        self._v3_card = self._build_v3_card()
        self._v3_card.setVisible(False)
        self._section_cards.append(self._v3_card)

        for card in self._section_cards:
            il.addWidget(card)

        save_row = QHBoxLayout(); save_row.addStretch()
        self._btn_save = QPushButton("💾  Save")
        self._btn_save.setFixedHeight(36)
        self._btn_save.setStyleSheet(
            f"QPushButton{{background:{COLORS['bg_elevated']};"
            f"color:{COLORS['text_primary']};border:1px solid {COLORS['bg_border']};"
            f"border-radius:8px;font-size:13px;font-weight:600;padding:0 20px;}}"
            f"QPushButton:hover{{border-color:{COLORS['accent']};}}"
        )
        self._btn_save.clicked.connect(self._on_save)
        save_row.addWidget(self._btn_save)
        il.addLayout(save_row)
        il.addStretch()

        scroll.setWidget(inner)
        c_lay.addWidget(scroll)
        root.addWidget(right)

    def _on_submode_changed(self, index: int):
        _, val = SUB_MODES[index]
        is_v3 = (val == "selfish_v3")
        self._v3_sidebar_btn.setVisible(is_v3)
        # If V3 section was active and we leave V3 mode, go back to Windows
        if not is_v3:
            current_active = next(
                (i for i, btn in enumerate(self._sidebar_btns) if btn.styleSheet() == sidebar_btn_style(True)),
                None
            )
            if current_active is None:
                # check v3 btn
                if self._v3_sidebar_btn.styleSheet() == sidebar_btn_style(True):
                    self._activate_section(0)
        self.sig_submode_changed.emit(val)

    def _activate_section(self, index: int):
        # Build combined list: common btns + optional v3 btn
        all_btns = list(self._sidebar_btns) + [self._v3_sidebar_btn]
        for i, btn in enumerate(all_btns):
            btn.setStyleSheet(sidebar_btn_style(i == index))
        for i, card in enumerate(self._section_cards):
            card.setVisible(i == index)

    def _build_windows_card(self) -> QFrame:
        card = _card_frame()
        lay = QVBoxLayout(card)
        lay.setContentsMargins(16, 14, 16, 14)
        lay.setSpacing(10)
        lay.addWidget(_sec("GAME WINDOWS"))

        info = QLabel("Use the buttons below to manually assign each window.")
        info.setStyleSheet(f"color:{COLORS['text_dim']};font-size:10px;")
        info.setWordWrap(True)
        lay.addWidget(info)
        lay.addWidget(_separator())

        lay.addWidget(_sec("WINDOW 1  —  LEFT"))
        btn_d1 = _detect_btn("🔍  Detect Window 1")
        btn_d1.clicked.connect(self.sig_detect_win1.emit)
        lay.addWidget(btn_d1)
        r1 = QHBoxLayout(); r1.setSpacing(8)
        r1.addWidget(_fld("Title"))
        self._fields["DUR_GameTitle1"] = _le("Roblox", w=200)
        r1.addWidget(self._fields["DUR_GameTitle1"]); r1.addStretch()
        lay.addLayout(r1)
        r1b = QHBoxLayout(); r1b.setSpacing(8)
        r1b.addWidget(_fld("Dimensions"))
        for lbl, key, ph in [("L", "DUR_Win1W", "384"), ("H", "DUR_Win1H", "216")]:
            r1b.addWidget(_dim(lbl))
            le = _le(ph, int_only=True, w=70)
            self._fields[key] = le; r1b.addWidget(le)
        r1b.addStretch()
        lay.addLayout(r1b)

        lay.addWidget(_separator())

        lay.addWidget(_sec("WINDOW 2  —  RIGHT"))
        btn_d2 = _detect_btn("🔍  Detect Window 2")
        btn_d2.clicked.connect(self.sig_detect_win2.emit)
        lay.addWidget(btn_d2)
        r2 = QHBoxLayout(); r2.setSpacing(8)
        r2.addWidget(_fld("Title"))
        self._fields["DUR_GameTitle2"] = _le("Roblox", w=200)
        r2.addWidget(self._fields["DUR_GameTitle2"]); r2.addStretch()
        lay.addLayout(r2)
        r2b = QHBoxLayout(); r2b.setSpacing(8)
        r2b.addWidget(_fld("Dimensions"))
        for lbl, key, ph in [("L", "DUR_Win2W", "384"), ("H", "DUR_Win2H", "216")]:
            r2b.addWidget(_dim(lbl))
            le = _le(ph, int_only=True, w=70)
            self._fields[key] = le; r2b.addWidget(le)
        r2b.addStretch()
        lay.addLayout(r2b)

        lay.addWidget(_separator())

        lay.addWidget(_sec("MODES"))
        surv_row = QHBoxLayout(); surv_row.setSpacing(8)
        surv_lbl = QLabel("Strength Loops")
        surv_lbl.setStyleSheet(f"color:{COLORS['text_primary']};font-size:11px;")
        surv_row.addWidget(surv_lbl)
        self._survivor_toggle = AnimatedToggle(checked=False)
        surv_row.addWidget(self._survivor_toggle)
        self._surv_count_lbl = QLabel("3")
        self._surv_count_lbl.setStyleSheet(f"color:{COLORS['accent']};font-size:13px;font-weight:bold;min-width:18px;")
        surv_row.addWidget(self._surv_count_lbl)
        surv_row.addStretch()
        lay.addLayout(surv_row)
        surv_hint = QLabel("Toggle: 3 loops (OFF) → 2 loops (ON) before next durability cycle")
        surv_hint.setStyleSheet(f"color:{COLORS['text_dim']};font-size:10px;")
        lay.addWidget(surv_hint)
        self._survivor_toggle.toggled.connect(
            lambda checked: self._surv_count_lbl.setText("2" if checked else "3")
        )

        lay.addWidget(_separator())

        lay.addWidget(_sec("K KEY — CALIBRATION OVERLAY"))
        k_row = QHBoxLayout(); k_row.setSpacing(8)
        k_lbl = QLabel("Enable K Key")
        k_lbl.setStyleSheet(f"color:{COLORS['text_primary']};font-size:11px;")
        k_row.addWidget(k_lbl)
        self._k_toggle = AnimatedToggle(checked=True)
        k_row.addWidget(self._k_toggle)
        k_row.addStretch()
        lay.addLayout(k_row)
        self._k_toggle.toggled.connect(self._on_k_toggle_immediate)
        self._k_toggle.toggled.connect(self.sig_k_toggle_changed.emit)
        k_hint = QLabel("If disabled: K key does not show calibration points. If enabled: K toggles the calibration overlay normally.")
        k_hint.setStyleSheet(f"color:{COLORS['text_dim']};font-size:10px;")
        k_hint.setWordWrap(True)
        lay.addWidget(k_hint)

        lay.addWidget(_separator())

        lay.addWidget(_sec("WINDOW SPACING"))
        gap_row = QHBoxLayout(); gap_row.setSpacing(8)
        gap_lbl = QLabel("Espacement entre fenêtres (px)")
        gap_lbl.setStyleSheet(f"color:{COLORS['text_primary']};font-size:11px;")
        gap_row.addWidget(gap_lbl)
        le_gap = _le("20", int_only=True, w=70)
        self._fields["DUR_WinGap"] = le_gap
        gap_row.addWidget(le_gap); gap_row.addStretch()
        lay.addLayout(gap_row)

        lay.addWidget(_separator())

        lay.addWidget(_sec("TRAINING DURATION"))
        dur_row = QHBoxLayout(); dur_row.setSpacing(8)
        dur_lbl = QLabel("Dura training duration (s)")
        dur_lbl.setStyleSheet(f"color:{COLORS['text_primary']};font-size:11px;")
        dur_row.addWidget(dur_lbl)
        le_dur = _le("18.0", w=70)
        self._fields["DUR_TrainingDuration"] = le_dur
        dur_row.addWidget(le_dur); dur_row.addStretch()
        lay.addLayout(dur_row)

        lay.addWidget(_separator())

        lay.addWidget(_sec("POST-TRAINING PAUSE"))
        post_row = QHBoxLayout(); post_row.setSpacing(8)
        post_lbl = QLabel("Delay after dura training (s)")
        post_lbl.setStyleSheet(f"color:{COLORS['text_primary']};font-size:11px;")
        post_row.addWidget(post_lbl)
        le_post = _le("0.5", w=70)
        self._fields["DUR_PostTrainingDelay"] = le_post
        post_row.addWidget(le_post); post_row.addStretch()
        lay.addLayout(post_row)

        lay.addWidget(_separator())

        lay.addWidget(_sec("POST-TRAINING RIGHT-CLICK BLOCK"))
        rcb_row = QHBoxLayout(); rcb_row.setSpacing(8)
        rcb_lbl = QLabel("Disable right-clicks after training")
        rcb_lbl.setStyleSheet(f"color:{COLORS['text_primary']};font-size:11px;")
        rcb_row.addWidget(rcb_lbl)
        self._no_rclick_toggle = AnimatedToggle(checked=False)
        rcb_row.addWidget(self._no_rclick_toggle)
        rcb_row.addStretch()
        lay.addLayout(rcb_row)

        rcd_row = QHBoxLayout(); rcd_row.setSpacing(8)
        rcd_lbl = QLabel("Block duration (s)")
        rcd_lbl.setStyleSheet(f"color:{COLORS['text_primary']};font-size:11px;")
        rcd_row.addWidget(rcd_lbl)
        le_rcd = _le("3.0", w=70)
        self._fields["DUR_NoRClickDuration"] = le_rcd
        rcd_row.addWidget(le_rcd); rcd_row.addStretch()
        lay.addLayout(rcd_row)

        return card

    def _build_win1_card(self) -> QFrame:
        card = _card_frame()
        lay = QVBoxLayout(card)
        lay.setContentsMargins(16, 14, 16, 14)
        lay.setSpacing(10)
        lay.addWidget(_sec("WINDOW 1  —  DURABILITY"))

        lay.addWidget(_sec("KEYBINDS"))
        _key_row("Durability Training Key", "DUR1_TrainingKey", "e", self._fields, lay)
        _key_row("Strength Training Key", "DUR1_StrengthKey", "r", self._fields, lay)
        _key_row("Fighting Style Key", "DUR1_FightStyleKey", "f", self._fields, lay)

        lay.addWidget(_separator())
        lay.addWidget(_sec("PIXEL DETECTION"))
        _pixel_block("Pixel Health",
                     "DUR1_HealthX", "DUR1_HealthY",
                     "DUR1_HealthColor", "DUR1_HealthTol",
                     self._fields, lay)
        _pixel_block("Pixel Stamina (Strength Training)",
                     "DUR1_StaminaX", "DUR1_StaminaY",
                     "DUR1_StaminaColor", "DUR1_StaminaTol",
                     self._fields, lay)

        return card

    def _build_win2_card(self) -> QFrame:
        card = _card_frame()
        lay = QVBoxLayout(card)
        lay.setContentsMargins(16, 14, 16, 14)
        lay.setSpacing(10)
        lay.addWidget(_sec("WINDOW 2  —  SHADOW BOXING / FIGHTING STYLE"))

        lay.addWidget(_sec("CLICK POSITION"))
        _xy_row("Click Spam Dura Training", "DUR2_ClickX", "DUR2_ClickY", self._fields, lay)

        lay.addWidget(_separator())
        lay.addWidget(_sec("FOOD"))
        _xy_row("Food Click", "DUR2_FoodClickX", "DUR2_FoodClickY", self._fields, lay)
        fk2_row = QHBoxLayout(); fk2_row.setSpacing(6)
        fk2_row.addWidget(_fld("Keys (1–7)"))
        for i in range(1, 8):
            le = _le(str(i + 5) if i <= 2 else "", w=44)
            self._fields[f"DUR2_Food{i}Key"] = le; fk2_row.addWidget(le)
        fk2_row.addStretch(); lay.addLayout(fk2_row)

        lay.addWidget(_separator())
        lay.addWidget(_sec("PIXEL DETECTION"))
        _pixel_block("Pixel Stamina",
                     "DUR2_StaminaX", "DUR2_StaminaY",
                     "DUR2_StaminaColor", "DUR2_StaminaTol",
                     self._fields, lay)
        _pixel_block("Food Pixel (Win2)",
                     "DUR2_FoodX", "DUR2_FoodY",
                     "DUR2_FoodColor", "DUR2_FoodTol",
                     self._fields, lay)

        lay.addWidget(_separator())
        lay.addWidget(_sec("KEYBINDS"))
        _key_row("Fighting Style Key", "DUR2_FightStyleKey", "f", self._fields, lay)

        lay.addWidget(_separator())
        lay.addWidget(_sec("FOOD LOOP WIN2"))
        win2_food_row = QHBoxLayout(); win2_food_row.setSpacing(8)
        win2_food_lbl = QLabel("Enable WIN2 food loop")
        win2_food_lbl.setStyleSheet(f"color:{COLORS['text_primary']};font-size:11px;")
        win2_food_row.addWidget(win2_food_lbl)
        self._win2_food_toggle = AnimatedToggle(checked=True)
        win2_food_row.addWidget(self._win2_food_toggle)
        win2_food_row.addStretch()
        lay.addLayout(win2_food_row)

        return card

    def _build_v3_card(self) -> QFrame:
        """Settings card exclusive to Selfish V3."""
        card = _card_frame()
        lay = QVBoxLayout(card)
        lay.setContentsMargins(16, 14, 16, 14)
        lay.setSpacing(10)
        lay.addWidget(_sec("SELFISH V3 — CONFIGURATION"))

        f = self._fields_v3  # shorthand

        # ── POINTS K — info ───────────────────────────────────────────────────
        hint = QLabel(
            "Les positions d'achat utilisent automatiquement les points K :\n"
            "🔴 Rouge = STR WIN1  |  🟢 Vert = DUR WIN1  |  🟠 Orange = STR WIN2  |  🔵 Bleu = DUR WIN2\n"
            "Appuie sur K pour positionner les 4 points directement sur l'écran."
        )
        hint.setStyleSheet(f"color:{COLORS['text_dim']};font-size:10px;")
        hint.setWordWrap(True)
        lay.addWidget(hint)

        lay.addWidget(_separator())
        lay.addWidget(_sec("WIN1 — STRENGTH STAT CLICK (après équipement)"))
        hint_s1 = QLabel("Coordonnées où cliquer APRÈS avoir équipé le training Strength sur WIN1 (clic de confirmation)")
        hint_s1.setStyleSheet(f"color:{COLORS['text_dim']};font-size:10px;")
        hint_s1.setWordWrap(True)
        lay.addWidget(hint_s1)
        _xy_row("Strength Stat Click (WIN1)", "SV3_W1_StrStatClickX", "SV3_W1_StrStatClickY", f, lay)

        lay.addWidget(_separator())
        lay.addWidget(_sec("WIN2 — STRENGTH STAT CLICK (après équipement)"))
        hint_s2 = QLabel("Coordonnées où cliquer APRÈS avoir équipé le training Strength sur WIN2 (point orange par défaut)")
        hint_s2.setStyleSheet(f"color:{COLORS['text_dim']};font-size:10px;")
        hint_s2.setWordWrap(True)
        lay.addWidget(hint_s2)
        _xy_row("Strength Stat Click (WIN2)", "SV3_W2_StrStatClickX", "SV3_W2_StrStatClickY", f, lay)

        lay.addWidget(_separator())
        lay.addWidget(_sec("POSITIONS SPAM DE CLICS (combat)"))
        hint_spam = QLabel(
            "Coordonnées où la souris se place pendant les boucles de spam (clics de combat).\n"
            "WIN1 = pendant le spam de la phase 2 | WIN2 = pendant le spam de la phase 1"
        )
        hint_spam.setStyleSheet(f"color:{COLORS['text_dim']};font-size:10px;")
        hint_spam.setWordWrap(True)
        lay.addWidget(hint_spam)
        _xy_row("Position Spam (WIN1)", "SV3_W1_SpamX", "SV3_W1_SpamY", f, lay)
        _xy_row("Position Spam (WIN2)", "SV3_W2_SpamX", "SV3_W2_SpamY", f, lay)

        lay.addWidget(_separator())
        lay.addWidget(_sec("SLOW M1S"))
        slow_hint = QLabel(
            "Remplace le spam rapide par un pattern L/R lent (timings Strength V1) :\n"
            "séries de L-clicks espacées + R-click toutes les ~1s."
        )
        slow_hint.setStyleSheet(f"color:{COLORS['text_dim']};font-size:10px;")
        slow_hint.setWordWrap(True)
        lay.addWidget(slow_hint)

        sm1_w1_row = QHBoxLayout(); sm1_w1_row.setSpacing(8)
        sm1_w1_lbl = QLabel("Slow M1s — WIN1 (phase 2)")
        sm1_w1_lbl.setStyleSheet(f"color:{COLORS['text_primary']};font-size:11px;")
        sm1_w1_row.addWidget(sm1_w1_lbl)
        self._slow_m1s_w1 = AnimatedToggle(checked=False)
        sm1_w1_row.addWidget(self._slow_m1s_w1)
        sm1_w1_row.addStretch()
        lay.addLayout(sm1_w1_row)

        sm1_w2_row = QHBoxLayout(); sm1_w2_row.setSpacing(8)
        sm1_w2_lbl = QLabel("Slow M1s — WIN2 (phase 1)")
        sm1_w2_lbl.setStyleSheet(f"color:{COLORS['text_primary']};font-size:11px;")
        sm1_w2_row.addWidget(sm1_w2_lbl)
        self._slow_m1s_w2 = AnimatedToggle(checked=False)
        sm1_w2_row.addWidget(self._slow_m1s_w2)
        sm1_w2_row.addStretch()
        lay.addLayout(sm1_w2_row)

        sm1_ms_row = QHBoxLayout(); sm1_ms_row.setSpacing(8)
        sm1_ms_lbl = QLabel("Slow M1s — intervalle L-clicks (ms)")
        sm1_ms_lbl.setStyleSheet(f"color:{COLORS['text_primary']};font-size:11px;")
        sm1_ms_row.addWidget(sm1_ms_lbl)
        le_sm = _le("1154", int_only=True, w=70); f["SV3_SlowM1sClickMs"] = le_sm
        sm1_ms_row.addWidget(le_sm); sm1_ms_row.addStretch()
        lay.addLayout(sm1_ms_row)

        sm1_rw_row = QHBoxLayout(); sm1_rw_row.setSpacing(8)
        sm1_rw_lbl = QLabel("Slow M1s — attente avant R-click (ms)")
        sm1_rw_lbl.setStyleSheet(f"color:{COLORS['text_primary']};font-size:11px;")
        sm1_rw_row.addWidget(sm1_rw_lbl)
        le_srw = _le("1000", int_only=True, w=70); f["SV3_SlowM1sRClickWaitMs"] = le_srw
        sm1_rw_row.addWidget(le_srw); sm1_rw_row.addStretch()
        lay.addLayout(sm1_rw_row)

        sm1_rl_row = QHBoxLayout(); sm1_rl_row.setSpacing(8)
        sm1_rl_lbl = QLabel("Slow M1s — délai après R-click (ms)")
        sm1_rl_lbl.setStyleSheet(f"color:{COLORS['text_primary']};font-size:11px;")
        sm1_rl_row.addWidget(sm1_rl_lbl)
        le_srl = _le("300", int_only=True, w=70); f["SV3_SlowM1sRClickToLMs"] = le_srl
        sm1_rl_row.addWidget(le_srl); sm1_rl_row.addStretch()
        lay.addLayout(sm1_rl_row)

        lay.addWidget(_separator())
        lay.addWidget(_sec("KEYBINDS"))
        _key_row("WIN1 — Durability Training Key", "SV3_W1_DurTrainingKey", "e", f, lay)
        _key_row("WIN1 — Strength Training Key",   "SV3_W1_StrTrainingKey", "r", f, lay)
        _key_row("WIN2 — Strength Training Key",   "SV3_W2_StrTrainingKey", "r", f, lay)
        _key_row("WIN2 — Durability Training Key", "SV3_W2_DurTrainingKey", "e", f, lay)
        _key_row("WIN2 — Fighting Style Key",       "SV3_W2_FightStyleKey",  "f", f, lay)

        lay.addWidget(_separator())
        lay.addWidget(_sec("TRAINING DURATIONS"))
        dur_row = QHBoxLayout(); dur_row.setSpacing(8)
        dur_lbl = QLabel("Strength spam duration (s)")
        dur_lbl.setStyleSheet(f"color:{COLORS['text_primary']};font-size:11px;")
        dur_row.addWidget(dur_lbl)
        le_sd = _le("18.0", w=70); f["SV3_StrSpamDuration"] = le_sd
        dur_row.addWidget(le_sd); dur_row.addStretch()
        lay.addLayout(dur_row)

        dur2_row = QHBoxLayout(); dur2_row.setSpacing(8)
        dur2_lbl = QLabel("Durability spam duration (s)")
        dur2_lbl.setStyleSheet(f"color:{COLORS['text_primary']};font-size:11px;")
        dur2_row.addWidget(dur2_lbl)
        le_dd = _le("18.0", w=70); f["SV3_DurSpamDuration"] = le_dd
        dur2_row.addWidget(le_dd); dur2_row.addStretch()
        lay.addLayout(dur2_row)

        strclick_row = QHBoxLayout(); strclick_row.setSpacing(8)
        strclick_lbl = QLabel("Durée spam Strength click (ms)")
        strclick_lbl.setStyleSheet(f"color:{COLORS['text_primary']};font-size:11px;")
        strclick_row.addWidget(strclick_lbl)
        le_sc = _le("700", int_only=True, w=70); f["SV3_StrClickSpamMs"] = le_sc
        strclick_row.addWidget(le_sc); strclick_row.addStretch()
        strclick_hint = QLabel("Spam de clics répétés pour lancer le training (aussi utilisé pour durabilité)")
        strclick_hint.setStyleSheet(f"color:{COLORS['text_dim']};font-size:10px;")
        strclick_hint.setWordWrap(True)
        lay.addLayout(strclick_row)
        lay.addWidget(strclick_hint)

        cend_row = QHBoxLayout(); cend_row.setSpacing(8)
        cend_lbl = QLabel("Cycle end delay (ms)")
        cend_lbl.setStyleSheet(f"color:{COLORS['text_primary']};font-size:11px;")
        cend_row.addWidget(cend_lbl)
        le_ce = _le("1000", int_only=True, w=70); f["SV3_CycleEndDelay"] = le_ce
        cend_row.addWidget(le_ce); cend_row.addStretch()

        ptrans_row = QHBoxLayout(); ptrans_row.setSpacing(8)
        ptrans_lbl = QLabel("Délai transition phase 1→2 (ms)")
        ptrans_lbl.setStyleSheet(f"color:{COLORS['text_primary']};font-size:11px;")
        ptrans_row.addWidget(ptrans_lbl)
        le_pt = _le("0", int_only=True, w=70); f["SV3_PhaseTransitionDelay"] = le_pt
        ptrans_row.addWidget(le_pt); ptrans_row.addStretch()
        ptrans_hint = QLabel("Attente après fin du 1er spam (pour que le training le plus long se termine)")
        ptrans_hint.setStyleSheet(f"color:{COLORS['text_dim']};font-size:10px;")
        ptrans_hint.setWordWrap(True)
        lay.addLayout(cend_row)
        lay.addLayout(ptrans_row)
        lay.addWidget(ptrans_hint)

        lay.addWidget(_separator())
        lay.addWidget(_sec("WIN1 — HEALTH PIXEL (phase 2)"))
        _pixel_block("Health (WIN1 dur-phase)",
                     "SV3_W1_Health2X", "SV3_W1_Health2Y",
                     "SV3_W1_Health2Color", "SV3_W1_Health2Tol",
                     f, lay)

        lay.addWidget(_separator())
        lay.addWidget(_sec("WIN1 — STAMINA PIXEL (phase 2 — si disparaît → stop spam WIN1)"))
        _pixel_block("Stamina (WIN1 dur-phase)",
                     "SV3_W1_Stamina2X", "SV3_W1_Stamina2Y",
                     "SV3_W1_Stamina2Color", "SV3_W1_Stamina2Tol",
                     f, lay)

        lay.addWidget(_separator())
        lay.addWidget(_sec("WIN2 — HEALTH PIXEL"))
        _pixel_block("Health Pixel (WIN2)",
                     "SV3_W2_HealthX", "SV3_W2_HealthY",
                     "SV3_W2_HealthColor", "SV3_W2_HealthTol",
                     f, lay)

        lay.addWidget(_separator())
        lay.addWidget(_sec("WIN2 — STAMINA PIXEL (phase 1 — si disparaît → stop spam WIN2)"))
        _pixel_block("Stamina Pixel (WIN2)",
                     "SV3_W2_StaminaX", "SV3_W2_StaminaY",
                     "SV3_W2_StaminaColor", "SV3_W2_StaminaTol",
                     f, lay)

        lay.addWidget(_separator())
        lay.addWidget(_sec("WIN2 — FOOD"))
        _pixel_block("Food Pixel (WIN2)",
                     "SV3_W2_FoodX", "SV3_W2_FoodY",
                     "SV3_W2_FoodColor", "SV3_W2_FoodTol",
                     f, lay)
        _xy_row("Food Click (WIN2)", "SV3_W2_FoodClickX", "SV3_W2_FoodClickY", f, lay)
        fk_row = QHBoxLayout(); fk_row.setSpacing(6)
        fk_row.addWidget(_fld("Food Keys (1–7)"))
        for i in range(1, 8):
            le = _le(str(i + 5) if i <= 2 else "", w=44)
            f[f"SV3_W2_Food{i}Key"] = le; fk_row.addWidget(le)
        fk_row.addStretch(); lay.addLayout(fk_row)

        lay.addWidget(_separator())
        lay.addWidget(_sec("WIN2 — FOOD BLOCK PIXELS"))
        _pixel_block("Block Pixel 1",
                     "SV3_W2_FoodBlock1X", "SV3_W2_FoodBlock1Y",
                     "SV3_W2_FoodBlock1Color", "SV3_W2_FoodBlock1Tol",
                     f, lay)
        _pixel_block("Block Pixel 2",
                     "SV3_W2_FoodBlock2X", "SV3_W2_FoodBlock2Y",
                     "SV3_W2_FoodBlock2Color", "SV3_W2_FoodBlock2Tol",
                     f, lay)

        return card

    def _on_k_toggle_immediate(self, enabled: bool):
        self.cfg.set("DUR_KToggleEnabled", 1 if enabled else 0)
        self.cfg.save_profile()
        self.sig_saved.emit()

    def _load_values(self):
        from core.config_manager import DURABILITY_DEFAULTS, SV3_DEFAULTS
        for key, le in self._fields.items():
            val = self.cfg.get(key, DURABILITY_DEFAULTS.get(key, ""))
            le.setText(str(val))
        for key, le in self._fields_v3.items():
            val = self.cfg.get(key, SV3_DEFAULTS.get(key, ""))
            le.setText(str(val))
        surv_mode = int(self.cfg.get("DUR_SurvivorMode", 0))
        self._survivor_toggle.setChecked(bool(surv_mode))
        self._surv_count_lbl.setText("2" if surv_mode else "3")
        k_enabled = int(self.cfg.get("DUR_KToggleEnabled", 1))
        self._k_toggle.setChecked(bool(k_enabled))
        no_rclick = int(self.cfg.get("DUR_NoRClickEnabled", 0))
        self._no_rclick_toggle.setChecked(bool(no_rclick))
        win2_food = int(self.cfg.get("DUR_Win2FoodEnabled", 1))
        self._win2_food_toggle.setChecked(bool(win2_food))
        slow_m1s_w1 = int(self.cfg.get("SV3_W1_SlowM1s", 0))
        self._slow_m1s_w1.setChecked(bool(slow_m1s_w1))
        slow_m1s_w2 = int(self.cfg.get("SV3_W2_SlowM1s", 0))
        self._slow_m1s_w2.setChecked(bool(slow_m1s_w2))
        # Restore dropdown
        sub_mode = self.cfg.get("DUR_SubMode", "selfish_v1_dur")
        for i, (_, val) in enumerate(SUB_MODES):
            if val == sub_mode:
                self._mode_combo.blockSignals(True)
                self._mode_combo.setCurrentIndex(i)
                self._mode_combo.blockSignals(False)
                self._v3_sidebar_btn.setVisible(val == "selfish_v3")
                break

    def _on_save(self):
        from core.config_manager import DURABILITY_DEFAULTS, SV3_DEFAULTS
        all_fields = {**self._fields, **self._fields_v3}
        all_defaults = {**DURABILITY_DEFAULTS, **SV3_DEFAULTS}
        for key, le in all_fields.items():
            default = all_defaults.get(key, "")
            raw = le.text().strip()
            if isinstance(default, float):
                try:
                    self.cfg.set(key, float(raw.replace(",", ".")))
                except ValueError:
                    self.cfg.set(key, default)
            elif isinstance(default, int):
                try:
                    self.cfg.set(key, int(raw))
                except ValueError:
                    self.cfg.set(key, default)
            else:
                self.cfg.set(key, raw)
        self.cfg.set("DUR_SurvivorMode",    1 if self._survivor_toggle.isChecked() else 0)
        self.cfg.set("DUR_KToggleEnabled",  1 if self._k_toggle.isChecked() else 0)
        self.cfg.set("DUR_NoRClickEnabled", 1 if self._no_rclick_toggle.isChecked() else 0)
        self.cfg.set("DUR_Win2FoodEnabled", 1 if self._win2_food_toggle.isChecked() else 0)
        self.cfg.set("SV3_W1_SlowM1s",     1 if self._slow_m1s_w1.isChecked() else 0)
        self.cfg.set("SV3_W2_SlowM1s",     1 if self._slow_m1s_w2.isChecked() else 0)
        _, sub_val = SUB_MODES[self._mode_combo.currentIndex()]
        self.cfg.set("DUR_SubMode", sub_val)
        self.sig_k_toggle_changed.emit(self._k_toggle.isChecked())
        self.cfg.save_profile()
        self.sig_saved.emit()

    def refresh_from_config(self):
        self._load_values()

    def set_detected_title1(self, title: str):
        le = self._fields.get("DUR_GameTitle1")
        if le and title:
            le.setText(title)

    def set_detected_title2(self, title: str):
        le = self._fields.get("DUR_GameTitle2")
        if le and title:
            le.setText(title)

    def _on_select(self):
        self.sig_select_dur.emit()

    def set_active(self, active: bool):
        self._active = active
        if active:
            self._btn_select.setText("✅  Durability — ACTIVE  (F1 / F2 / F3)")
        else:
            self._btn_select.setText("💪  Select Durability  (F1 / F2 / F3)")
        self._btn_select.setStyleSheet(self._select_style(active))

    def _select_style(self, active: bool) -> str:
        if active:
            return (
                f"QPushButton{{background:{COLORS['bg_active']};"
                f"color:{COLORS['text_primary']};border:1px solid {COLORS['accent']};"
                f"border-radius:8px;font-size:13px;font-weight:700;padding:0 20px;}}"
                f"QPushButton:hover{{background:{COLORS['bg_hover']};}}"
            )
        return (
            f"QPushButton{{background:{COLORS['bg_elevated']};"
            f"color:{COLORS['text_secondary']};border:1px solid {COLORS['bg_border']};"
            f"border-radius:8px;font-size:13px;font-weight:600;padding:0 20px;}}"
            f"QPushButton:hover{{border-color:{COLORS['accent']};"
            f"color:{COLORS['text_primary']};}}"
        )

    def get_current_submode(self) -> str:
        _, val = SUB_MODES[self._mode_combo.currentIndex()]
        return val
