
import os
import math
from PyQt6.QtWidgets import QWidget, QApplication
from PyQt6.QtCore import Qt, QTimer, pyqtSignal
from PyQt6.QtGui import (QPainter, QColor, QFont, QLinearGradient, QRadialGradient,
                          QPen, QBrush, QPainterPath, QPixmap)
from .theme import COLORS

W, H = 560, 360
LOGO_SIZE = 160  # bigger logo

T_FADE_IN_DONE  = 1000
T_PANEL_START   = 1100
T_PANEL_DONE    = 1700
T_TITLE_START   = 1750
T_TITLE_DONE    = 2800   # longer: letter-by-letter animation
T_BAR_START     = 2900
T_BAR_DONE      = 4000
T_FADEOUT_START = 4300

def _load_logo(size: int) -> QPixmap | None:
    assets_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "assets")
    path = os.path.join(assets_dir, "eclipse_logo.png")
    if os.path.isfile(path):
        pm = QPixmap(path)
        return pm.scaled(size, size, Qt.AspectRatioMode.KeepAspectRatio,
                         Qt.TransformationMode.SmoothTransformation)
    return None

def _ease_out_cubic(t):
    return 1.0 - (1.0 - t) ** 3

def _ease_in_out(t):
    if t < 0.5: return 4 * t * t * t
    p = -2 * t + 2
    return 1 - p * p * p / 2

class SplashScreen(QWidget):
    finished = pyqtSignal()

    def __init__(self):
        super().__init__()
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint |
            Qt.WindowType.WindowStaysOnTopHint |
            Qt.WindowType.Tool
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setFixedSize(W, H)

        screen = QApplication.primaryScreen().geometry()
        self.move((screen.width() - W) // 2, (screen.height() - H) // 2)

        self._logo_pm   = _load_logo(LOGO_SIZE)
        self._elapsed   = 0
        self._fading    = False
        self._alpha_out = 255
        self._ring_rot  = 0.0
        import random
        self._particles = [
            {
                'x': random.uniform(0, W),
                'y': random.uniform(0, H),
                'vx': random.uniform(-0.3, 0.3),
                'vy': random.uniform(-0.5, -0.1),
                'life': random.uniform(0, 1),
                'size': random.uniform(1, 2.5),
            }
            for _ in range(40)
        ]

        self._tick = QTimer(self)
        self._tick.timeout.connect(self._on_tick)
        self._tick.start(16)

    def _on_tick(self):
        self._elapsed  += 16
        self._ring_rot += 0.35

        import random
        for p in self._particles:
            p['x']    += p['vx']
            p['y']    += p['vy']
            p['life'] -= 0.004
            if p['life'] <= 0 or p['y'] < 0:
                p['x']    = random.uniform(W * 0.2, W * 0.8)
                p['y']    = H * 0.9
                p['vx']   = random.uniform(-0.4, 0.4)
                p['vy']   = random.uniform(-0.6, -0.1)
                p['life'] = random.uniform(0.6, 1.0)
                p['size'] = random.uniform(1, 2.5)

        if self._elapsed >= T_FADEOUT_START and not self._fading:
            self._fading = True

        if self._fading:
            self._alpha_out = max(0, self._alpha_out - 7)
            if self._alpha_out <= 0:
                self._tick.stop()
                self.close()
                self.finished.emit()
                return

        self.update()

    def _logo_alpha(self):
        return min(1.0, self._elapsed / T_FADE_IN_DONE)

    def _panel_progress(self):
        t = self._elapsed
        if t < T_PANEL_START: return 0.0
        return _ease_out_cubic(min(1.0, (t - T_PANEL_START) / (T_PANEL_DONE - T_PANEL_START)))

    def _title_progress(self):
        t = self._elapsed
        if t < T_TITLE_START: return 0.0
        return min(1.0, (t - T_TITLE_START) / (T_TITLE_DONE - T_TITLE_START))

    def _bar_progress(self):
        t = self._elapsed
        if t < T_BAR_START: return 0.0
        return _ease_in_out(min(1.0, (t - T_BAR_START) / (T_BAR_DONE - T_BAR_START)))

    def _dots(self):
        return "." * ((self._elapsed // 400) % 4)

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        ga = self._alpha_out / 255.0
        p.setOpacity(ga)

        p.fillRect(self.rect(), QColor("#000000"))

        cx, cy = W // 2, H // 2 - 30
        r_ring = 160
        rg = QRadialGradient(cx, cy, r_ring)
        rg.setColorAt(0,    QColor(80, 0, 140, 0))
        rg.setColorAt(0.65, QColor(80, 0, 160, 20))
        rg.setColorAt(0.88, QColor(160, 40, 255, 50))
        rg.setColorAt(1.0,  QColor(80, 0, 140, 0))
        p.setBrush(QBrush(rg))
        p.setPen(Qt.PenStyle.NoPen)
        p.drawEllipse(cx - r_ring, cy - r_ring, r_ring * 2, r_ring * 2)

        from PyQt6.QtCore import QRectF
        arc_pen = QPen(QColor(160, 40, 255, 25), 1.5)
        p.setPen(arc_pen)
        p.setBrush(Qt.BrushStyle.NoBrush)
        arc_rect = QRectF(cx - r_ring, cy - r_ring, r_ring * 2, r_ring * 2)
        p.drawArc(arc_rect, int(self._ring_rot * 16), int(240 * 16))
        bright_arc = QPen(QColor(210, 80, 255, 80), 2)
        p.setPen(bright_arc)
        p.drawArc(arc_rect, int(self._ring_rot * 16), int(50 * 16))

        panel_prog = self._panel_progress()
        if panel_prog > 0.3:
            pv = min(1.0, (panel_prog - 0.3) / 0.7)
            for part in self._particles:
                alpha = int(part['life'] * 120 * pv)
                if alpha <= 0: continue
                p.setOpacity(ga * part['life'] * pv * 0.7)
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(QBrush(QColor(180, 60, 255, alpha)))
                sz = part['size']
                p.drawEllipse(int(part['x'] - sz), int(part['y'] - sz),
                              int(sz * 2), int(sz * 2))
            p.setOpacity(ga)

        if panel_prog > 0:
            panel_h = int(H * panel_prog)
            panel_y = H - panel_h
            path = QPainterPath()
            path.addRoundedRect(10, panel_y, W - 20, H - panel_y, 14, 14)
            grad_bg = QLinearGradient(0, panel_y, 0, H)
            grad_bg.setColorAt(0, QColor(8, 4, 18))
            grad_bg.setColorAt(1, QColor(3, 1, 8))
            p.setBrush(QBrush(grad_bg))
            p.setPen(QPen(QColor(50, 10, 100, 160), 1))
            p.drawPath(path)
            if panel_prog > 0.7:
                la = min(1.0, (panel_prog - 0.7) / 0.3)
                p.setPen(QPen(QColor(160, 40, 255, int(la * 200)), 1))
                p.drawLine(50, panel_y + 1, W - 50, panel_y + 1)

        logo_alpha = self._logo_alpha()
        if logo_alpha > 0 and self._logo_pm:
            p.setOpacity(ga * logo_alpha)
            lx = (W - self._logo_pm.width()) // 2
            ly = int(H * 0.05)
            p.drawPixmap(lx, ly, self._logo_pm)
            p.setOpacity(ga)

        title_prog = self._title_progress()
        if title_prog > 0:
            TITLE   = "ECLIPSE"
            SUBTITLE = "MACROS"
            n_chars = len(TITLE) + len(SUBTITLE) + 2  # +2 for gap chars

            half = 0.45
            eclipse_prog = min(1.0, title_prog / half)
            macros_prog  = max(0.0, min(1.0, (title_prog - half) / (1 - half)))

            font_t = QFont("Segoe UI Variable", 18, QFont.Weight.ExtraLight)
            font_t.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, 7)
            p.setFont(font_t)

            from PyQt6.QtGui import QFontMetrics
            fm = QFontMetrics(font_t)

            ty = int(H * 0.60)
            gap = 24  # gap between ECLIPSE and MACROS
            total_w = fm.horizontalAdvance("ECLIPSE") + gap + fm.horizontalAdvance("MACROS")
            start_x = max(20, (W - total_w) // 2 - 10)

            n_e = len(TITLE)
            x_cursor = start_x
            for i, ch in enumerate(TITLE):
                char_prog = max(0.0, min(1.0, eclipse_prog * n_e - i))
                if char_prog <= 0:
                    x_cursor += fm.horizontalAdvance(ch) + 7
                    continue
                slide_y = int((1.0 - _ease_out_cubic(char_prog)) * 18)
                p.setOpacity(ga * char_prog)
                brightness = 180 + int(char_prog * 75)
                p.setPen(QColor(brightness, int(brightness * 0.92), 255))
                p.drawText(x_cursor, ty - slide_y, ch)
                x_cursor += fm.horizontalAdvance(ch) + 7

            x_cursor += gap

            font_sub = QFont("Segoe UI Variable", 18, QFont.Weight.ExtraLight)
            font_sub.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, 7)
            p.setFont(font_sub)
            fm2 = QFontMetrics(font_sub)

            n_m = len(SUBTITLE)
            for i, ch in enumerate(SUBTITLE):
                char_prog = max(0.0, min(1.0, macros_prog * n_m - i))
                if char_prog <= 0:
                    x_cursor += fm2.horizontalAdvance(ch) + 7
                    continue
                slide_y = int((1.0 - _ease_out_cubic(char_prog)) * 18)
                p.setOpacity(ga * char_prog)
                brightness = 160 + int(char_prog * 80)
                p.setPen(QColor(brightness, 40, 255))
                p.drawText(x_cursor, ty - slide_y, ch)
                x_cursor += fm2.horizontalAdvance(ch) + 7

            p.setOpacity(ga)

            if title_prog > 0.9:
                sep_fade = min(1.0, (title_prog - 0.9) / 0.1)
                p.setOpacity(ga * sep_fade)
                sep_y = ty + 14
                sg = QLinearGradient(W // 5, sep_y, 4 * W // 5, sep_y)
                sg.setColorAt(0,   QColor(0, 0, 0, 0))
                sg.setColorAt(0.4, QColor(140, 30, 255, 160))
                sg.setColorAt(0.6, QColor(200, 60, 255, 220))
                sg.setColorAt(1,   QColor(0, 0, 0, 0))
                p.setPen(QPen(sg, 1))
                p.drawLine(W // 5, sep_y, 4 * W // 5, sep_y)
                p.setOpacity(ga)

        bar_prog = self._bar_progress()
        if bar_prog >= 0 and title_prog > 0.7:
            bv = min(1.0, (title_prog - 0.7) / 0.3)
            p.setOpacity(ga * bv)
            bx, by = 100, int(H * 0.83)
            bw, bh = W - 200, 2
            p.setBrush(QBrush(QColor(20, 8, 40)))
            p.setPen(Qt.PenStyle.NoPen)
            p.drawRoundedRect(bx, by, bw, bh, 1, 1)
            fw = int(bw * bar_prog)
            if fw > 0:
                fg = QLinearGradient(bx, 0, bx + bw, 0)
                fg.setColorAt(0,   QColor(50, 10, 100))
                fg.setColorAt(0.6, QColor(130, 30, 210))
                fg.setColorAt(1,   QColor(200, 60, 255))
                p.setBrush(QBrush(fg))
                p.drawRoundedRect(bx, by, fw, bh, 1, 1)
                gx2 = bx + fw - 2
                p.setBrush(QBrush(QColor(220, 90, 255, 230)))
                p.drawEllipse(gx2 - 3, by - 2, 6, bh + 4)
            font_l = QFont("Segoe UI", 8)
            font_l.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, 2)
            p.setFont(font_l)
            p.setPen(QColor(70, 30, 120))
            p.drawText(0, by + 14, W, 18, Qt.AlignmentFlag.AlignCenter,
                       f"INITIALIZING{self._dots()}")
            p.setOpacity(ga)

        p.end()
