"""
ui/hub_window.py
================
Hub launcher window – shown at startup before the macro.
Built in PyQt6 to match the existing Eclipse Macros UI stack.

Flow:
    main.py → HubWindow shown
              ├── auto-checks for updates (background thread)
              ├── "Update" button → downloads + replaces build zip
              └── "Start" button → shows MainWindow, closes Hub
"""

import os
import sys
import json
import logging
import threading
import tempfile
import zipfile
from pathlib import Path

import requests
from packaging.version import Version

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QProgressBar, QTextEdit, QFrame, QApplication,
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal, QObject, QTimer
from PyQt6.QtGui import QFont, QPixmap, QColor, QPalette, QIcon

from .theme import COLORS

log = logging.getLogger("EclipseHub")

# ── Remote manifest URL ────────────────────────────────────────────────────────
# Host a JSON file at this URL:
# { "version": "3.2.1", "download_url": "https://...", "changelog": "..." }
MANIFEST_URL = "https://raw.githubusercontent.com/georgeribaim-dot/EclipseMacros/main/version.json"

# Installed version (bump this after each release)
LOCAL_VERSION = "3.2.0"


# ══════════════════════════════════════════════════════════════════════════════
# Background workers (QThread)
# ══════════════════════════════════════════════════════════════════════════════

class ManifestWorker(QObject):
    """Fetches the remote version manifest in a background thread."""
    done    = pyqtSignal(dict)   # {"version": str, "download_url": str, "changelog": str}
    failed  = pyqtSignal(str)    # error message

    def run(self):
        try:
            resp = requests.get(MANIFEST_URL, timeout=10)
            resp.raise_for_status()
            self.done.emit(resp.json())
        except Exception as exc:
            self.failed.emit(str(exc))


class DownloadWorker(QObject):
    """Downloads and extracts a zip update."""
    progress = pyqtSignal(int)   # 0-100
    done     = pyqtSignal()
    failed   = pyqtSignal(str)

    def __init__(self, url: str, dest_dir: Path):
        super().__init__()
        self._url  = url
        self._dest = dest_dir

    def run(self):
        try:
            with requests.get(self._url, stream=True, timeout=120) as r:
                r.raise_for_status()
                total = int(r.headers.get("content-length", 0))
                downloaded = 0
                with tempfile.NamedTemporaryFile(delete=False, suffix=".zip") as tmp:
                    tmp_path = Path(tmp.name)
                    for chunk in r.iter_content(65536):
                        tmp.write(chunk)
                        downloaded += len(chunk)
                        if total:
                            self.progress.emit(int(downloaded / total * 95))

            self.progress.emit(97)
            with zipfile.ZipFile(tmp_path, "r") as zf:
                zf.extractall(self._dest)
            tmp_path.unlink(missing_ok=True)
            self.progress.emit(100)
            self.done.emit()
        except Exception as exc:
            self.failed.emit(str(exc))


# ══════════════════════════════════════════════════════════════════════════════
# Hub Window
# ══════════════════════════════════════════════════════════════════════════════

class HubWindow(QWidget):
    """
    Shown at startup. Emits `launch_macro` when the user clicks Start.
    The caller (main.py) connects that signal to open MainWindow.
    """
    launch_macro = pyqtSignal()

    def __init__(self):
        super().__init__()
        self._manifest: dict | None = None
        self._dl_thread: QThread | None = None

        self._build_ui()
        self._setup_window()

        # Auto-check after a short delay so the window paints first
        QTimer.singleShot(500, self._check_updates)

    # ── Window setup ──────────────────────────────────────────────────────────

    def _setup_window(self):
        self.setWindowTitle("Eclipse Macros – Hub")
        self.setFixedSize(620, 500)
        self.setWindowFlags(Qt.WindowType.Window)
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)

        # Center on screen
        screen = QApplication.primaryScreen().geometry()
        self.move(
            (screen.width()  - self.width())  // 2,
            (screen.height() - self.height()) // 2,
        )

        # App icon
        assets = Path(__file__).parent.parent / "assets"
        ico = assets / "eclipse_logo.ico"
        if ico.exists():
            self.setWindowIcon(QIcon(str(ico)))

        # Global stylesheet (dark purple, matching the macro theme)
        self.setStyleSheet(f"""
            HubWindow {{
                background-color: {COLORS['bg_base']};
            }}
            QWidget {{
                background-color: transparent;
                color: {COLORS['text_primary']};
                font-family: "Segoe UI Variable", "Segoe UI", sans-serif;
            }}

            /* ── Cards ── */
            #card {{
                background-color: {COLORS['bg_elevated']};
                border: 1px solid {COLORS['bg_border']};
                border-radius: 10px;
            }}

            /* ── Labels ── */
            #title {{
                font-size: 22px;
                font-weight: 700;
                color: {COLORS['accent']};
                letter-spacing: 2px;
            }}
            #version_label {{
                font-size: 11px;
                color: {COLORS['text_secondary']};
                letter-spacing: 1px;
            }}
            #key_label {{
                font-size: 11px;
                color: {COLORS['text_secondary']};
            }}
            #val_label {{
                font-size: 11px;
                color: {COLORS['text_primary']};
                font-weight: 600;
            }}
            #status_ok    {{ color: {COLORS['accent_ok']};   font-size: 11px; font-weight: 600; }}
            #status_warn  {{ color: {COLORS['accent_warn']}; font-size: 11px; font-weight: 600; }}
            #status_error {{ color: {COLORS['accent_error']}; font-size: 11px; font-weight: 600; }}
            #status_idle  {{ color: {COLORS['text_secondary']}; font-size: 11px; }}

            /* ── Changelog box ── */
            QTextEdit {{
                background-color: {COLORS['bg_surface']};
                border: 1px solid {COLORS['bg_border']};
                border-radius: 6px;
                color: {COLORS['text_secondary']};
                font-family: Consolas, monospace;
                font-size: 10px;
                padding: 6px;
            }}

            /* ── Progress bar ── */
            QProgressBar {{
                background-color: {COLORS['bg_surface']};
                border: none;
                border-radius: 3px;
                height: 6px;
                text-align: center;
                font-size: 0px;
            }}
            QProgressBar::chunk {{
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                    stop:0 {COLORS['accent_2']}, stop:1 {COLORS['accent_glow']});
                border-radius: 3px;
            }}

            /* ── Buttons ── */
            QPushButton {{
                border-radius: 7px;
                padding: 7px 18px;
                font-size: 12px;
                font-weight: 600;
                border: none;
            }}
            #btn_check {{
                background-color: {COLORS['bg_active']};
                color: {COLORS['text_label']};
                border: 1px solid {COLORS['bg_border']};
            }}
            #btn_check:hover  {{ background-color: {COLORS['bg_hover']}; }}
            #btn_check:disabled {{ color: {COLORS['text_dim']}; }}

            #btn_update {{
                background-color: {COLORS['btn_neutral']};
                color: {COLORS['accent']};
                border: 1px solid {COLORS['neon_border']};
            }}
            #btn_update:hover {{ background-color: {COLORS['bg_active']}; }}
            #btn_update:disabled {{ color: {COLORS['text_dim']}; border-color: {COLORS['bg_border']}; }}

            #btn_start {{
                background-color: {COLORS['btn_success']};
                color: {COLORS['accent_ok']};
                border: 1px solid #1a4a30;
                font-size: 13px;
                padding: 9px 28px;
            }}
            #btn_start:hover {{ background-color: #0e2a1e; }}
            #btn_start:disabled {{ color: {COLORS['text_dim']}; border-color: {COLORS['bg_border']}; }}
        """)

    # ── UI construction ───────────────────────────────────────────────────────

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # ── Header ──
        header = self._make_header()
        root.addWidget(header)

        inner = QVBoxLayout()
        inner.setContentsMargins(22, 16, 22, 20)
        inner.setSpacing(12)
        root.addLayout(inner)

        # ── Version card ──
        inner.addWidget(self._make_version_card())

        # ── Changelog ──
        inner.addWidget(self._make_changelog_card(), stretch=1)

        # ── Progress (hidden until needed) ──
        self._progress_bar = QProgressBar()
        self._progress_bar.setRange(0, 100)
        self._progress_bar.setValue(0)
        self._progress_bar.setFixedHeight(6)
        self._progress_bar.hide()
        inner.addWidget(self._progress_bar)

        self._progress_lbl = QLabel("")
        self._progress_lbl.setObjectName("status_idle")
        self._progress_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._progress_lbl.hide()
        inner.addWidget(self._progress_lbl)

        # ── Button row ──
        inner.addLayout(self._make_button_row())

    def _make_header(self) -> QWidget:
        header = QWidget()
        header.setFixedHeight(76)
        header.setStyleSheet(f"background-color: {COLORS['bg_surface']}; border-bottom: 1px solid {COLORS['bg_border']};")

        layout = QHBoxLayout(header)
        layout.setContentsMargins(24, 0, 24, 0)

        # Logo
        assets = Path(__file__).parent.parent / "assets"
        logo_path = assets / "eclipse_logo.png"
        if logo_path.exists():
            pm = QPixmap(str(logo_path)).scaled(
                44, 44,
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation,
            )
            logo_lbl = QLabel()
            logo_lbl.setPixmap(pm)
            layout.addWidget(logo_lbl)
            layout.addSpacing(12)

        title = QLabel("ECLIPSE MACROS")
        title.setObjectName("title")
        layout.addWidget(title)
        layout.addStretch()

        ver_lbl = QLabel(f"v{LOCAL_VERSION}")
        ver_lbl.setObjectName("version_label")
        layout.addWidget(ver_lbl)

        return header

    def _make_version_card(self) -> QWidget:
        card = QFrame()
        card.setObjectName("card")

        layout = QHBoxLayout(card)
        layout.setContentsMargins(20, 14, 20, 14)
        layout.setSpacing(0)

        def _info_col(key: str, val: str, val_name: str = "val_label") -> tuple[QLabel, QVBoxLayout]:
            col = QVBoxLayout()
            col.setSpacing(3)
            k = QLabel(key.upper())
            k.setObjectName("key_label")
            v = QLabel(val)
            v.setObjectName(val_name)
            col.addWidget(k)
            col.addWidget(v)
            return v, col

        self._lbl_installed, col1 = _info_col("Installed", LOCAL_VERSION)
        layout.addLayout(col1)

        layout.addSpacing(40)

        self._lbl_remote, col2 = _info_col("Latest", "Checking…")
        layout.addLayout(col2)

        layout.addSpacing(40)

        self._lbl_status, col3 = _info_col("Status", "—", "status_idle")
        layout.addLayout(col3)

        layout.addStretch()
        return card

    def _make_changelog_card(self) -> QWidget:
        card = QFrame()
        card.setObjectName("card")

        layout = QVBoxLayout(card)
        layout.setContentsMargins(14, 12, 14, 12)
        layout.setSpacing(6)

        header = QLabel("CHANGELOG")
        header.setObjectName("key_label")
        layout.addWidget(header)

        self._changelog = QTextEdit()
        self._changelog.setReadOnly(True)
        self._changelog.setPlainText("Fetching release notes…")
        layout.addWidget(self._changelog)

        return card

    def _make_button_row(self) -> QHBoxLayout:
        row = QHBoxLayout()
        row.setSpacing(10)

        self._btn_check = QPushButton("Check for Updates")
        self._btn_check.setObjectName("btn_check")
        self._btn_check.setCursor(Qt.CursorShape.PointingHandCursor)
        self._btn_check.clicked.connect(self._check_updates)
        row.addWidget(self._btn_check)

        self._btn_update = QPushButton("Update")
        self._btn_update.setObjectName("btn_update")
        self._btn_update.setCursor(Qt.CursorShape.PointingHandCursor)
        self._btn_update.setEnabled(False)
        self._btn_update.clicked.connect(self._start_download)
        row.addWidget(self._btn_update)

        row.addStretch()

        self._btn_start = QPushButton("▶  Start")
        self._btn_start.setObjectName("btn_start")
        self._btn_start.setCursor(Qt.CursorShape.PointingHandCursor)
        self._btn_start.clicked.connect(self._on_start)
        row.addWidget(self._btn_start)

        return row

    # ── Update check ──────────────────────────────────────────────────────────

    def _check_updates(self):
        self._btn_check.setEnabled(False)
        self._btn_check.setText("Checking…")
        self._lbl_remote.setText("…")
        self._set_status("Contacting server…", "idle")

        self._manifest_thread = QThread()
        self._manifest_worker = ManifestWorker()
        self._manifest_worker.moveToThread(self._manifest_thread)
        self._manifest_thread.started.connect(self._manifest_worker.run)
        self._manifest_worker.done.connect(self._on_manifest_done)
        self._manifest_worker.failed.connect(self._on_manifest_failed)
        self._manifest_worker.done.connect(self._manifest_thread.quit)
        self._manifest_worker.failed.connect(self._manifest_thread.quit)
        self._manifest_thread.start()

    def _on_manifest_done(self, data: dict):
        self._manifest = data
        remote_ver = data.get("version", "?")
        changelog  = data.get("changelog", "No changelog available.")

        self._lbl_remote.setText(remote_ver)
        self._changelog.setPlainText(changelog)
        self._btn_check.setText("Check for Updates")
        self._btn_check.setEnabled(True)

        try:
            is_newer = Version(remote_ver) > Version(LOCAL_VERSION)
        except Exception:
            is_newer = False

        if is_newer:
            self._set_status(f"Update available → {remote_ver}", "warn")
            self._btn_update.setEnabled(True)
            log.info(f"Update available: {LOCAL_VERSION} → {remote_ver}")
        else:
            self._set_status("Up to date  ✓", "ok")
            self._btn_update.setEnabled(False)
            log.info("No update available.")

    def _on_manifest_failed(self, msg: str):
        self._lbl_remote.setText("Unavailable")
        self._set_status("Cannot reach update server", "error")
        self._changelog.setPlainText(f"Could not fetch update info:\n{msg}")
        self._btn_check.setText("Check for Updates")
        self._btn_check.setEnabled(True)
        log.warning(f"Manifest failed: {msg}")

    # ── Download / install update ─────────────────────────────────────────────

    def _start_download(self):
        if not self._manifest:
            return

        url = self._manifest.get("download_url", "")
        if not url:
            return

        # Lock UI
        self._btn_check.setEnabled(False)
        self._btn_update.setEnabled(False)
        self._btn_start.setEnabled(False)
        self._progress_bar.setValue(0)
        self._progress_bar.show()
        self._progress_lbl.setText("Downloading update…")
        self._progress_lbl.show()
        self._set_status("Downloading…", "warn")

        dest = Path(__file__).parent.parent.parent  # project root

        self._dl_thread = QThread()
        self._dl_worker = DownloadWorker(url, dest)
        self._dl_worker.moveToThread(self._dl_thread)
        self._dl_thread.started.connect(self._dl_worker.run)
        self._dl_worker.progress.connect(self._on_dl_progress)
        self._dl_worker.done.connect(self._on_dl_done)
        self._dl_worker.failed.connect(self._on_dl_failed)
        self._dl_worker.done.connect(self._dl_thread.quit)
        self._dl_worker.failed.connect(self._dl_thread.quit)
        self._dl_thread.start()

    def _on_dl_progress(self, pct: int):
        self._progress_bar.setValue(pct)
        self._progress_lbl.setText(f"Downloading…  {pct}%")

    def _on_dl_done(self):
        self._progress_lbl.setText("Update installed — restart to apply  ✓")
        self._set_status("Update installed  ✓", "ok")
        self._btn_check.setEnabled(True)
        self._btn_start.setEnabled(True)
        log.info("Update installed successfully.")

    def _on_dl_failed(self, msg: str):
        self._progress_bar.hide()
        self._progress_lbl.hide()
        self._set_status("Update failed", "error")
        self._btn_check.setEnabled(True)
        self._btn_update.setEnabled(True)
        self._btn_start.setEnabled(True)
        log.error(f"Download failed: {msg}")

    # ── Start macro ───────────────────────────────────────────────────────────

    def _on_start(self):
        log.info("User clicked Start – launching macro.")
        self._btn_start.setText("Loading…")
        self._btn_start.setEnabled(False)
        # Small delay so the button feedback is visible
        QTimer.singleShot(120, self.launch_macro.emit)

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _set_status(self, text: str, level: str):
        """level: 'ok' | 'warn' | 'error' | 'idle'"""
        name_map = {
            "ok":    "status_ok",
            "warn":  "status_warn",
            "error": "status_error",
            "idle":  "status_idle",
        }
        self._lbl_status.setText(text)
        self._lbl_status.setObjectName(name_map.get(level, "status_idle"))
        # Force Qt to re-apply the stylesheet for the new objectName
        self._lbl_status.style().unpolish(self._lbl_status)
        self._lbl_status.style().polish(self._lbl_status)
