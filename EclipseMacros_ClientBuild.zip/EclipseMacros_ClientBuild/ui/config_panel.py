
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
    QPushButton, QLabel, QLineEdit, QFrame, QScrollArea,
)
from PyQt6.QtCore import Qt, pyqtSignal

from .theme import COLORS, sidebar_btn_style
from .widgets import AnimatedToggle, SectionCard, GlowButton
from core.config_manager import ConfigManager, SECTIONS, CUSTOMIZATION_SECTIONS
import os
from PyQt6.QtGui import QPixmap

def _trials_pixmap(size: int) -> QPixmap:
    assets = os.path.join(os.path.dirname(os.path.dirname(__file__)), "assets")
    path   = os.path.join(assets, "trials_logo.png")
    if os.path.isfile(path):
        pm = QPixmap(path)
        return pm.scaled(size, size,
                         Qt.AspectRatioMode.KeepAspectRatio,
                         Qt.TransformationMode.SmoothTransformation)
    pm = QPixmap(size, size)
    pm.fill(Qt.GlobalColor.transparent)
    return pm

GAME_WINDOW_SECTION = ("Game Window", [
    ("Window Title", "GameTitle"),
    ("Target Width",  "GameWinW"),
    ("Target Height", "GameWinH"),
])

CUSTOM_SECTIONS_FILTERED = [s for s in CUSTOMIZATION_SECTIONS if s[0] != "Game Window"]

SECTION_DESCS = {
    "Cooldowns":         "Skill cooldown timers in milliseconds.",
    "Skill Keys":        "Assign a key to each skill. Leave empty to disable.",
    "Attack & Timings": "Basic attack configuration and execution delays.",
    "Misc":              "Transform options, UI timing, and miscellaneous behaviors.",
    "Game Window":       "Game window title and target dimensions. "
                         "Use the buttons below to auto-detect or reposition.",
    "Food — Block Pixel 1": "If this pixel color is detected, the food loop will NOT eat. "
                             "Leave X/Y empty to disable.",
    "Food — Block Pixel 2": "Second anti-eat block pixel (checked alongside Block Pixel 1). "
                             "Leave X/Y empty to disable.",
}

class ConfigPanel(QWidget):
    sig_saved         = pyqtSignal()
    sig_detect_window = pyqtSignal()
    sig_snap_window   = pyqtSignal()
    sig_select_trial  = pyqtSignal()   # requests MainWindow to activate Trial mode

    def __init__(self, config: ConfigManager, parent=None):
        super().__init__(parent)
        self.cfg = config
        self._active_section = 0
        self._macro_active   = False   # True = macro Trial selected
        self._field_widgets: list[dict] = []
        self._sidebar_btns:  list[QPushButton] = []
        self._build_ui()
        self._activate_section(0)

    def _build_ui(self):
        root = QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        sidebar = QFrame()
        sidebar.setFixedWidth(165)
        sidebar.setStyleSheet(
            f"background:{COLORS['sidebar_bg']};"
            f"border-right:1px solid {COLORS['bg_border']};"
        )
        sb_lay = QVBoxLayout(sidebar)
        sb_lay.setContentsMargins(0, 8, 0, 8)
        sb_lay.setSpacing(2)

        def _hdr(text):
            l = QLabel(text)
            l.setStyleSheet(
                f"color:{COLORS['text_dim']};font-size:9px;font-weight:700;"
                f"letter-spacing:1.5px;padding:8px 14px 4px 14px;"
            )
            return l

        sb_lay.addWidget(_hdr("CONFIGURATION"))
        for i, (name, _) in enumerate(SECTIONS):
            btn = self._sidebar_btn(name, i)
            sb_lay.addWidget(btn)
            self._sidebar_btns.append(btn)

        gw_idx = len(SECTIONS)
        btn_gw = self._sidebar_btn(GAME_WINDOW_SECTION[0], gw_idx)
        sb_lay.addWidget(btn_gw)
        self._sidebar_btns.append(btn_gw)

        sep = QFrame()
        sep.setFrameShape(QFrame.Shape.HLine)
        sep.setStyleSheet(f"color:{COLORS['bg_border']};margin:4px 10px;")
        sb_lay.addWidget(sep)

        sb_lay.addWidget(_hdr("CUSTOMIZATION"))
        for j, (name, _) in enumerate(CUSTOM_SECTIONS_FILTERED):
            idx = len(SECTIONS) + 1 + j
            btn = self._sidebar_btn(name, idx, small=True)
            sb_lay.addWidget(btn)
            self._sidebar_btns.append(btn)

        sb_lay.addStretch()
        root.addWidget(sidebar)

        right = QWidget()
        right.setStyleSheet(f"background:{COLORS['bg_base']};")
        c_lay = QVBoxLayout(right)
        c_lay.setContentsMargins(20, 16, 20, 16)
        c_lay.setSpacing(8)

        tr = QHBoxLayout(); tr.setSpacing(12)
        ll = QLabel()
        ll.setPixmap(_trials_pixmap(44))
        ll.setFixedSize(44, 44)
        tr.addWidget(ll)

        col = QVBoxLayout(); col.setSpacing(2)
        t_title = QLabel("Trials")
        t_title.setStyleSheet(
            f"color:{COLORS['text_primary']};font-size:16px;font-weight:700;"
        )
        col.addWidget(t_title)
        t_sub = QLabel("Trials automation")
        t_sub.setStyleSheet(f"color:{COLORS['text_secondary']};font-size:11px;")
        col.addWidget(t_sub)
        tr.addLayout(col); tr.addStretch()
        c_lay.addLayout(tr)

        self._btn_select_trial = QPushButton("⛩  Select Trials  (F1 / F2 / F3)")
        self._btn_select_trial.setFixedHeight(42)
        self._btn_select_trial.setStyleSheet(self._trial_select_style(False))
        self._btn_select_trial.clicked.connect(self._on_select_trial)
        c_lay.addWidget(self._btn_select_trial)

        self._title_lbl = QLabel()
        self._title_lbl.setStyleSheet(
            f"color:{COLORS['text_primary']};font-size:14px;font-weight:600;"
            f"padding-top:4px;"
        )
        c_lay.addWidget(self._title_lbl)

        self._desc_lbl = QLabel()
        self._desc_lbl.setStyleSheet(
            f"color:{COLORS['text_secondary']};font-size:11px;"
        )
        self._desc_lbl.setWordWrap(True)
        c_lay.addWidget(self._desc_lbl)

        self._scroll = QScrollArea()
        self._scroll.setWidgetResizable(True)
        self._scroll.setFrameShape(QFrame.Shape.NoFrame)
        self._scroll.setStyleSheet(
            "QScrollArea{border:none;background:transparent;}"
            "QScrollArea>QWidget>QWidget{background:transparent;}"
        )
        c_lay.addWidget(self._scroll, 1)

        self._toggle_container = QWidget()
        tgl_lay = QVBoxLayout(self._toggle_container)
        tgl_lay.setContentsMargins(0, 0, 0, 0)
        tgl_lay.setSpacing(8)
        self._transfo_toggle = self._toggle_row("Transform on Start", "TransfoOnStart")
        self._abrawl_toggle  = self._toggle_row("ABRAWL Mode",        "AbrawlMode")
        self._no_m2_toggle   = self._toggle_row("No M2",             "NoM2Mode")
        tgl_lay.addWidget(self._transfo_toggle)
        tgl_lay.addWidget(self._abrawl_toggle)
        tgl_lay.addWidget(self._no_m2_toggle)
        self._toggle_container.hide()
        c_lay.addWidget(self._toggle_container)

        self._window_btn_container = QWidget()
        wb = QHBoxLayout(self._window_btn_container)
        wb.setContentsMargins(0, 4, 0, 0)
        wb.setSpacing(10)

        btn_detect = GlowButton("🎮  Detect Window", "neutral")
        btn_detect.setToolTip("Auto-detect the game window title from the foreground window")
        btn_detect.clicked.connect(self.sig_detect_window.emit)
        wb.addWidget(btn_detect)

        btn_snap = GlowButton("📐  Snap (384×216)", "neutral")
        btn_snap.setToolTip("Move and resize the game window to top-left (384×216 px)")
        btn_snap.clicked.connect(self.sig_snap_window.emit)
        wb.addWidget(btn_snap)
        wb.addStretch()

        self._window_btn_container.hide()
        c_lay.addWidget(self._window_btn_container)

        save_row = QHBoxLayout()
        save_row.addStretch()
        btn_save = GlowButton("💾  Save", "primary")
        btn_save.setFixedWidth(180)
        btn_save.clicked.connect(self._save_current)
        save_row.addWidget(btn_save)
        c_lay.addLayout(save_row)

        root.addWidget(right)

    def _sidebar_btn(self, name: str, idx: int, small: bool = False) -> QPushButton:
        btn = QPushButton(name)
        btn.setStyleSheet(sidebar_btn_style(False))
        btn.setCursor(Qt.CursorShape.PointingHandCursor)
        btn.setFixedHeight(32 if small else 38)
        btn.clicked.connect(lambda _, i=idx: self._switch_section(i))
        return btn

    def _toggle_row(self, label: str, cfg_key: str) -> QWidget:
        row = QWidget()
        row.setStyleSheet(
            f"background:{COLORS['bg_elevated']};"
            f"border:1px solid {COLORS['bg_border']};border-radius:8px;"
        )
        lay = QHBoxLayout(row)
        lay.setContentsMargins(14, 10, 14, 10)
        lbl = QLabel(label)
        lbl.setStyleSheet(f"color:{COLORS['text_primary']};font-size:13px;")
        lay.addWidget(lbl)
        lay.addStretch()
        tgl = AnimatedToggle(checked=self.cfg.get_bool(cfg_key))
        tgl.toggled.connect(lambda val, k=cfg_key: self._on_toggle(k, val))
        lay.addWidget(tgl)
        row._toggle = tgl
        row._key    = cfg_key
        return row

    def _switch_section(self, idx: int):
        self._save_current(silent=True)
        self._activate_section(idx)

    def _activate_section(self, idx: int):
        self._active_section = idx

        for i, btn in enumerate(self._sidebar_btns):
            btn.setStyleSheet(sidebar_btn_style(i == idx))

        all_secs = list(SECTIONS) + [GAME_WINDOW_SECTION] + list(CUSTOM_SECTIONS_FILTERED)
        if idx >= len(all_secs):
            return
        name, fields = all_secs[idx]

        self._title_lbl.setText(name)
        self._desc_lbl.setText(
            SECTION_DESCS.get(name, "Pixel detection coordinates and colors.")
        )

        self._toggle_container.setVisible(name == "Misc")
        self._window_btn_container.setVisible(name == "Game Window")

        old_widget = self._scroll.takeWidget()
        if old_widget is not None:
            old_widget.deleteLater()

        self._field_widgets.clear()

        container = QWidget()
        container.setStyleSheet("background:transparent;")
        lay = QVBoxLayout(container)
        lay.setContentsMargins(0, 2, 4, 2)
        lay.setSpacing(0)

        if fields:
            card = SectionCard()
            grid = QGridLayout()
            grid.setHorizontalSpacing(20)
            grid.setVerticalSpacing(10)
            grid.setColumnMinimumWidth(0, 190)
            card.content_layout().addLayout(grid)

            for row_i, (label, key) in enumerate(fields):
                lbl = QLabel(label + "  :")
                lbl.setStyleSheet(f"color:{COLORS['text_label']};font-size:12px;")
                lbl.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)

                edit = QLineEdit(str(self.cfg.get(key, "")))
                edit.setStyleSheet(f"""
                    QLineEdit {{
                        background:{COLORS['bg_elevated']};
                        border:1px solid {COLORS['bg_border']};
                        border-radius:6px;
                        padding:5px 8px;
                        color:{COLORS['text_primary']};
                        max-width:210px;
                    }}
                    QLineEdit:focus {{ border:1px solid {COLORS['accent']}; }}
                """)

                grid.addWidget(lbl,  row_i, 0)
                grid.addWidget(edit, row_i, 1)
                self._field_widgets.append({"widget": edit, "key": key})

            lay.addWidget(card)

        lay.addStretch()
        self._scroll.setWidget(container)

        if name == "Misc":
            self._transfo_toggle._toggle.setChecked(self.cfg.get_bool("TransfoOnStart"))
            self._abrawl_toggle._toggle.setChecked(self.cfg.get_bool("AbrawlMode"))
            self._no_m2_toggle._toggle.setChecked(self.cfg.get_bool("NoM2Mode"))

    def _on_toggle(self, key: str, val: bool):
        self.cfg.set(key, 1 if val else 0)
        self.cfg.save_profile()
        self.sig_saved.emit()

    def set_detected_title(self, title: str):
        self.cfg.set("GameTitle", title)
        for fw in self._field_widgets:
            if fw["key"] == "GameTitle":
                fw["widget"].setText(title)
                break

    def _save_current(self, silent: bool = False):
        from core.config_manager import DEFAULT_CONFIG
        for fw in self._field_widgets:
            key     = fw["key"]
            val_str = fw["widget"].text().strip()
            if isinstance(DEFAULT_CONFIG.get(key), int):
                try:
                    val = int(val_str)
                except ValueError:
                    val = val_str
            else:
                val = val_str
            self.cfg.set(key, val)
        self.cfg.save_profile()
        if not silent:
            self.sig_saved.emit()

    def refresh_from_config(self):
        for fw in self._field_widgets:
            fw["widget"].setText(str(self.cfg.get(fw["key"], "")))

    @staticmethod
    def _trial_select_style(active: bool) -> str:
        if active:
            return (
                "QPushButton{background:#1a2a3a;color:#5BA3F5;"
                "border:2px solid #5BA3F5;border-radius:8px;"
                "font-size:13px;font-weight:700;}"
                "QPushButton:hover{background:#1e3448;}"
            )
        return (
            f"QPushButton{{background:{COLORS['bg_elevated']};"
            f"color:{COLORS['text_primary']};"
            f"border:1px solid {COLORS['bg_border']};"
            f"border-radius:8px;font-size:13px;}}"
            f"QPushButton:hover{{border-color:{COLORS.get('accent','#888')};}}"
        )

    def _on_select_trial(self):
        if not self._macro_active:
            self.sig_select_trial.emit()

    def set_active(self, active: bool):
        self._macro_active = active
        if active:
            self._btn_select_trial.setText("✅  Trials — ACTIVE  (F1 / F2 / F3)")
        else:
            self._btn_select_trial.setText("⛩  Select Trials  (F1 / F2 / F3)")
        self._btn_select_trial.setStyleSheet(self._trial_select_style(active))
