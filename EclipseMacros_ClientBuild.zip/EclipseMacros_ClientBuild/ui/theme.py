
COLORS = {
    "bg_base":        "#050505",
    "bg_surface":     "#0A0A0F",
    "bg_elevated":    "#0F0F1A",
    "bg_hover":       "#141428",
    "bg_active":      "#1A1A35",
    "bg_border":      "#1E1E3A",
    "bg_glass":       "rgba(10,10,20,0.85)",

    "sidebar_bg":     "#030308",
    "sidebar_sel":    "#0D0D20",
    "sidebar_txt":    "#3A3A6A",
    "sidebar_sel_txt":"#C0B8E8",

    "accent":         "#B060E8",
    "accent_2":       "#8040C0",
    "accent_glow":    "#CC44FF",
    "accent_ok":      "#40D080",
    "accent_warn":    "#E0A030",
    "accent_error":   "#E04060",
    "accent_gold":    "#E8E0FF",

    "text_primary":   "#EEE8FF",
    "text_secondary": "#7068A0",
    "text_dim":       "#302858",
    "text_label":     "#A090D0",

    "status_idle":    "#302858",
    "status_run":     "#40D080",
    "status_pause":   "#E0A030",
    "status_stop":    "#E04060",

    "btn_primary":    "#1A1030",
    "btn_danger":     "#200A18",
    "btn_success":    "#0A1E18",
    "btn_neutral":    "#100E20",

    "neon_border":    "#6020A8",
    "neon_bright":    "#CC44FF",
}

def build_stylesheet() -> str:
    c = COLORS
    return f"""
* {{
    font-family: "Segoe UI Variable", "Segoe UI", sans-serif;
    font-size: 13px;
    color: {c['text_primary']};
    outline: none;
}}
QMainWindow, QDialog {{
    background-color: {c['bg_base']};
}}
QWidget {{
    background-color: transparent;
}}
QScrollBar:vertical {{
    background: {c['bg_surface']};
    width: 4px;
    border-radius: 2px;
}}
QScrollBar::handle:vertical {{
    background: {c['neon_border']};
    border-radius: 2px;
    min-height: 20px;
}}
QScrollBar::handle:vertical:hover {{
    background: {c['accent_glow']};
}}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{
    height: 0px;
}}
QScrollBar:horizontal {{
    background: {c['bg_surface']};
    height: 4px;
}}
QScrollBar::handle:horizontal {{
    background: {c['neon_border']};
    border-radius: 2px;
}}
QLineEdit, QTextEdit, QPlainTextEdit {{
    background-color: {c['bg_elevated']};
    border: 1px solid {c['bg_border']};
    border-radius: 6px;
    padding: 5px 8px;
    color: {c['text_primary']};
    selection-background-color: {c['accent_2']};
}}
QLineEdit:focus, QTextEdit:focus {{
    border: 1px solid {c['neon_border']};
    background-color: {c['bg_active']};
}}
QComboBox {{
    background-color: {c['bg_elevated']};
    border: 1px solid {c['bg_border']};
    border-radius: 6px;
    padding: 5px 8px;
    color: {c['text_primary']};
    min-width: 120px;
}}
QComboBox:hover {{ border-color: {c['neon_border']}; }}
QComboBox::drop-down {{ border: none; width: 24px; }}
QComboBox::down-arrow {{
    image: none;
    border-left: 4px solid transparent;
    border-right: 4px solid transparent;
    border-top: 5px solid {c['text_secondary']};
    margin-right: 8px;
}}
QComboBox QAbstractItemView {{
    background-color: {c['bg_elevated']};
    border: 1px solid {c['neon_border']};
    border-radius: 6px;
    padding: 4px;
    selection-background-color: {c['bg_active']};
    outline: none;
}}
QSpinBox {{
    background-color: {c['bg_elevated']};
    border: 1px solid {c['bg_border']};
    border-radius: 6px;
    padding: 4px 8px;
    color: {c['text_primary']};
}}
QSpinBox:focus {{ border-color: {c['neon_border']}; }}
QSpinBox::up-button, QSpinBox::down-button {{
    background: {c['bg_border']};
    border: none;
    width: 16px;
    border-radius: 3px;
}}
QCheckBox {{
    spacing: 8px;
    color: {c['text_primary']};
}}
QCheckBox::indicator {{
    width: 16px;
    height: 16px;
    border: 1px solid {c['neon_border']};
    border-radius: 4px;
    background: {c['bg_elevated']};
}}
QCheckBox::indicator:checked {{
    background: {c['accent']};
    border-color: {c['accent_glow']};
}}
QLabel {{
    color: {c['text_primary']};
    background: transparent;
}}
QToolTip {{
    background-color: {c['bg_elevated']};
    color: {c['text_primary']};
    border: 1px solid {c['neon_border']};
    border-radius: 6px;
    padding: 4px 8px;
}}
QTabWidget::pane {{
    border: 1px solid {c['bg_border']};
    border-radius: 8px;
    background: {c['bg_surface']};
}}
QTabBar::tab {{
    background: {c['bg_elevated']};
    color: {c['text_secondary']};
    padding: 8px 16px;
    border-radius: 6px 6px 0 0;
    margin-right: 2px;
}}
QTabBar::tab:selected {{
    background: {c['bg_active']};
    color: {c['text_primary']};
    border-top: 1px solid {c['neon_border']};
}}
QTabBar::tab:hover {{ background: {c['bg_hover']}; }}
QFrame[frameShape="4"], QFrame[frameShape="5"] {{
    color: {c['bg_border']};
}}
QMessageBox {{
    background-color: {c['bg_surface']};
}}
QMessageBox QLabel {{
    color: {c['text_primary']};
}}
QMessageBox QPushButton {{
    background: {c['btn_primary']};
    color: {c['text_primary']};
    border: 1px solid {c['neon_border']};
    border-radius: 6px;
    padding: 6px 16px;
    min-width: 80px;
}}
QMessageBox QPushButton:hover {{
    background: {c['bg_active']};
    border-color: {c['accent_glow']};
}}
"""

def sidebar_btn_style(selected: bool) -> str:
    c = COLORS
    if selected:
        return f"""
            QPushButton {{
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                    stop:0 {c['sidebar_sel']}, stop:1 transparent);
                color: {c['accent_gold']};
                border: none;
                border-left: 2px solid {c['accent_glow']};
                border-radius: 0px;
                padding: 10px 14px;
                text-align: left;
                font-weight: 600;
                font-size: 12px;
                letter-spacing: 1px;
            }}
        """
    else:
        return f"""
            QPushButton {{
                background: transparent;
                color: {c['sidebar_txt']};
                border: none;
                border-left: 2px solid transparent;
                border-radius: 0px;
                padding: 10px 14px;
                text-align: left;
                font-size: 12px;
                letter-spacing: 1px;
            }}
            QPushButton:hover {{
                background: {c['bg_hover']};
                color: {c['sidebar_sel_txt']};
                border-left: 2px solid {c['accent_2']};
            }}
        """

def action_btn_style(variant: str = "primary") -> str:
    c = COLORS
    variants = {
        "primary": (c['btn_primary'],  c['bg_active'],  c['bg_elevated'],  c['neon_border'],  c['accent_glow']),
        "danger":  (c['btn_danger'],   "#2A0A1A",       "#180510",         "#601030",         "#E04060"),
        "success": (c['btn_success'],  "#0A2018",       "#051208",         "#206040",         "#40D080"),
        "neutral": (c['btn_neutral'],  "#18163A",       "#100E28",         c['bg_border'],    c['neon_border']),
    }
    bg, hover, press, border, hborder = variants.get(variant, variants["primary"])
    return f"""
        QPushButton {{
            background: {bg};
            color: {c['text_primary']};
            border: 1px solid {border};
            border-radius: 6px;
            padding: 8px 18px;
            font-weight: 600;
            letter-spacing: 0.5px;
        }}
        QPushButton:hover {{
            background: {hover};
            border-color: {hborder};
            color: {c['accent_gold']};
        }}
        QPushButton:pressed {{ background: {press}; }}
        QPushButton:disabled {{
            background: {c['bg_surface']};
            color: {c['text_dim']};
            border-color: {c['bg_border']};
        }}
    """

def log_color(level: str) -> str:
    mapping = {
        "info":  COLORS["text_secondary"],
        "ok":    COLORS["accent_ok"],
        "warn":  COLORS["accent_warn"],
        "error": COLORS["accent_error"],
    }
    return mapping.get(level, COLORS["text_primary"])
