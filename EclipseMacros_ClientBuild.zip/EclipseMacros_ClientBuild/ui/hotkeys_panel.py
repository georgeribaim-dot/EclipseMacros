
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QKeySequenceEdit, QFrame, QLineEdit, QScrollArea, QPushButton,
)
from PyQt6.QtCore import pyqtSignal, QTimer
from PyQt6.QtGui import QKeySequence, QIntValidator

from .theme import COLORS
from .widgets import GlowButton, SectionCard
from core.config_manager import ConfigManager


class HotkeysPanel(QWidget):
    sig_saved          = pyqtSignal(dict)
    sig_detect_window  = pyqtSignal()
    sig_snap_window    = pyqtSignal()
    sig_start_food     = pyqtSignal()   # new: start food loop
    sig_stop_food      = pyqtSignal()   # new: stop food loop

    ACTIONS = [
        ("start",   "Start macro",       "F1"),
        ("stop",    "Stop macro",        "F3"),
        ("show_ui", "Show interface",    "F9"),
        ("pixel",   "Pixel Calibration", "F10"),
    ]

    def __init__(self, bindings: dict, cfg: ConfigManager, parent=None):
        super().__init__(parent)
        self._edits: dict[str, QKeySequenceEdit] = {}
        # Merge saved hotkeys from config over the defaults
        merged = dict(bindings)
        for action, _, default in self.ACTIONS:
            saved = cfg.get_str(f"HK_{action}")
            if saved:
                merged[action] = saved
        self._bindings = merged
        self.cfg = cfg
        self._food_running = False
        self._build_ui()
        self._load_values()

    # ─────────────────────────────── helpers ──────────────────────────────────

    def _fld(self, text: str, w: int = 200) -> QLabel:
        l = QLabel(text)
        l.setStyleSheet(f"color:{COLORS['text_label']};font-size:12px;")
        l.setFixedWidth(w)
        return l

    def _le(self, ph: str = "", int_only: bool = False, width: int = 0) -> QLineEdit:
        e = QLineEdit()
        e.setPlaceholderText(ph)
        if int_only:
            e.setValidator(QIntValidator(0, 999999))
        e.setFixedHeight(28)
        if width:
            e.setFixedWidth(width)
        e.setStyleSheet(f"""
            QLineEdit{{background:{COLORS['bg_elevated']};
            border:1px solid {COLORS['bg_border']};border-radius:6px;
            color:{COLORS['text_primary']};font-size:12px;padding:0 8px;}}
            QLineEdit:focus{{border:1px solid {COLORS['accent']};}}
        """)
        return e

    # ─────────────────────────────── build UI ─────────────────────────────────

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(20, 16, 20, 16)
        root.setSpacing(14)

        title = QLabel("Settings")
        title.setStyleSheet(f"color:{COLORS['text_primary']};font-size:16px;font-weight:700;")
        root.addWidget(title)
        desc = QLabel("Game window, hotkeys, food loop configuration.")
        desc.setStyleSheet(f"color:{COLORS['text_secondary']};font-size:11px;")
        root.addWidget(desc)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setStyleSheet("background:transparent;")
        inner = QWidget(); inner.setStyleSheet("background:transparent;")
        il = QVBoxLayout(inner)
        il.setContentsMargins(0, 0, 8, 0); il.setSpacing(16)

        # ── GAME WINDOW ──────────────────────────────────────────────────────
        gw_card = SectionCard("GAME WINDOW")
        gw_lay  = gw_card.content_layout()

        row_t = QHBoxLayout()
        row_t.addWidget(self._fld("Window Title"))
        self._ed_title = self._le("ex: Roblox")
        row_t.addWidget(self._ed_title); row_t.addStretch()
        gw_lay.addLayout(row_t)

        row_wh = QHBoxLayout(); row_wh.setSpacing(16)
        row_wh.addWidget(self._fld("Target Width (px)"))
        self._ed_w = self._le("384", int_only=True, width=80)
        row_wh.addWidget(self._ed_w)
        row_wh.addWidget(self._fld("Target Height (px)"))
        self._ed_h = self._le("216", int_only=True, width=80)
        row_wh.addWidget(self._ed_h); row_wh.addStretch()
        gw_lay.addLayout(row_wh)

        btn_row = QHBoxLayout(); btn_row.setSpacing(10)
        self._btn_detect = GlowButton("🎮  Detect Window", "neutral")
        self._btn_detect.clicked.connect(self.sig_detect_window.emit)
        btn_row.addWidget(self._btn_detect)
        self._btn_snap = GlowButton("📐  Snap Window", "neutral")
        self._btn_snap.clicked.connect(self.sig_snap_window.emit)
        btn_row.addWidget(self._btn_snap); btn_row.addStretch()
        gw_lay.addLayout(btn_row)
        il.addWidget(gw_card)

        # ── KEYBOARD SHORTCUTS ───────────────────────────────────────────────
        hk_card = SectionCard("KEYBOARD SHORTCUTS")
        hk_lay  = hk_card.content_layout()
        for action, label, default_key in self.ACTIONS:
            row = QHBoxLayout()
            lbl = QLabel(label)
            lbl.setStyleSheet(f"color:{COLORS['text_label']};font-size:12px;")
            lbl.setFixedWidth(200)
            row.addWidget(lbl)
            kse = QKeySequenceEdit()
            current = self._bindings.get(action, default_key)
            kse.setKeySequence(QKeySequence(current.upper()))
            kse.setStyleSheet(f"""
                QKeySequenceEdit {{
                    background:{COLORS['bg_elevated']};
                    border:1px solid {COLORS['bg_border']};
                    border-radius:6px; padding:5px 8px;
                    color:{COLORS['text_primary']}; max-width:120px;
                }}
                QKeySequenceEdit:focus {{ border:1px solid {COLORS['accent']}; }}
            """)
            row.addWidget(kse); row.addStretch()
            self._edits[action] = kse
            hk_lay.addLayout(row)
        note = QLabel(
            "ℹ️  F1 Start · F3 Stop — work even when the interface is minimized.\n"
            "    Requires application restart to take effect."
        )
        note.setStyleSheet(f"color:{COLORS['text_dim']};font-size:10px;")
        note.setWordWrap(True)
        hk_lay.addWidget(note)
        il.addWidget(hk_card)

        # ── FOOD LOOP ────────────────────────────────────────────────────────
        food_card = SectionCard("FOOD LOOP")
        food_lay  = food_card.content_layout()

        food_desc = QLabel(
            "Shared configuration for all macros (Shadow Boxing, Trials, Strength, Durability…).\n"
            "The button below launches a standalone autonomous food loop."
        )
        food_desc.setStyleSheet(f"color:{COLORS['text_dim']};font-size:10px;")
        food_desc.setWordWrap(True)
        food_lay.addWidget(food_desc)


        # — Food keys —
        keys_lbl = QLabel("FOOD KEYS")
        keys_lbl.setStyleSheet(
            f"color:{COLORS['accent_gold']};font-size:10px;"
            f"font-weight:700;letter-spacing:2px;padding-top:8px;"
        )
        food_lay.addWidget(keys_lbl)
        info = QLabel("Keys used when the food pixel is detected. Leave empty = disabled.")
        info.setStyleSheet(f"color:{COLORS['text_dim']};font-size:10px;")
        info.setWordWrap(True)
        food_lay.addWidget(info)

        self._food_key_eds: list[QLineEdit] = []
        for i in range(6):
            row = QHBoxLayout()
            row.addWidget(self._fld(f"Food {i+1}  (empty = off)"))
            ed = self._le("ex: 6", width=80)
            self._food_key_eds.append(ed)
            row.addWidget(ed); row.addStretch()
            food_lay.addLayout(row)

        # — Pixel detection —
        pix_lbl = QLabel("PIXEL DETECTION")
        pix_lbl.setStyleSheet(
            f"color:{COLORS['accent_gold']};font-size:10px;"
            f"font-weight:700;letter-spacing:2px;padding-top:8px;"
        )
        food_lay.addWidget(pix_lbl)

        self._food_pixel_eds: dict[str, QLineEdit] = {}
        for label, key, is_int in [
            ("Pixel X",        "FOOD_X",         False),
            ("Pixel Y",        "FOOD_Y",         False),
            ("Color (hex)",    "FOOD_Color",      False),
            ("Tolerance",      "FOOD_Tolerance",  True),
            ("Click X (eat)",  "FOOD_CLICK_X",    True),
            ("Click Y (eat)",  "FOOD_CLICK_Y",    True),
        ]:
            row = QHBoxLayout()
            row.addWidget(self._fld(label))
            ed = self._le(int_only=is_int, width=120)
            self._food_pixel_eds[key] = ed
            row.addWidget(ed); row.addStretch()
            food_lay.addLayout(row)

        # — Block Pixel —
        blk_lbl = QLabel("BLOCK PIXEL (anti-eat)")
        blk_lbl.setStyleSheet(
            f"color:{COLORS['accent_gold']};font-size:10px;"
            f"font-weight:700;letter-spacing:2px;padding-top:8px;"
        )
        food_lay.addWidget(blk_lbl)
        blk_desc = QLabel("If this pixel is detected when the food pixel is missing → do not eat.")
        blk_desc.setStyleSheet(f"color:{COLORS['text_dim']};font-size:9px;")
        blk_desc.setWordWrap(True)
        food_lay.addWidget(blk_desc)

        self._food_block_eds: dict[str, QLineEdit] = {}
        for label, key, is_int in [
            ("Block 1 X",         "FOOD_BLOCK_X",         False),
            ("Block 1 Y",         "FOOD_BLOCK_Y",         False),
            ("Block 1 Color",     "FOOD_BLOCK_Color",     False),
            ("Block 1 Tolerance", "FOOD_BLOCK_Tolerance", True),
            ("Block 2 X",         "FOOD_BLOCK2_X",        False),
            ("Block 2 Y",         "FOOD_BLOCK2_Y",        False),
            ("Block 2 Color",     "FOOD_BLOCK2_Color",    False),
            ("Block 2 Tolerance", "FOOD_BLOCK2_Tolerance", True),
        ]:
            row = QHBoxLayout()
            row.addWidget(self._fld(label))
            ed = self._le(int_only=is_int, width=120)
            ed.setPlaceholderText("(disabled)" if not is_int else "")
            self._food_block_eds[key] = ed
            row.addWidget(ed); row.addStretch()
            food_lay.addLayout(row)

        # — Timing —
        tim_lbl = QLabel("TIMING")
        tim_lbl.setStyleSheet(
            f"color:{COLORS['accent_gold']};font-size:10px;"
            f"font-weight:700;letter-spacing:2px;padding-top:8px;"
        )
        food_lay.addWidget(tim_lbl)

        for label, attr, ph in [
            ("Check interval (ms)",     "_ed_food_interval", "500"),
            ("Key press duration (ms)", "_ed_food_duration",  "100"),
        ]:
            row = QHBoxLayout()
            row.addWidget(self._fld(label))
            ed = self._le(ph, int_only=True, width=100)
            setattr(self, attr, ed)
            row.addWidget(ed); row.addStretch()
            food_lay.addLayout(row)

        il.addWidget(food_card)

        il.addStretch()
        scroll.setWidget(inner)
        root.addWidget(scroll)

        btn_row2 = QHBoxLayout()
        btn_row2.addStretch()
        self._btn_save = GlowButton("💾  Save Settings", "primary")
        self._btn_save.setFixedWidth(250)
        self._btn_save.clicked.connect(self._save)
        btn_row2.addWidget(self._btn_save)
        root.addLayout(btn_row2)

    # ─────────────────────────────── logic ────────────────────────────────────

    @staticmethod
    def _food_btn_style(running: bool) -> str:
        if running:
            return (
                "QPushButton{background:#2a1a1a;color:#FF6B6B;"
                "border:2px solid #FF6B6B;border-radius:8px;"
                "font-size:13px;font-weight:700;}"
                "QPushButton:hover{background:#3a1a1a;}"
            )
        return (
            f"QPushButton{{background:{COLORS['bg_elevated']};"
            f"color:{COLORS['accent_ok']};border:1px solid {COLORS['accent_ok']};"
            f"border-radius:8px;font-size:13px;font-weight:700;}}"
            f"QPushButton:hover{{background:#1a2a1a;}}"
        )

    def _on_food_btn(self):
        if self._food_running:
            self.sig_stop_food.emit()
        else:
            self._save(silent=True)
            self.sig_start_food.emit()

    def set_food_running(self, running: bool):
        self._food_running = running

    def set_food_pixel_status(self, present: bool):
        pass  # indicator removed

    def _load_values(self):
        self._ed_title.setText(self.cfg.get_str("GameTitle"))
        w = self.cfg.get_int("GameWinW"); self._ed_w.setText(str(w if w else 384))
        h = self.cfg.get_int("GameWinH"); self._ed_h.setText(str(h if h else 216))
        for i, ed in enumerate(self._food_key_eds, start=1):
            ed.setText(self.cfg.get_str(f"Food{i}Key"))
        for key, ed in self._food_pixel_eds.items():
            ed.setText(str(self.cfg.get(key, "")))
        for key, ed in self._food_block_eds.items():
            ed.setText(str(self.cfg.get(key, "")))
        self._ed_food_interval.setText(str(self.cfg.get_int("FOOD_CheckInterval") or 500))
        self._ed_food_duration.setText(str(self.cfg.get_int("FOOD_KeyDuration") or 100))

    def set_detected_title(self, title: str):
        self._ed_title.setText(title)

    def refresh_from_config(self):
        self._load_values()

    def _save(self, silent: bool = False):
        self.cfg.set("GameTitle", self._ed_title.text().strip())
        try:    self.cfg.set("GameWinW", int(self._ed_w.text() or 384))
        except: pass
        try:    self.cfg.set("GameWinH", int(self._ed_h.text() or 216))
        except: pass

        # Food keys
        for i, ed in enumerate(self._food_key_eds, start=1):
            self.cfg.set(f"Food{i}Key", ed.text().strip())

        # Food pixel detection
        int_keys = {"FOOD_Tolerance", "FOOD_CLICK_X", "FOOD_CLICK_Y", "FOOD_X", "FOOD_Y"}
        for key, ed in self._food_pixel_eds.items():
            val = ed.text().strip()
            if key in int_keys:
                try: self.cfg.set(key, int(val))
                except: pass
            else:
                if val: self.cfg.set(key, val)

        # Food block pixel detection
        blk_int_keys = {"FOOD_BLOCK_Tolerance", "FOOD_BLOCK2_Tolerance"}
        for key, ed in self._food_block_eds.items():
            val = ed.text().strip()
            if key in blk_int_keys:
                try: self.cfg.set(key, int(val) if val else 30)
                except: pass
            else:
                self.cfg.set(key, val)

        # Timing
        try:    self.cfg.set("FOOD_CheckInterval", int(self._ed_food_interval.text() or 500))
        except: pass
        try:    self.cfg.set("FOOD_KeyDuration", int(self._ed_food_duration.text() or 100))
        except: pass

        # Hotkeys — save to config before writing profile
        new_bindings = {}
        for action, kse in self._edits.items():
            seq = kse.keySequence().toString().lower().strip()
            if seq:
                new_bindings[action] = seq
                self.cfg.set(f"HK_{action}", seq)
        self._bindings.update(new_bindings)

        self.cfg.save_profile()
        self.sig_saved.emit(new_bindings)

        if not silent:
            self._btn_save.setText("✓  Saved!")
            QTimer.singleShot(2000, lambda: self._btn_save.setText("💾  Save Settings"))
