"""Food calibration overlay — J key, single red point (food click position)."""

from PyQt6.QtWidgets import QWidget
from PyQt6.QtCore import Qt, pyqtSignal, QPoint
from PyQt6.QtGui import QColor, QFont, QPainter, QPen, QBrush, QCursor


class FoodDraggablePoint(QWidget):
    pos_changed = pyqtSignal(int, int)

    def __init__(self, x: int, y: int, parent=None):
        super().__init__(parent)
        self.pos_x = x
        self.pos_y = y
        self._dragging = False
        self._offset = QPoint()
        self.setGeometry(x - 8, y - 8, 16, 16)
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setCursor(QCursor(Qt.CursorShape.OpenHandCursor))
        self.setToolTip("FAT food click position — drag to set")

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self._dragging = True
            self._offset = event.pos()
            self.setCursor(QCursor(Qt.CursorShape.ClosedHandCursor))

    def mouseMoveEvent(self, event):
        if self._dragging:
            new_pos = self.pos() + event.pos() - self._offset
            self.move(new_pos)
            self.pos_x = new_pos.x() + 8
            self.pos_y = new_pos.y() + 8
            self.pos_changed.emit(self.pos_x, self.pos_y)

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self._dragging = False
            self.setCursor(QCursor(Qt.CursorShape.OpenHandCursor))

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        color = QColor(255, 0, 0)
        painter.setPen(QPen(color, 2))
        painter.setBrush(QBrush(QColor(255, 0, 0, 100)))
        painter.drawEllipse(2, 2, 12, 12)
        font = QFont(); font.setPointSize(7)
        painter.setFont(font)
        painter.setPen(QColor(255, 255, 255))
        painter.drawText(0, -12, 16, 10, Qt.AlignmentFlag.AlignCenter, "J")


class FoodCalibrationOverlay:
    """Manages a single draggable J-point for FAT macro food click position."""

    point_updated = None  # set after construction via callback

    def __init__(self, cfg):
        self.cfg = cfg
        self._visible = False
        x = int(cfg.get("FAT_ClickX", 960))
        y = int(cfg.get("FAT_ClickY", 540))
        self._point = FoodDraggablePoint(x, y)
        self._point.pos_changed.connect(self._on_moved)

    def _on_moved(self, x: int, y: int):
        self.cfg.set("FAT_ClickX", x)
        self.cfg.set("FAT_ClickY", y)
        if self.point_updated:
            self.point_updated(x, y)

    def toggle_visibility(self):
        self._visible = not self._visible
        if self._visible:
            self._point.show()
        else:
            self._point.hide()
        return self._visible

    def is_visible(self) -> bool:
        return self._visible

    def hide_point(self):
        if self._visible:
            self._visible = False
            self._point.hide()

    def get_pos(self):
        return self._point.pos_x, self._point.pos_y
