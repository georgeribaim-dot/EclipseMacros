
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
    QLabel, QPushButton, QFrame, QSizePolicy, QScrollArea,
)
from PyQt6.QtCore import Qt, pyqtSignal, QTimer
from PyQt6.QtGui import QFont, QPainter, QColor, QLinearGradient, QBrush

from .theme import COLORS, action_btn_style
from .widgets import StatCard, LogConsole, StatusIndicator, GlowButton, AnimatedToggle, NeonSeparator

class DashboardPanel(QWidget):
    sig_start  = pyqtSignal()
    sig_stop   = pyqtSignal()
    sig_pixel  = pyqtSignal()
    sig_f10_toggle_changed = pyqtSignal(bool)

    def __init__(self, cfg=None, parent=None):
        super().__init__(parent)
        self._cfg        = cfg
        self._is_running = False
        self._is_paused  = False
        self._elapsed    = 0
        self._timer      = QTimer(self)
        self._timer.timeout.connect(self._tick_timer)
        self._build_ui()
        if self._cfg is not None:
            f10_state = bool(self._cfg.get_int("F10ToggleEnabled"))
            self._f10_toggle.setChecked(f10_state)
        self._f10_toggle.toggled.connect(self._on_f10_toggled)

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setStyleSheet("background:transparent;")
        inner = QWidget()
        inner.setStyleSheet("background:transparent;")
        il = QVBoxLayout(inner)
        il.setContentsMargins(20, 16, 20, 16)
        il.setSpacing(14)

        status_card = QFrame()
        status_card.setStyleSheet(f"""
            QFrame {{
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                    stop:0 {COLORS['bg_elevated']}, stop:1 {COLORS['bg_surface']});
                border: 1px solid {COLORS['bg_border']};
                border-left: 2px solid {COLORS['neon_border']};
                border-radius: 10px;
            }}
        """)
        sc_lay = QHBoxLayout(status_card)
        sc_lay.setContentsMargins(16, 12, 16, 12)

        self._status_dot = StatusIndicator()
        sc_lay.addWidget(self._status_dot)

        self._status_label = QLabel("READY")
        self._status_label.setStyleSheet(f"""
            color: {COLORS['text_primary']};
            font-size: 13px;
            font-weight: 300;
            letter-spacing: 3px;
        """)
        sc_lay.addWidget(self._status_label)
        sc_lay.addStretch()

        self._timer_label = QLabel("00:00:00")
        self._timer_label.setStyleSheet(f"""
            color: {COLORS['accent_2']};
            font-family: "Cascadia Code", "Consolas", monospace;
            font-size: 13px;
            letter-spacing: 2px;
        """)
        sc_lay.addWidget(self._timer_label)

        self._phase_badge = QLabel("IDLE")
        self._phase_badge.setStyleSheet(f"""
            background: {COLORS['bg_border']};
            color: {COLORS['text_dim']};
            border: 1px solid {COLORS['bg_border']};
            border-radius: 4px;
            padding: 3px 10px;
            font-size: 9px;
            font-weight: 700;
            letter-spacing: 2px;
        """)
        sc_lay.addWidget(self._phase_badge)
        il.addWidget(status_card)

        ctrl_row = QHBoxLayout()
        ctrl_row.setSpacing(10)

        self._btn_start = GlowButton("▶   START   (F1)", "success")
        self._btn_start.setFixedHeight(48)
        self._btn_start.clicked.connect(self._on_start)
        ctrl_row.addWidget(self._btn_start)

        self._btn_stop = GlowButton("⏹   STOP   (F3)", "danger")
        self._btn_stop.setFixedHeight(48)
        self._btn_stop.setEnabled(False)
        self._btn_stop.clicked.connect(self._on_stop)
        ctrl_row.addWidget(self._btn_stop)
        il.addLayout(ctrl_row)

        il.addWidget(NeonSeparator())

        lbl_stats = QLabel("SESSION STATISTICS")
        lbl_stats.setStyleSheet(f"color:{COLORS['text_dim']};font-size:8px;letter-spacing:3px;font-weight:700;")
        il.addWidget(lbl_stats)

        stats_grid = QGridLayout()
        stats_grid.setSpacing(8)
        self._card_trials   = StatCard("Trials",        "0", "⛩", logo="trials_logo.png")
        self._card_shadow   = StatCard("Shadow Boxing", "0", "⬡", logo="shadow_boxing_logo.png")
        self._card_road     = StatCard("Roadworks",     "0", "⬡", logo="roadworks_logo.png")
        self._card_dur      = StatCard("Durability",    "0", "⬡", logo="durability_logo.png")
        self._card_strength = StatCard("Strength",      "0", "⬡", logo="strength_logo.png")
        self._card_food     = StatCard("Food",          "0", "⬡", logo="food_logo.png")
        stats_grid.addWidget(self._card_trials,   0, 0)
        stats_grid.addWidget(self._card_shadow,   0, 1)
        stats_grid.addWidget(self._card_road,     0, 2)
        stats_grid.addWidget(self._card_dur,      0, 3)
        stats_grid.addWidget(self._card_strength, 1, 0)
        stats_grid.addWidget(self._card_food,     1, 1)
        il.addLayout(stats_grid)

        cd_card = QFrame()
        cd_card.setStyleSheet(f"""
            QFrame {{
                background: {COLORS['bg_elevated']};
                border: 1px solid {COLORS['bg_border']};
                border-radius: 10px;
            }}
        """)
        cd_lay = QVBoxLayout(cd_card)
        cd_lay.setContentsMargins(16, 12, 16, 12)
        cd_lay.setSpacing(8)

        lbl_cd = QLabel("SYSTEM INFORMATION")
        lbl_cd.setStyleSheet(f"color:{COLORS['text_dim']};font-size:8px;font-weight:700;letter-spacing:3px;")
        cd_lay.addWidget(lbl_cd)
        cd_lay.addWidget(NeonSeparator())

        self._info_labels: dict[str, QLabel] = {}
        info_fields = [
            ("phase",   "Current Phase",  "Idle"),
            ("profile", "Active Profile", "Default"),
            ("hotkeys", "Hotkeys",        "F1 Start  |  F2 Pause  |  F3 Stop"),
        ]
        for key, label, default in info_fields:
            row_w = QHBoxLayout()
            lbl_k = QLabel(label)
            lbl_k.setStyleSheet(f"color:{COLORS['text_secondary']};font-size:10px;letter-spacing:1px;")
            lbl_k.setFixedWidth(130)
            row_w.addWidget(lbl_k)
            sep2 = QLabel("›")
            sep2.setStyleSheet(f"color:{COLORS['neon_border']};font-size:10px;")
            row_w.addWidget(sep2)
            row_w.addSpacing(4)
            lbl_v = QLabel(default)
            lbl_v.setStyleSheet(f"color:{COLORS['text_primary']};font-size:10px;")
            row_w.addWidget(lbl_v)
            row_w.addStretch()
            cd_lay.addLayout(row_w)
            self._info_labels[key] = lbl_v

        px_row = QHBoxLayout()
        lbl_px = QLabel("Pixel Status")
        lbl_px.setStyleSheet(f"color:{COLORS['text_secondary']};font-size:10px;letter-spacing:1px;")
        lbl_px.setFixedWidth(130)
        px_row.addWidget(lbl_px)
        sep3 = QLabel("›")
        sep3.setStyleSheet(f"color:{COLORS['neon_border']};font-size:10px;")
        px_row.addWidget(sep3)
        px_row.addSpacing(4)


        px_row.addStretch()
        cd_lay.addLayout(px_row)

        cal_row = QHBoxLayout()
        btn_px = QPushButton("◎  Pixel Calibration  (F10)")
        btn_px.setStyleSheet(action_btn_style("neutral"))
        btn_px.setCursor(Qt.CursorShape.PointingHandCursor)
        btn_px.setFixedHeight(32)
        btn_px.clicked.connect(self.sig_pixel.emit)
        cal_row.addWidget(btn_px)
        cal_row.addSpacing(14)

        f10_lbl = QLabel("Enable F10 Key")
        f10_lbl.setStyleSheet(f"color:{COLORS['text_secondary']};font-size:10px;letter-spacing:1px;")
        cal_row.addWidget(f10_lbl)
        self._f10_toggle = AnimatedToggle(checked=True)
        cal_row.addWidget(self._f10_toggle)
        cal_row.addStretch()
        cd_lay.addLayout(cal_row)

        il.addWidget(cd_card)

        log_header = QHBoxLayout()
        lbl_log = QLabel("LIVE LOG")
        lbl_log.setStyleSheet(f"color:{COLORS['text_dim']};font-size:8px;font-weight:700;letter-spacing:3px;")
        log_header.addWidget(lbl_log)
        log_header.addStretch()

        btn_clear = QPushButton("Clear")
        btn_clear.setStyleSheet(f"""
            QPushButton {{
                background: transparent;
                color: {COLORS['text_dim']};
                border: 1px solid {COLORS['bg_border']};
                border-radius: 4px;
                padding: 2px 10px;
                font-size: 9px;
                letter-spacing: 1px;
            }}
            QPushButton:hover {{
                color: {COLORS['accent_glow']};
                border-color: {COLORS['neon_border']};
            }}
        """)
        btn_clear.setCursor(Qt.CursorShape.PointingHandCursor)
        log_header.addWidget(btn_clear)
        il.addLayout(log_header)

        self.log_console = LogConsole()
        self.log_console.setMinimumHeight(160)
        btn_clear.clicked.connect(self.log_console.clear_logs)
        il.addWidget(self.log_console)

        scroll.setWidget(inner)
        root.addWidget(scroll)

    def _on_f10_toggled(self, enabled: bool):
        if self._cfg is not None:
            self._cfg.set("F10ToggleEnabled", 1 if enabled else 0)
            self._cfg.save_profile()
        self.sig_f10_toggle_changed.emit(enabled)

    def set_status(self, running: bool, paused: bool = False):
        self._is_running = running
        self._is_paused  = paused

        if running and not paused:
            state, label = "running", "RUNNING"
            color = COLORS['accent_ok']
            if not self._timer.isActive():
                self._timer.start(1000)
        elif running and paused:
            state, label = "paused", "PAUSED"
            color = COLORS['accent_warn']
        else:
            state = "stopped" if not running else "idle"
            label = "READY"
            color = COLORS['text_primary']
            self._timer.stop()
            if not running:
                self._elapsed = 0
                self._timer_label.setText("00:00:00")

        self._status_dot.set_state(state)
        self._status_label.setText(label)
        self._status_label.setStyleSheet(f"""
            color: {color};
            font-size: 13px;
            font-weight: 300;
            letter-spacing: 3px;
        """)
        self._btn_start.setEnabled(not running)
        self._btn_stop.setEnabled(running)


    def set_phase(self, phase: str):
        self._phase_badge.setText(phase.upper())
        self._info_labels["phase"].setText(phase)
        phase_colors = {
            "Combat":  COLORS["accent_error"],
            "Running": COLORS["accent_ok"],
            "Waiting": COLORS["accent_warn"],
            "Idle":    COLORS["text_dim"],
        }
        color = phase_colors.get(phase, COLORS["text_secondary"])
        self._phase_badge.setStyleSheet(f"""
            background: {COLORS['bg_border']};
            color: {color};
            border: 1px solid {COLORS['bg_border']};
            border-radius: 4px;
            padding: 3px 10px;
            font-size: 9px;
            font-weight: 700;
            letter-spacing: 2px;
        """)

    def update_stats(self, stats: dict):
        self._card_trials.set_value(str(stats.get("trials_done", 0)))
        self._card_shadow.set_value(str(stats.get("shadowboxing_done", 0)))
        self._card_road.set_value(str(stats.get("roadworks_done", 0)))
        self._card_dur.set_value(str(stats.get("durability_done", 0)))
        self._card_strength.set_value(str(stats.get("strength_done", 0)))
        self._card_food.set_value(str(stats.get("food_done", 0)))

    def set_profile_name(self, name: str):
        self._info_labels["profile"].setText(name)

    def set_pixel_status(self, pixel: str, present: bool):
        pass  # indicateurs health/stamina supprimés de l'UI

    @staticmethod
    def _pixel_badge_style(state: str) -> str:
        if state == "ok":
            bg, fg, border = "#0A2018", "#40D080", "#206040"
        elif state == "gone":
            bg, fg, border = "#200810", "#E04060", "#601030"
        else:
            bg, fg, border = "#0F0E1A", "#7068A0", "#1E1E3A"
        return (
            f"background: {bg}; color: {fg}; border: 1px solid {border};"
            "border-radius: 4px; padding: 2px 8px;"
            "font-size: 9px; font-weight: 700; letter-spacing: 1px;"
        )

    def append_log(self, message: str, level: str = "info"):
        self.log_console.append_log(message, level)

    def _on_start(self):
        self._elapsed = 0
        self.sig_start.emit()

    def _on_stop(self):
        self._timer.stop()
        self._elapsed = 0
        self._timer_label.setText("00:00:00")
        self.sig_stop.emit()

    def _tick_timer(self):
        if not self._is_paused:
            self._elapsed += 1
        h = self._elapsed // 3600
        m = (self._elapsed % 3600) // 60
        s = self._elapsed % 60
        self._timer_label.setText(f"{h:02d}:{m:02d}:{s:02d}")
