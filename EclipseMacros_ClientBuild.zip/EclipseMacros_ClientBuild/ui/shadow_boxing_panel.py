
import os
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame,
    QPushButton, QLineEdit, QScrollArea, QSizePolicy,
    QGridLayout,
)
from PyQt6.QtCore import Qt, pyqtSignal, QTimer
from PyQt6.QtGui import QPixmap, QIntValidator

from .theme import COLORS
from core.config_manager import ConfigManager

def _boxer_pixmap(size: int) -> QPixmap:
    assets = os.path.join(os.path.dirname(os.path.dirname(__file__)), "assets")
    path   = os.path.join(assets, "shadow_boxing_logo.png")
    if os.path.isfile(path):
        pm = QPixmap(path)
        return pm.scaled(size, size,
                         Qt.AspectRatioMode.KeepAspectRatio,
                         Qt.TransformationMode.SmoothTransformation)
    pm = QPixmap(size, size)
    pm.fill(Qt.GlobalColor.transparent)
    return pm

def _sec(txt):
    l = QLabel(txt)
    l.setStyleSheet(
        f"color:{COLORS['accent_gold']};font-size:10px;"
        f"font-weight:700;letter-spacing:2px;padding-bottom:4px;"
    )
    return l

def _fld(txt):
    l = QLabel(txt)
    l.setStyleSheet(f"color:{COLORS['text_secondary']};font-size:11px;")
    return l

def _le(ph="", int_only=False):
    e = QLineEdit()
    e.setPlaceholderText(ph)
    if int_only:
        e.setValidator(QIntValidator(1, 999999))
    e.setFixedHeight(28)
    e.setStyleSheet(f"""
        QLineEdit{{background:{COLORS['bg_elevated']};
        border:1px solid {COLORS['bg_border']};border-radius:6px;
        color:{COLORS['text_primary']};font-size:12px;padding:0 8px;}}
        QLineEdit:focus{{border:1px solid {COLORS['accent']};}}
    """)
    return e

def _card_frame():
    f = QFrame()
    f.setStyleSheet(
        f"QFrame{{background:{COLORS['bg_elevated']};"
        f"border:1px solid {COLORS['bg_border']};border-radius:10px;}}"
    )
    return f

def _sec_btn():
    return (
        f"QPushButton{{background:{COLORS['bg_elevated']};"
        f"color:{COLORS['text_primary']};border:1px solid {COLORS['bg_border']};"
        f"border-radius:8px;font-size:12px;}}"
        f"QPushButton:hover{{border-color:{COLORS.get('accent','#888')};}}"
    )

class ShadowBoxingPanel(QWidget):
    sig_select_sb = pyqtSignal()
    sig_saved     = pyqtSignal()

    def __init__(self, cfg: ConfigManager, parent=None):
        super().__init__(parent)
        self.cfg      = cfg
        self._active  = False          # True = macro SB selected
        self._build_ui()
        self._load_values()

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(20, 16, 20, 16)
        root.setSpacing(14)

        tr = QHBoxLayout(); tr.setSpacing(12)
        ll = QLabel()
        ll.setPixmap(_boxer_pixmap(44))
        ll.setFixedSize(44, 44)
        tr.addWidget(ll)

        col = QVBoxLayout(); col.setSpacing(2)
        t = QLabel("Shadow Boxing")
        t.setStyleSheet(
            f"color:{COLORS['text_primary']};font-size:16px;font-weight:700;"
        )
        col.addWidget(t)
        sub = QLabel("Combat training automation")
        sub.setStyleSheet(f"color:{COLORS['text_secondary']};font-size:11px;")
        col.addWidget(sub)
        tr.addLayout(col); tr.addStretch()
        root.addLayout(tr)

        self._btn_select = QPushButton("🥊  Select Shadow Boxing  (F1 / F2 / F3)")
        self._btn_select.setFixedHeight(42)
        self._btn_select.setStyleSheet(self._select_style(False))
        self._btn_select.clicked.connect(self._on_select)
        root.addWidget(self._btn_select)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setStyleSheet("background:transparent;")
        inner = QWidget(); inner.setStyleSheet("background:transparent;")
        il = QVBoxLayout(inner)
        il.setContentsMargins(0, 0, 8, 0); il.setSpacing(16)

        kc = _card_frame(); kl = QVBoxLayout(kc)
        kl.setContentsMargins(16,14,16,14); kl.setSpacing(10)
        kl.addWidget(_sec("MACRO KEYS"))
        g = QGridLayout(); g.setHorizontalSpacing(16); g.setVerticalSpacing(8)
        g.addWidget(_fld("Training Key"),       0, 0)
        self._ed_training = _le("ex: e"); g.addWidget(self._ed_training, 0, 1)
        g.addWidget(_fld("Fighting Style Key"), 1, 0)
        self._ed_fight = _le("ex: r");    g.addWidget(self._ed_fight,    1, 1)
        g.addWidget(_fld("Rotation Key"),        2, 0)
        self._ed_rotation = _le("ex: right")
        self._ed_rotation.setToolTip("Key held to rotate character (default: right arrow)")
        g.addWidget(self._ed_rotation, 2, 1)
        kl.addLayout(g); il.addWidget(kc)

        tc = _card_frame(); tl = QVBoxLayout(tc)
        tl.setContentsMargins(16,14,16,14); tl.setSpacing(10)
        tl.addWidget(_sec("TIMINGS"))
        g2 = QGridLayout(); g2.setHorizontalSpacing(16); g2.setVerticalSpacing(8)
        g2.addWidget(_fld("Duration rotation (ms)"),       0, 0)
        self._ed_spin   = _le("31000", int_only=True)
        self._ed_spin.setToolTip("Duration of the rotation phase (default : 31000 ms = 31 s)")
        g2.addWidget(self._ed_spin,   0, 1)
        g2.addWidget(_fld("Right Click Interval (ms)"), 1, 0)
        self._ed_rclick = _le("300",   int_only=True)
        self._ed_rclick.setToolTip("Delay between each right-click during rotation (default : 300 ms)")
        g2.addWidget(self._ed_rclick, 1, 1)
        g2.addWidget(_fld("Pause after cycle (ms)"), 2, 0)
        self._ed_cycle_delay = _le("10000", int_only=True)
        self._ed_cycle_delay.setToolTip("Pause between each Shadow Boxing cycle (default : 10000 ms = 10 s)")
        g2.addWidget(self._ed_cycle_delay, 2, 1)
        tl.addLayout(g2); il.addWidget(tc)


        il.addStretch()
        scroll.setWidget(inner)
        root.addWidget(scroll)

        self._btn_save = QPushButton("💾  Save Settings")
        self._btn_save.setFixedHeight(34)
        self._btn_save.setStyleSheet(_sec_btn())
        self._btn_save.clicked.connect(self._save_values)
        root.addWidget(self._btn_save)

    @staticmethod
    def _select_style(active: bool) -> str:
        if active:
            return (
                "QPushButton{background:#1a3a1a;color:#4CAF50;"
                "border:2px solid #4CAF50;border-radius:8px;"
                "font-size:13px;font-weight:700;}"
                "QPushButton:hover{background:#1e461e;}"
            )
        return (
            f"QPushButton{{background:{COLORS['bg_elevated']};"
            f"color:{COLORS['text_primary']};"
            f"border:1px solid {COLORS['bg_border']};"
            f"border-radius:8px;font-size:13px;}}"
            f"QPushButton:hover{{border-color:{COLORS.get('accent','#888')};}}"
        )

    def _load_values(self):
        self._ed_training.setText(self.cfg.get_str("SB_TrainingKey"))
        self._ed_fight.setText(   self.cfg.get_str("SB_FightingStyleKey"))
        rot = self.cfg.get_str("SB_RotationKey")
        self._ed_rotation.setText(rot if rot else "right")
        spin = self.cfg.get_int("SB_SpinDuration")
        self._ed_spin.setText(str(spin if spin else 31000))
        rc = self.cfg.get_int("SB_RClickInterval")
        self._ed_rclick.setText(str(rc if rc else 300))
        cd = self.cfg.get_int("SB_CycleDelay")
        self._ed_cycle_delay.setText(str(cd if cd else 10000))


    def _save_values(self):
        self.cfg.set("SB_TrainingKey",      self._ed_training.text().strip() or "e")
        self.cfg.set("SB_FightingStyleKey", self._ed_fight.text().strip()    or "r")
        self.cfg.set("SB_RotationKey",      self._ed_rotation.text().strip() or "right")
        try:    self.cfg.set("SB_SpinDuration",   int(self._ed_spin.text()   or 31000))
        except: self.cfg.set("SB_SpinDuration",   31000)
        try:    self.cfg.set("SB_RClickInterval", int(self._ed_rclick.text() or 300))
        except: self.cfg.set("SB_RClickInterval", 300)
        try:    self.cfg.set("SB_CycleDelay",     int(self._ed_cycle_delay.text() or 10000))
        except: self.cfg.set("SB_CycleDelay",     10000)

        self.cfg.save_profile()
        self.sig_saved.emit()
        self._btn_save.setText("✓  Saved!")
        QTimer.singleShot(2000,
            lambda: self._btn_save.setText("💾  Save Settings"))

    def _on_select(self):
        if not self._active:
            self.sig_select_sb.emit()

    def set_active(self, active: bool):
        self._active = active
        if active:
            self._btn_select.setText("✅  Shadow Boxing — ACTIVE  (F1 / F2 / F3)")
        else:
            self._btn_select.setText("🥊  Select Shadow Boxing  (F1 / F2 / F3)")
        self._btn_select.setStyleSheet(self._select_style(active))

    def refresh_from_config(self):
        self._load_values()
