
import io, os, json, time, threading, urllib.request, pathlib

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
    QLabel, QFrame, QPushButton, QLineEdit, QSpinBox,
    QTextEdit, QDoubleSpinBox, QFileDialog, QScrollArea,
)
from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QFont

from .theme import COLORS, action_btn_style
from .widgets import AnimatedToggle, NeonSeparator

_SETTINGS_PATH = (
    pathlib.Path(os.getenv("APPDATA", ".")) / "EclipseMacros" / "webhook_settings.json"
)
_ASSETS_DIR      = pathlib.Path(__file__).parent.parent / "assets"
_AVATAR_IMG      = _ASSETS_DIR / "eclipse_logo_avatar.png"
_AVATAR_CACHE    = _ASSETS_DIR / "_avatar_url_cache.txt"

# ── Default spawn image paths (assets/bosses.png, etc.) ──────────
_DEFAULT_SPAWN_IMGS = {
    "bosses":          str(_ASSETS_DIR / "bosses.png"),
    "rift":            str(_ASSETS_DIR / "rift.png"),
    "merchant":        str(_ASSETS_DIR / "merchant.png"),
    "gang_base_attack": str(_ASSETS_DIR / "gang_base_attack.png"),
    "turf":            str(_ASSETS_DIR / "turf.png"),
}
_GANK_TEMPLATE_PATH = str(_ASSETS_DIR / "fight.png")

_SETTINGS_DEFAULTS = {
    "webhook_url":      "",
    "user_id":          "",
    "interval_min":     5,
    "auto_start":       True,
    # spawn — chemins pré-chargés depuis assets/
    "spawn_bosses_on":  False,
    "spawn_bosses_img": _DEFAULT_SPAWN_IMGS["bosses"],
    "spawn_bosses_thr": 0.80,
    "spawn_rift_on":    False,
    "spawn_rift_img":   _DEFAULT_SPAWN_IMGS["rift"],
    "spawn_rift_thr":   0.80,
    "spawn_merchant_on":  False,
    "spawn_merchant_img": _DEFAULT_SPAWN_IMGS["merchant"],
    "spawn_merchant_thr": 0.80,
    "spawn_gang_base_attack_on":  False,
    "spawn_gang_base_attack_img": _DEFAULT_SPAWN_IMGS["gang_base_attack"],
    "spawn_gang_base_attack_thr": 0.80,
    "spawn_turf_on":  False,
    "spawn_turf_img": _DEFAULT_SPAWN_IMGS["turf"],
    "spawn_turf_thr": 0.80,
    # gank — template matching (fight.png)
    "gank_on":  False,
    "gank_thr": 0.55,
    # durability/strength strength-training pixel
    "strength_pixel_on":    False,
    "strength_pixel_x":     960,
    "strength_pixel_y":     540,
    "strength_pixel_color": "0xFFFFFF",
    "strength_pixel_tol":   20,
}

def _load_settings() -> dict:
    try:
        if _SETTINGS_PATH.exists():
            data = json.loads(_SETTINGS_PATH.read_text(encoding="utf-8"))
            return {**_SETTINGS_DEFAULTS, **data}
    except Exception:
        pass
    return dict(_SETTINGS_DEFAULTS)

def _save_settings(data: dict):
    try:
        _SETTINGS_PATH.parent.mkdir(parents=True, exist_ok=True)
        _SETTINGS_PATH.write_text(
            json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8"
        )
    except Exception:
        pass

def _grab_pil():
    try:
        from PIL import ImageGrab
        return ImageGrab.grab(all_screens=True)
    except Exception:
        try:
            import mss, numpy as np
            from PIL import Image
            with mss.mss() as sct:
                raw = sct.grab(sct.monitors[0])
                return Image.frombytes("RGB", raw.size, raw.bgra, "raw", "BGRX")
        except Exception:
            return None

def _grab_bytes() -> bytes | None:
    img = _grab_pil()
    if not img:
        return None
    buf = io.BytesIO()
    img.save(buf, format="PNG", optimize=True)
    return buf.getvalue()

def _find_template(screen, template, threshold=0.80) -> bool:
    """
    Détection basée sur les contours/bords (Canny edge matching).
    Ignore totalement le fond — seuls les éléments graphiques distinctifs
    (écriture japonaise stylisée, tête de mort samouraï) sont comparés.
    Teste plusieurs échelles pour robustesse.
    """
    try:
        import cv2, numpy as np

        s_bgr = cv2.cvtColor(np.array(screen.convert("RGB")),   cv2.COLOR_RGB2BGR)
        t_bgr = cv2.cvtColor(np.array(template.convert("RGB")), cv2.COLOR_RGB2BGR)

        s_gray = cv2.cvtColor(s_bgr, cv2.COLOR_BGR2GRAY)
        t_gray = cv2.cvtColor(t_bgr, cv2.COLOR_BGR2GRAY)

        th, tw = t_gray.shape[:2]
        sh, sw = s_gray.shape[:2]

        # Contours du template (éléments graphiques distinctifs — ignore le fond)
        t_edges = cv2.Canny(t_gray, 50, 150)

        # Tester plusieurs échelles (HUD Roblox variable selon résolution)
        scales = [1.0, 0.85, 1.15, 0.70, 1.30]
        best_score = 0.0

        for scale in scales:
            nw = max(1, int(tw * scale))
            nh = max(1, int(th * scale))
            if nh > sh or nw > sw:
                continue
            t_scaled = cv2.resize(t_edges, (nw, nh), interpolation=cv2.INTER_LINEAR)
            s_edges  = cv2.Canny(s_gray, 50, 150)
            res = cv2.matchTemplate(s_edges, t_scaled, cv2.TM_CCOEFF_NORMED)
            _, mv, _, _ = cv2.minMaxLoc(res)
            best_score = max(best_score, float(mv))
            if best_score >= threshold:
                return True

        return best_score >= threshold

    except Exception:
        pass

    # Fallback numpy sans cv2 : comparaison overlap des gradients
    try:
        import numpy as np

        def _to_gray(arr):
            return 0.299 * arr[:, :, 0] + 0.587 * arr[:, :, 1] + 0.114 * arr[:, :, 2]

        def _edges_simple(gray):
            gy = np.abs(np.diff(gray, axis=0, prepend=gray[:1]))
            gx = np.abs(np.diff(gray, axis=1, prepend=gray[:, :1]))
            mag = gy + gx
            thr_e = mag.mean() + mag.std()
            return (mag > thr_e).astype(np.float32)

        sc_arr = np.array(screen.convert("RGB")).astype(np.float32)
        tm_arr = np.array(template.convert("RGB")).astype(np.float32)
        sh, sw = sc_arr.shape[:2]
        th, tw = tm_arr.shape[:2]
        if th > sh or tw > sw:
            return False

        sc_e = _edges_simple(_to_gray(sc_arr))
        tm_e = _edges_simple(_to_gray(tm_arr))
        tm_sum = tm_e.sum()
        if tm_sum < 1:
            return False

        best = 0.0
        step = max(4, th // 8)
        for y in range(0, sh - th, step):
            for x in range(0, sw - tw, step):
                patch = sc_e[y:y+th, x:x+tw]
                overlap = (patch * tm_e).sum() / tm_sum
                best = max(best, float(overlap))
                if best >= threshold:
                    return True
        return best >= threshold

    except Exception:
        return False

def _upload_avatar() -> str | None:
    if not _AVATAR_IMG.exists():
        return None
    try:
        data = _AVATAR_IMG.read_bytes()
        bnd  = b"----EclipseCatbox88"
        body = b""
        for n, v in [("reqtype", b"fileupload"), ("userhash", b"")]:
            body += b"--" + bnd + b"\r\n"
            body += f'Content-Disposition: form-data; name="{n}"\r\n\r\n'.encode() + v + b"\r\n"
        body += b"--" + bnd + b"\r\n"
        body += b'Content-Disposition: form-data; name="fileToUpload"; filename="eclipse_avatar.png"\r\n'
        body += b"Content-Type: image/png\r\n\r\n" + data + b"\r\n"
        body += b"--" + bnd + b"--\r\n"
        req = urllib.request.Request(
            "https://catbox.moe/user/api.php", data=body, method="POST",
            headers={"Content-Type": f"multipart/form-data; boundary={bnd.decode()}",
                     "User-Agent": "EclipseBot/4.0"}
        )
        with urllib.request.urlopen(req, timeout=30) as r:
            url = r.read().decode().strip()
            return url if url.startswith("https://") else None
    except Exception:
        return None

def _get_avatar() -> str | None:
    if _AVATAR_CACHE.exists():
        c = _AVATAR_CACHE.read_text().strip()
        if c.startswith("https://"):
            return c
    url = _upload_avatar()
    if url:
        _AVATAR_CACHE.write_text(url)
    return url

def _discord_send(url: str, content: str,
                  img: bytes | None = None,
                  avatar_url: str | None = None) -> tuple[bool, str]:
    """Envoie un message Discord (webhook). Retourne (succès, message)."""
    if not url or not url.startswith("https://discord.com/api/webhooks/"):
        return False, "URL webhook invalide"
    try:
        payload = {"content": content, "username": "Eclipse Bot"}
        import re as _re
        mentioned_ids = _re.findall(r"<@!?(\d+)>", content)
        allowed_mentions = {"parse": [], "users": mentioned_ids} if mentioned_ids else {"parse": []}
        payload["allowed_mentions"] = allowed_mentions
        if avatar_url:
            payload["avatar_url"] = avatar_url
        if img:
            bnd  = b"----EclipseBound7x"
            body = b"--" + bnd + b"\r\n"
            body += b'Content-Disposition: form-data; name="payload_json"\r\n'
            body += b'Content-Type: application/json\r\n\r\n'
            body += json.dumps(payload).encode() + b"\r\n"
            ts = time.strftime("%H-%M-%S")
            body += b"--" + bnd + b"\r\n"
            body += f'Content-Disposition: form-data; name="files[0]"; filename="eclipse_{ts}.png"\r\n'.encode()
            body += b"Content-Type: image/png\r\n\r\n" + img + b"\r\n"
            body += b"--" + bnd + b"--\r\n"
            req = urllib.request.Request(
                url, data=body, method="POST",
                headers={"Content-Type": f"multipart/form-data; boundary={bnd.decode()}",
                         "User-Agent": "EclipseBot/4.0"}
            )
        else:
            req = urllib.request.Request(
                url, data=json.dumps(payload).encode(), method="POST",
                headers={"Content-Type": "application/json", "User-Agent": "EclipseBot/4.0"}
            )
        with urllib.request.urlopen(req, timeout=15) as r:
            code = r.getcode()
            # Discord retourne 204 No Content (success) ou 200 pour les webhooks
            if code in (200, 204):
                return True, f"HTTP {code}"
            return False, f"HTTP {code} inattendu"
    except urllib.error.HTTPError as e:
        body_err = ""
        try:
            body_err = e.read().decode(errors="replace")[:200]
        except Exception:
            pass
        return False, f"HTTP {e.code}: {body_err}"
    except Exception as e:
        return False, str(e)

GANK_MODES = {"Shadow Boxing", "Roadworks", "Strength"}

class _SpawnDetector:
    """Detects a spawn image on screen (template matching)."""
    COOLDOWN = 60.0

    def __init__(self, name: str, on_found):
        self.name = name
        self._cb  = on_found
        self._tpl = None
        self._thr = 0.80
        self._on  = False
        self._stop  = threading.Event()
        self._last  = 0.0
        threading.Thread(target=self._run, daemon=True).start()

    def set_template(self, pil): self._tpl = pil
    def set_threshold(self, v):  self._thr = v
    def set_enabled(self, v):    self._on  = v
    def stop(self):              self._stop.set()

    def _run(self):
        while not self._stop.wait(8):
            if not self._on or self._tpl is None:
                continue
            try:
                sc = _grab_pil()
                if sc and _find_template(sc, self._tpl, self._thr):
                    now = time.monotonic()
                    if now - self._last >= self.COOLDOWN:
                        self._last = now
                        self._cb(self.name)
            except Exception:
                pass

class _GankMonitor:
    """
    GANK DETECTION via template matching (fight.png — tête de mort / samouraï).
    - Scanne tout l'écran toutes les TICK secondes
    - Si le template est trouvé → screenshot + ping Discord
    - Cooldown 60s anti-spam
    """
    TICK     = 1.5   # vérification toutes les 1.5 s
    COOLDOWN = 60.0

    def __init__(self, on_ganked, on_template_loaded=None):
        self._cb              = on_ganked
        self._on_tpl_loaded   = on_template_loaded  # callback(path_str) quand le template builtin est chargé
        self._on              = False
        self._active          = False
        self._thr             = 0.72          # seuil de confiance template matching
        self._tpl             = None          # cache PIL du template
        self._last            = 0.0
        self._stop            = threading.Event()
        self._load_template()
        threading.Thread(target=self._run, daemon=True).start()

    def _load_template(self):
        """Charge fight.png depuis assets/ automatiquement (mode script ET PyInstaller)."""
        import sys, pathlib
        try:
            from PIL import Image
            if hasattr(sys, "_MEIPASS"):
                p = pathlib.Path(sys._MEIPASS) / "assets" / "fight.png"
            else:
                p = pathlib.Path(__file__).parent.parent / "assets" / "fight.png"
            if p.exists():
                self._tpl = Image.open(str(p)).convert("RGB")
                if self._on_tpl_loaded:
                    self._on_tpl_loaded(str(p))
        except Exception:
            self._tpl = None

    def set_enabled(self, v):      self._on     = v
    def set_macro_active(self, v): self._active = v
    def set_threshold(self, v):    self._thr    = v
    # Compatibilité avec le panel UI qui appelait set_config(x,y,c,t) pour le pixel
    # → on ignore x/y/c/t, la détection est maintenant full-screen template matching
    def set_config(self, x, y, c, t): pass
    def stop(self):                self._stop.set()

    def _template_detected(self) -> bool:
        """Retourne True si fight.png est trouvé sur l'écran."""
        if self._tpl is None:
            self._load_template()   # retry si le template n'était pas dispo au démarrage
            return False
        try:
            sc = _grab_pil()
            if sc is None:
                return False
            return _find_template(sc, self._tpl, self._thr)
        except Exception:
            return False

    def _run(self):
        while not self._stop.wait(self.TICK):
            if not self._on or not self._active:
                continue
            if self._template_detected():
                now = time.monotonic()
                if now - self._last >= self.COOLDOWN:
                    self._last = now
                    self._cb()

class _StrengthPixelMonitor:
    """
    Surveille le pixel de strength training dans WIN1 (durability).
    If the pixel IS NOT DETECTED → ping + screenshot.
    Utilisé uniquement pendant les boucles de strength training.
    """
    TICK     = 2.0
    COOLDOWN = 30.0

    def __init__(self, on_absent):
        self._cb    = on_absent
        self._on    = False
        self._active = False
        self._x = self._y = 0
        self._color = 0xFFFFFF
        self._tol   = 20
        self._last  = 0.0
        self._stop  = threading.Event()
        threading.Thread(target=self._run, daemon=True).start()

    def set_enabled(self, v):          self._on     = v
    def set_active(self, v):           self._active = v
    def set_config(self, x, y, c, t): self._x=x; self._y=y; self._color=c; self._tol=t
    def stop(self):                    self._stop.set()

    def _pixel_present(self) -> bool:
        try:
            from PIL import ImageGrab
            margin = 2
            x0 = max(0, self._x - margin)
            y0 = max(0, self._y - margin)
            img = ImageGrab.grab(bbox=(x0, y0, self._x + margin + 1, self._y + margin + 1), all_screens=True)
            tr = (self._color >> 16) & 0xFF
            tg = (self._color >>  8) & 0xFF
            tb =  self._color        & 0xFF
            for px in range(img.width):
                for py in range(img.height):
                    pixel = img.getpixel((px, py))
                    r, g, b = pixel[0], pixel[1], pixel[2]
                    if abs(r-tr) <= self._tol and abs(g-tg) <= self._tol and abs(b-tb) <= self._tol:
                        return True
            return False
        except Exception:
            return True  # In case of error, treat as present to avoid false positives

    def _run(self):
        while not self._stop.wait(self.TICK):
            if not self._on or not self._active:
                continue
            if not self._pixel_present():
                now = time.monotonic()
                if now - self._last >= self.COOLDOWN:
                    self._last = now
                    self._cb()

class _WebhookWorker:
    def __init__(self, url, interval_min, avatar_url, on_log):
        self._url = url; self._iv = interval_min * 60
        self._av  = avatar_url; self._log = on_log
        self._stop = threading.Event()
        threading.Thread(target=self._run, daemon=True).start()

    def stop(self): self._stop.set()

    def _run(self):
        self._log("Eclipse Bot connected ✓", "ok")
        ok, msg = _discord_send(self._url, "🟣 **Eclipse Bot** — macro monitoring active.", avatar_url=self._av)
        if not ok:
            self._log(f"Discord connection warning: {msg}", "warn")
        self._send_ss("🚀 Eclipse Macro started.")
        nxt = time.monotonic() + self._iv
        while not self._stop.wait(5):
            if time.monotonic() >= nxt:
                self._send_ss(f"📸 Screenshot — {time.strftime('%H:%M:%S')}")
                nxt = time.monotonic() + self._iv
        self._log("Eclipse Bot disconnected.", "warn")
        _discord_send(self._url, "🔴 **Eclipse Bot** — macro stopped.", avatar_url=self._av)

    def _send_ss(self, caption):
        img = _grab_bytes()
        ok, msg = _discord_send(self._url, caption, img, self._av)
        if ok:
            sz = f"{len(img)//1024} KB" if img else "?"
            self._log(f"Screenshot sent ({sz}) — {msg}", "ok")
        else:
            self._log(f"Discord send error: {msg}", "error")

def _mkbtn(text: str, variant: str = "neutral", w: int | None = None) -> QPushButton:
    b = QPushButton(text)
    b.setFixedHeight(36)
    if w: b.setFixedWidth(w)
    b.setStyleSheet(action_btn_style(variant))
    b.setCursor(Qt.CursorShape.PointingHandCursor)
    return b

def _mklabel(text: str, color: str | None = None,
             size: int = 11, bold: bool = False) -> QLabel:
    lbl = QLabel(text)
    c = color or COLORS["text_label"]
    fw = "600" if bold else "400"
    lbl.setStyleSheet(
        f"color:{c};font-size:{size}px;font-weight:{fw};letter-spacing:0.5px;"
    )
    return lbl

def _mkinput(placeholder: str = "", password: bool = False) -> QLineEdit:
    le = QLineEdit()
    le.setPlaceholderText(placeholder)
    le.setFixedHeight(36)
    if password:
        le.setEchoMode(QLineEdit.EchoMode.Password)
    le.setStyleSheet(f"""
        QLineEdit {{
            background: {COLORS['bg_surface']};
            color: {COLORS['text_primary']};
            border: 1px solid {COLORS['bg_border']};
            border-radius: 6px;
            padding: 0 10px;
            font-size: 12px;
        }}
        QLineEdit:focus {{
            border-color: {COLORS['neon_border']};
            background: {COLORS['bg_elevated']};
        }}
    """)
    return le

def _section_header(title: str) -> QWidget:
    w = QWidget()
    h = QHBoxLayout(w)
    h.setContentsMargins(0, 4, 0, 4)
    h.setSpacing(10)
    bar = QFrame()
    bar.setFixedSize(3, 16)
    bar.setStyleSheet(f"background:{COLORS['accent_glow']};border-radius:2px;")
    h.addWidget(bar)
    lbl = QLabel(title)
    lbl.setStyleSheet(
        f"color:{COLORS['accent_glow']};font-size:10px;"
        f"font-weight:700;letter-spacing:3px;"
    )
    h.addWidget(lbl)
    h.addStretch()
    return w

def _card_frame() -> tuple[QFrame, QVBoxLayout]:
    f = QFrame()
    f.setStyleSheet(f"""
        QFrame {{
            background: {COLORS['bg_elevated']};
            border: 1px solid {COLORS['bg_border']};
            border-left: 2px solid {COLORS['neon_border']};
            border-radius: 10px;
        }}
    """)
    lay = QVBoxLayout(f)
    lay.setContentsMargins(18, 16, 18, 16)
    lay.setSpacing(12)
    return f, lay

def _spinbox(lo, hi, val, suffix="", w=80) -> QSpinBox:
    sb = QSpinBox()
    sb.setRange(lo, hi); sb.setValue(val)
    if suffix: sb.setSuffix(suffix)
    sb.setFixedHeight(36); sb.setFixedWidth(w)
    sb.setStyleSheet(f"""
        QSpinBox {{
            background:{COLORS['bg_surface']};color:{COLORS['text_primary']};
            border:1px solid {COLORS['bg_border']};border-radius:6px;
            padding:0 8px;font-size:12px;
        }}
        QSpinBox:focus {{ border-color:{COLORS['neon_border']}; }}
        QSpinBox::up-button, QSpinBox::down-button {{
            width:18px;background:{COLORS['bg_elevated']};
            border:none;border-radius:3px;
        }}
    """)
    return sb

def _dspinbox(lo, hi, val, w=70) -> QDoubleSpinBox:
    sb = QDoubleSpinBox()
    sb.setRange(lo, hi); sb.setValue(val)
    sb.setSingleStep(0.05); sb.setDecimals(2)
    sb.setFixedHeight(36); sb.setFixedWidth(w)
    sb.setStyleSheet(f"""
        QDoubleSpinBox {{
            background:{COLORS['bg_surface']};color:{COLORS['text_primary']};
            border:1px solid {COLORS['bg_border']};border-radius:6px;
            padding:0 6px;font-size:12px;
        }}
        QDoubleSpinBox:focus {{ border-color:{COLORS['neon_border']}; }}
        QDoubleSpinBox::up-button, QDoubleSpinBox::down-button {{
            width:18px;background:{COLORS['bg_elevated']};
            border:none;border-radius:3px;
        }}
    """)
    return sb

class WebhookPanel(QWidget):
    sig_log = pyqtSignal(str, str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._worker  = None
        self._running = False
        self._avatar  = None
        self._cfg     = _load_settings()
        self._sip: dict[str, str] = {
            "bosses":           self._cfg.get("spawn_bosses_img",          _DEFAULT_SPAWN_IMGS["bosses"]),
            "rift":             self._cfg.get("spawn_rift_img",            _DEFAULT_SPAWN_IMGS["rift"]),
            "merchant":         self._cfg.get("spawn_merchant_img",        _DEFAULT_SPAWN_IMGS["merchant"]),
            "gang_base_attack": self._cfg.get("spawn_gang_base_attack_img", _DEFAULT_SPAWN_IMGS["gang_base_attack"]),
            "turf":             self._cfg.get("spawn_turf_img",            _DEFAULT_SPAWN_IMGS["turf"]),
        }
        self._loading = True

        self._spawn_dets: dict[str, _SpawnDetector] = {
            k: _SpawnDetector(k, self._on_spawn)
            for k in ("bosses", "rift", "merchant", "gang_base_attack", "turf")
        }
        self._gank_mon = _GankMonitor(self._on_ganked, on_template_loaded=self._on_gank_template_loaded)
        self._str_mon  = _StrengthPixelMonitor(self._on_strength_absent)

        self._build_ui()
        self._load_into_ui()
        self._loading = False

        # Preload spawn images from assets/ at startup
        threading.Thread(target=self._preload_spawn_images, daemon=True).start()
        threading.Thread(target=self._preload_avatar, daemon=True).start()

    def _preload_avatar(self):
        self._log("Loading Eclipse avatar...", "info")
        url = _get_avatar()
        if url:
            self._avatar = url
            self._log("Eclipse avatar loaded ✓", "ok")
        else:
            self._log("Avatar unavailable (connection?)", "warn")

    def _on_gank_template_loaded(self, path: str):
        """Appelé quand fight.png (built-in) est chargé automatiquement — met à jour le label UI."""
        import os
        from PyQt6.QtCore import QMetaObject, Qt
        def _update():
            try:
                self._gank_img_label.setText("✓  fight.png  (built-in)")
                self._gank_img_label.setStyleSheet(
                    f"color:{COLORS['accent_ok']};font-size:10px;"
                    f"background:{COLORS['bg_surface']};border:1px solid {COLORS['bg_border']};"
                    f"border-radius:5px;padding:4px 10px;"
                )
            except Exception:
                pass
        # Poster sur le thread Qt principal
        from PyQt6.QtCore import QTimer
        QTimer.singleShot(0, _update)

    def _preload_spawn_images(self):
        """Automatically load boss/rift/merchant images from assets/."""
        for key, path in _DEFAULT_SPAWN_IMGS.items():
            saved = self._cfg.get(f"spawn_{key}_img", path)
            # Prefer saved file if it exists, else assets/
            target = saved if saved and os.path.exists(saved) else path
            if os.path.exists(target):
                self._load_spawn_image(key, target, silent=True)
                self._log(f"[{key}] Image loaded automatically ✓", "ok")
            else:
                self._log(f"[{key}] Image not found: {target}", "warn")

    def _build_ui(self):
        scroll = QScrollArea(self)
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setStyleSheet("QScrollArea { border: none; background: transparent; }")
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)

        inner = QWidget()
        inner.setStyleSheet("background: transparent;")
        root = QVBoxLayout(inner)
        root.setContentsMargins(20, 16, 20, 20)
        root.setSpacing(16)

        hdr = QHBoxLayout(); hdr.setSpacing(12)
        col = QVBoxLayout(); col.setSpacing(4)
        t = QLabel("WEBHOOK")
        t.setStyleSheet(f"color:{COLORS['text_primary']};font-size:18px;font-weight:300;letter-spacing:6px;")
        col.addWidget(t)
        s = QLabel("Discord — remote monitoring")
        s.setStyleSheet(f"color:{COLORS['text_secondary']};font-size:11px;")
        col.addWidget(s)
        hdr.addLayout(col); hdr.addStretch()
        badge = QLabel("◉  ECLIPSE BOT")
        badge.setStyleSheet(f"""
            color:{COLORS['accent_glow']};background:{COLORS['bg_elevated']};
            border:1px solid {COLORS['neon_border']};border-radius:6px;
            padding:6px 14px;font-size:9px;font-weight:700;letter-spacing:2px;
        """)
        hdr.addWidget(badge)
        root.addLayout(hdr)
        root.addWidget(NeonSeparator())

        # ── Card 1 : Configuration Discord ────────────────────────────────────
        c1, cl1 = _card_frame()
        cl1.addWidget(_section_header("DISCORD CONFIG"))

        cl1.addWidget(_mklabel("Webhook URL", size=11))
        self._le_url = _mkinput("https://discord.com/api/webhooks/...")
        cl1.addWidget(self._le_url)
        self._le_url.textChanged.connect(self._autosave)

        cl1.addWidget(_mklabel("Your Discord user ID (for @ mentions)", size=11))
        self._le_uid = _mkinput("ex. 123456789012345678  →  Settings > Advanced > Developer mode > right-click profile")
        cl1.addWidget(self._le_uid)
        self._le_uid.textChanged.connect(self._autosave)

        row_opts = QHBoxLayout(); row_opts.setSpacing(16)
        row_opts.addWidget(_mklabel("Screenshot interval:", size=11))
        self._sb_iv = _spinbox(1, 60, 5, " min", 110)
        self._sb_iv.valueChanged.connect(self._autosave)
        row_opts.addWidget(self._sb_iv)
        row_opts.addSpacing(20)
        row_opts.addWidget(_mklabel("Auto-start:", size=11))
        self._tog_auto = AnimatedToggle(checked=True)
        self._tog_auto.toggled.connect(self._autosave)
        row_opts.addWidget(self._tog_auto)
        row_opts.addStretch()
        cl1.addLayout(row_opts)

        row_btns = QHBoxLayout(); row_btns.setSpacing(10)
        self._btn_start = _mkbtn("▶  Start", "success", 150)
        self._btn_stop  = _mkbtn("⏹  Stop",  "danger",  120)
        self._btn_test  = _mkbtn("◎  Test",   "neutral", 110)
        self._btn_stop.setEnabled(False)
        self._btn_start.clicked.connect(self._on_start)
        self._btn_stop.clicked.connect(self._on_stop)
        self._btn_test.clicked.connect(self._on_test)
        row_btns.addWidget(self._btn_start)
        row_btns.addWidget(self._btn_stop)
        row_btns.addWidget(self._btn_test)
        row_btns.addStretch()
        self._lbl_status = QLabel("◉  OFFLINE")
        self._lbl_status.setStyleSheet(
            f"color:{COLORS['text_dim']};font-size:10px;font-weight:700;letter-spacing:2px;"
        )
        row_btns.addWidget(self._lbl_status)
        cl1.addLayout(row_btns)
        root.addWidget(c1)

        # ── Card 2 : Spawn Detection ─────────────────────────────────────────
        c2, cl2 = _card_frame()
        cl2.addWidget(_section_header("DETECTION"))

        info2 = QLabel(
            "Images are loaded automatically from assets/. "
            "You can select custom screenshots. "
            "A Discord ping + screenshot is sent as soon as a match is detected."
        )
        info2.setWordWrap(True)
        info2.setStyleSheet(
            f"color:{COLORS['text_secondary']};font-size:10px;"
            f"line-height:1.5;padding:2px 0;"
        )
        cl2.addWidget(info2)

        grid = QGridLayout(); grid.setSpacing(8)
        grid.setColumnMinimumWidth(0, 44)
        grid.setColumnMinimumWidth(1, 160)
        grid.setColumnStretch(2, 1)
        grid.setColumnMinimumWidth(3, 120)
        grid.setColumnMinimumWidth(4, 90)
        grid.setColumnMinimumWidth(5, 76)

        for col_i, txt in enumerate(["", "Spawn", "Reference screenshot", "", "Threshold", ""]):
            if txt:
                h = _mklabel(txt, COLORS["text_dim"], 9, True)
                grid.addWidget(h, 0, col_i)

        self._spawn_toggles   : dict[str, AnimatedToggle] = {}
        self._spawn_img_labels: dict[str, QLabel]         = {}
        self._spawn_thr_spins : dict[str, QDoubleSpinBox] = {}

        spawns = [
            ("bosses",           "🔥  Bosses"),
            ("rift",             "🌀  Rift"),
            ("merchant",         "🛒  Traveling Merchant"),
            ("gang_base_attack", "⚔️  Base Attacked"),
            ("turf",             "🏴  Turf"),
        ]
        for row_i, (key, display) in enumerate(spawns, start=1):
            tog = AnimatedToggle(checked=False)
            tog.toggled.connect(lambda v, k=key: (
                self._spawn_dets[k].set_enabled(v),
                self._autosave()
            ))
            self._spawn_toggles[key] = tog
            grid.addWidget(tog, row_i, 0, Qt.AlignmentFlag.AlignVCenter)

            grid.addWidget(_mklabel(display, size=11), row_i, 1, Qt.AlignmentFlag.AlignVCenter)

            fl = QLabel("Loading...")
            fl.setStyleSheet(f"""
                color:{COLORS['text_dim']};font-size:10px;
                background:{COLORS['bg_surface']};
                border:1px solid {COLORS['bg_border']};border-radius:5px;
                padding:4px 10px;
            """)
            fl.setMinimumHeight(36)
            self._spawn_img_labels[key] = fl
            grid.addWidget(fl, row_i, 2, Qt.AlignmentFlag.AlignVCenter)

            btn = _mkbtn("📂  Browse", "neutral")
            btn.clicked.connect(lambda _, k=key: self._pick_spawn_image(k))
            grid.addWidget(btn, row_i, 3, Qt.AlignmentFlag.AlignVCenter)

            grid.addWidget(_mklabel("Threshold:", size=10), row_i, 4, Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignRight)
            sp = _dspinbox(0.50, 0.99, 0.80, 76)
            sp.valueChanged.connect(lambda v, k=key: self._spawn_dets[k].set_threshold(v))
            self._spawn_thr_spins[key] = sp
            grid.addWidget(sp, row_i, 5, Qt.AlignmentFlag.AlignVCenter)

        # ── Gank row (template matching) ─────────────────────────────────────
        gank_row_i = len(spawns) + 1
        self._tog_gank = AnimatedToggle(checked=False)
        self._tog_gank.toggled.connect(self._gank_mon.set_enabled)
        self._tog_gank.toggled.connect(lambda _: self._autosave())
        grid.addWidget(self._tog_gank, gank_row_i, 0, Qt.AlignmentFlag.AlignVCenter)

        grid.addWidget(_mklabel("☠  Gank (Live on the Edge)", size=11), gank_row_i, 1, Qt.AlignmentFlag.AlignVCenter)

        self._gank_img_label = QLabel("fight.png  (built-in)")
        self._gank_img_label.setStyleSheet(f"""
            color:{COLORS['text_dim']};font-size:10px;
            background:{COLORS['bg_surface']};
            border:1px solid {COLORS['bg_border']};border-radius:5px;
            padding:4px 10px;
        """)
        self._gank_img_label.setMinimumHeight(36)
        grid.addWidget(self._gank_img_label, gank_row_i, 2, Qt.AlignmentFlag.AlignVCenter)

        btn_gank_browse = _mkbtn("📂  Browse", "neutral")
        btn_gank_browse.clicked.connect(self._pick_gank_image)
        grid.addWidget(btn_gank_browse, gank_row_i, 3, Qt.AlignmentFlag.AlignVCenter)

        grid.addWidget(_mklabel("Threshold:", size=10), gank_row_i, 4, Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignRight)
        self._gank_thr = _dspinbox(0.40, 1.00, 0.55, 76)
        self._gank_thr.setSingleStep(0.01)
        self._gank_thr.valueChanged.connect(lambda v: self._gank_mon.set_threshold(v))
        grid.addWidget(self._gank_thr, gank_row_i, 5, Qt.AlignmentFlag.AlignVCenter)

        cl2.addLayout(grid)
        root.addWidget(c2)

        # ── Card 3 : Pixel Strength Training (Durability) ────────────────────
        c4, cl4 = _card_frame()
        cl4.addWidget(_section_header("PIXEL STRENGTH TRAINING (DURABILITY)"))

        info4 = QLabel(
            "During Durability strength training, if this pixel is missing, the bot captures a screenshot "
            "and notifies you. This pixel is different from the gank pixel."
        )
        info4.setWordWrap(True)
        info4.setStyleSheet(
            f"color:{COLORS['text_secondary']};font-size:10px;line-height:1.5;padding:2px 0;"
        )
        cl4.addWidget(info4)

        row_se = QHBoxLayout(); row_se.setSpacing(12)
        row_se.addWidget(_mklabel("Enable strength pixel monitoring", size=11))
        self._tog_str = AnimatedToggle(checked=False)
        self._tog_str.toggled.connect(self._str_mon.set_enabled)
        self._tog_str.toggled.connect(lambda _: self._autosave())
        row_se.addWidget(self._tog_str)
        row_se.addStretch()
        cl4.addLayout(row_se)

        sp_grid = QGridLayout(); sp_grid.setSpacing(8)

        def _add_sp_field(col, label, widget):
            sp_grid.addWidget(_mklabel(label, size=10), 0, col*2)
            sp_grid.addWidget(widget, 0, col*2+1)

        self._str_x   = _spinbox(0, 9999, 960, w=80)
        self._str_y   = _spinbox(0, 9999, 540, w=80)
        self._str_col = _mkinput("0xFFFFFF")
        self._str_col.setFixedWidth(100)
        self._str_tol = _spinbox(0, 255, 20, w=70)

        _add_sp_field(0, "X :", self._str_x)
        _add_sp_field(1, "Y :", self._str_y)
        _add_sp_field(2, "Color:", self._str_col)
        _add_sp_field(3, "Tolerance:", self._str_tol)

        btn_apply_str = _mkbtn("✔  Apply", "neutral", 130)
        btn_apply_str.clicked.connect(self._apply_str_pixel)
        sp_grid.addWidget(btn_apply_str, 0, 8)
        sp_grid.setColumnStretch(9, 1)
        cl4.addLayout(sp_grid)
        root.addWidget(c4)

        # ── Log ───────────────────────────────────────────────────────────────
        log_hdr = QHBoxLayout()
        log_hdr.addWidget(_mklabel("ECLIPSE BOT LOG", COLORS["text_dim"], 9, True))
        log_hdr.addStretch()
        btn_clear = QPushButton("Clear")
        btn_clear.setFixedHeight(22)
        btn_clear.setStyleSheet(
            f"color:{COLORS['text_dim']};background:transparent;"
            f"border:none;font-size:9px;text-decoration:underline;"
        )
        btn_clear.clicked.connect(self._log_area.clear if hasattr(self, "_log_area") else lambda: None)
        btn_clear.clicked.connect(lambda: self._log_area.clear())
        log_hdr.addWidget(btn_clear)
        root.addLayout(log_hdr)

        self._log_area = QTextEdit()
        self._log_area.setReadOnly(True)
        self._log_area.setFixedHeight(160)
        self._log_area.setStyleSheet(f"""
            QTextEdit {{
                background:{COLORS['bg_surface']};
                border:1px solid {COLORS['bg_border']};
                border-left:3px solid {COLORS['neon_border']};
                border-radius:8px;
                color:{COLORS['text_secondary']};
                font-size:11px;
                font-family:"Cascadia Code",Consolas,monospace;
                padding:8px;
                line-height:1.4;
            }}
        """)
        root.addWidget(self._log_area)
        root.addStretch()

        scroll.setWidget(inner)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.addWidget(scroll)

    def _load_into_ui(self):
        c = self._cfg
        self._le_url.setText(c.get("webhook_url", ""))
        self._le_uid.setText(c.get("user_id", ""))
        self._sb_iv.setValue(c.get("interval_min", 5))
        self._tog_auto.setChecked(c.get("auto_start", True))

        for key in ("bosses", "rift", "merchant", "gang_base_attack", "turf"):
            on  = c.get(f"spawn_{key}_on", False)
            thr = c.get(f"spawn_{key}_thr", 0.80)
            self._spawn_toggles[key].setChecked(on)
            self._spawn_thr_spins[key].setValue(thr)
            self._spawn_dets[key].set_enabled(on)
            self._spawn_dets[key].set_threshold(thr)

        self._tog_gank.setChecked(c.get("gank_on", False))
        self._gank_thr.setValue(c.get("gank_thr", 0.72))
        self._gank_mon.set_enabled(c.get("gank_on", False))
        self._gank_mon.set_threshold(c.get("gank_thr", 0.72))
        gank_img_path = c.get("gank_img", "")
        if gank_img_path and os.path.isfile(gank_img_path):
            try:
                from PIL import Image
                self._gank_mon._tpl = Image.open(gank_img_path).convert("RGB")
                self._gank_img_label.setText(f"✓  {os.path.basename(gank_img_path)}")
                self._gank_img_label.setStyleSheet(
                    f"color:{COLORS['accent_ok']};font-size:10px;"
                    f"background:{COLORS['bg_surface']};border:1px solid {COLORS['bg_border']};"
                    f"border-radius:5px;padding:4px 10px;"
                )
            except Exception:
                pass

        self._tog_str.setChecked(c.get("strength_pixel_on", False))
        self._str_x.setValue(c.get("strength_pixel_x", 960))
        self._str_y.setValue(c.get("strength_pixel_y", 540))
        self._str_col.setText(c.get("strength_pixel_color", "0xFFFFFF"))
        self._str_tol.setValue(c.get("strength_pixel_tol", 20))
        self._str_mon.set_enabled(c.get("strength_pixel_on", False))
        self._apply_str_pixel(silent=True)

    def _autosave(self, *_):
        if getattr(self, "_loading", True):
            return
        self._cfg.update({
            "webhook_url":  self._le_url.text().strip(),
            "user_id":      self._le_uid.text().strip(),
            "interval_min": self._sb_iv.value(),
            "auto_start":   self._tog_auto.isChecked(),
            "gank_on":  self._tog_gank.isChecked(),
            "gank_thr": self._gank_thr.value(),
            "gank_img": self._cfg.get("gank_img", ""),
            "strength_pixel_on":    self._tog_str.isChecked(),
            "strength_pixel_x":     self._str_x.value(),
            "strength_pixel_y":     self._str_y.value(),
            "strength_pixel_color": self._str_col.text().strip(),
            "strength_pixel_tol":   self._str_tol.value(),
        })
        for key in ("bosses", "rift", "merchant", "gang_base_attack", "turf"):
            self._cfg[f"spawn_{key}_on"]  = self._spawn_toggles[key].isChecked()
            self._cfg[f"spawn_{key}_thr"] = self._spawn_thr_spins[key].value()
            self._cfg[f"spawn_{key}_img"] = self._sip.get(key, "")
        _save_settings(self._cfg)

    @property
    def _spawn_img_paths(self) -> dict:
        return self._sip

    def _pick_spawn_image(self, key: str):
        path, _ = QFileDialog.getOpenFileName(
            self, f"Screenshot — {key}", "", "Images (*.png *.jpg *.bmp)"
        )
        if path:
            self._load_spawn_image(key, path)

    def _pick_gank_image(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Gank template image", "", "Images (*.png *.jpg *.bmp)"
        )
        if not path:
            return
        try:
            from PIL import Image
            img = Image.open(path).convert("RGB")
            self._gank_mon._tpl = img
            short = os.path.basename(path)
            self._gank_img_label.setText(f"✓  {short}")
            self._gank_img_label.setStyleSheet(
                f"color:{COLORS['accent_ok']};font-size:10px;"
                f"background:{COLORS['bg_surface']};border:1px solid {COLORS['bg_border']};"
                f"border-radius:5px;padding:4px 10px;"
            )
            self._cfg["gank_img"] = path
            self._autosave()
            self._log(f"Gank template: {short}", "ok")
        except Exception as e:
            self._log(f"Gank image load error: {e}", "error")

    def _load_spawn_image(self, key: str, path: str, silent: bool = False):
        try:
            from PIL import Image
            img = Image.open(path).convert("RGB")
            self._spawn_dets[key].set_template(img)
            self._sip[key] = path
            short = os.path.basename(path)
            self._spawn_img_labels[key].setText(f"✓  {short}")
            self._spawn_img_labels[key].setStyleSheet(
                f"color:{COLORS['accent_ok']};font-size:10px;"
                f"background:{COLORS['bg_surface']};border:1px solid {COLORS['bg_border']};"
                f"border-radius:5px;padding:4px 10px;"
            )
            self._cfg[f"spawn_{key}_img"] = path
            if not silent:
                self._log(f"[{key}] Template loaded: {short}", "ok")
                _save_settings(self._cfg)
        except Exception as e:
            if not silent:
                self._log(f"[{key}] Error: {e}", "error")

    def _on_spawn(self, key: str):
        url = self._le_url.text().strip()
        if not url.startswith("https://discord.com/api/webhooks/"):
            self._log(f"[{key}] Spawn detected but webhook URL is invalid!", "warn")
            return
        uid = self._le_uid.text().strip()
        msgs = {
            "bosses":           "🔥 Bosses have spawned!",
            "rift":             "🌀 A Rift has spawned!",
            "merchant":         "🛒 The Traveling Merchant has spawned!",
            "gang_base_attack": "⚔️ The gang base is under attack!",
            "turf":             "🏴 A turf has spawned!",
        }
        ping  = f"<@{uid}> " if uid else ""
        content = f"{ping}{msgs[key]}"
        self._log(f"Spawn detected → {key} — alert sent!", "warn")
        def _send():
            img = _grab_bytes()
            ok, msg = _discord_send(url, content, img, self._avatar)
            if not ok:
                self._log(f"Spawn send error [{key}]: {msg}", "error")
        threading.Thread(target=_send, daemon=True).start()

    def _apply_gank(self, *_, silent: bool = False):
        thr = self._gank_thr.value()
        self._gank_mon.set_threshold(thr)
        if not silent:
            self._log(f"Gank detection: template matching threshold={thr:.2f}", "info")
            self._autosave()

    def _apply_str_pixel(self, *_, silent: bool = False):
        try:
            raw = self._str_col.text().strip()
            c   = int(raw, 16) if raw.startswith("0x") or raw.startswith("0X") else int(raw.lstrip("#"), 16)
        except Exception:
            if not silent:
                self._log("Invalid strength pixel color. Format: 0xRRGGBB", "error")
            return
        self._str_mon.set_config(
            self._str_x.value(), self._str_y.value(), c, self._str_tol.value()
        )
        if not silent:
            self._log(
                f"Strength pixel config: ({self._str_x.value()},{self._str_y.value()}) "
                f"color=0x{c:06X} tol={self._str_tol.value()}", "info"
            )
            self._autosave()

    def _on_ganked(self):
        url = self._le_url.text().strip()
        if not url.startswith("https://discord.com/api/webhooks/"):
            return
        uid = self._le_uid.text().strip()
        ping = f"<@{uid}> " if uid else ""
        content = f"{ping}⚔️ **GANK DETECTED!** Enemy pixel visible on screen!"
        self._log("⚔  Gank detected (pixel visible)!", "warn")
        def _send():
            img = _grab_bytes()
            ok, msg = _discord_send(url, content, img, self._avatar)
            if not ok:
                self._log(f"Gank send error: {msg}", "error")
        threading.Thread(target=_send, daemon=True).start()

    def _on_strength_absent(self):
        """Called when the strength training pixel is no longer detected."""
        url = self._le_url.text().strip()
        if not url.startswith("https://discord.com/api/webhooks/"):
            return
        uid = self._le_uid.text().strip()
        ping = f"<@{uid}> " if uid else ""
        content = f"{ping}⚠️ **STRENGTH TRAINING** — Pixel missing! Check WIN1."
        self._log("⚠  Strength pixel absent — Discord alert sent", "warn")
        def _send():
            img = _grab_bytes()
            ok, msg = _discord_send(url, content, img, self._avatar)
            if not ok:
                self._log(f"Strength send error: {msg}", "error")
        threading.Thread(target=_send, daemon=True).start()

    def on_phase_changed(self, phase: str):
        self._gank_mon.set_macro_active(phase in GANK_MODES)
        # Active le monitor strength uniquement pendant les phases de strength training
        self._str_mon.set_active(phase == "Strength")

    def _validate_url(self) -> str | None:
        url = self._le_url.text().strip()
        if not url.startswith("https://discord.com/api/webhooks/"):
            self._log("URL webhook invalide. Format attendu : https://discord.com/api/webhooks/...", "warn")
            return None
        return url

    def _on_start(self):
        url = self._validate_url()
        if not url:
            return
        self._worker = _WebhookWorker(url, self._sb_iv.value(), self._avatar, self._log)
        self._running = True
        self._btn_start.setEnabled(False)
        self._btn_stop.setEnabled(True)
        self._lbl_status.setText("◉  ONLINE")
        self._lbl_status.setStyleSheet(
            f"color:{COLORS['accent_ok']};font-size:10px;font-weight:700;letter-spacing:2px;"
        )

    def _on_stop(self):
        if self._worker:
            self._worker.stop()
            self._worker = None
        self._running = False
        self._btn_start.setEnabled(True)
        self._btn_stop.setEnabled(False)
        self._lbl_status.setText("◉  OFFLINE")
        self._lbl_status.setStyleSheet(
            f"color:{COLORS['text_dim']};font-size:10px;font-weight:700;letter-spacing:2px;"
        )

    def _on_test(self):
        url = self._validate_url()
        if not url:
            return
        self._log("Test in progress...", "info")
        def _do():
            img = _grab_bytes()
            uid = self._le_uid.text().strip()
            ping = f"<@{uid}> " if uid else ""
            ok, msg = _discord_send(url, f"{ping}🧪 Eclipse Bot — test message", img, self._avatar)
            if ok:
                self._log(f"Test succeeded! ({len(img)//1024 if img else 0} KB) — {msg}", "ok")
            else:
                self._log(f"Test failed: {msg}", "error")
        threading.Thread(target=_do, daemon=True).start()

    def on_macro_started(self):
        if self._tog_auto.isChecked() and not self._running:
            url = self._le_url.text().strip()
            if url.startswith("https://discord.com/api/webhooks/"):
                self._on_start()
            else:
                self._log("Auto-start ignored: URL not configured.", "info")

    def on_macro_stopped(self):
        if self._running and self._tog_auto.isChecked():
            self._on_stop()

    def _log(self, msg: str, level: str = "info"):
        clr = {
            "ok":    COLORS.get("accent_ok",    "#4ade80"),
            "error": COLORS.get("accent_error",  "#f87171"),
            "warn":  COLORS.get("accent_warn",   "#fbbf24"),
            "info":  COLORS.get("text_secondary","#7068A0"),
        }.get(level, COLORS.get("text_secondary", "#7068A0"))
        dim = COLORS.get("text_dim", "#302858")
        ts  = time.strftime("%H:%M:%S")
        self._log_area.append(
            f'<span style="color:{dim}">[{ts}]</span> '
            f'<span style="color:{clr}">{msg}</span>'
        )
        self.sig_log.emit(msg, level)

    def closeEvent(self, event):
        for d in self._spawn_dets.values():
            d.stop()
        self._gank_mon.stop()
        self._str_mon.stop()
        super().closeEvent(event)
