
import ctypes
import ctypes.wintypes
from PyQt6.QtWidgets import QWidget, QLabel
from PyQt6.QtCore import Qt, QRect, pyqtSignal, QPoint, QTimer
from PyQt6.QtGui import QColor, QFont, QPainter, QPen, QBrush, QCursor
from PyQt6.QtCore import QSize

class DraggablePoint(QWidget):
    pos_changed = pyqtSignal(int, int, str)  # x, y, label

    def __init__(self, label: str, initial_x: int, initial_y: int, parent=None,
                 color: QColor = None, display_label: str = "K", tooltip: str = ""):
        super().__init__(parent)
        self.label = label
        self.pos_x = initial_x
        self.pos_y = initial_y
        self._dragging = False
        self._drag_offset = QPoint()
        self._color = color if color is not None else QColor(255, 0, 0)
        self._display_label = display_label

        self.setGeometry(initial_x - 8, initial_y - 8, 16, 16)
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setCursor(QCursor(Qt.CursorShape.OpenHandCursor))
        if tooltip:
            self.setToolTip(tooltip)

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self._dragging = True
            self._drag_offset = event.pos()
            self.setCursor(QCursor(Qt.CursorShape.ClosedHandCursor))

    def mouseMoveEvent(self, event):
        if self._dragging:
            new_pos = self.pos() + event.pos() - self._drag_offset
            self.move(new_pos)
            self.pos_x = new_pos.x() + 8
            self.pos_y = new_pos.y() + 8
            self.pos_changed.emit(self.pos_x, self.pos_y, self.label)

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self._dragging = False
            self.setCursor(QCursor(Qt.CursorShape.OpenHandCursor))

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        pen = QPen(self._color, 2)
        fill = QColor(self._color.red(), self._color.green(), self._color.blue(), 100)
        brush = QBrush(fill)
        painter.setPen(pen)
        painter.setBrush(brush)
        painter.drawEllipse(2, 2, 12, 12)

        font = QFont()
        font.setPointSize(7)
        painter.setFont(font)
        painter.setPen(QColor(255, 255, 255))
        painter.drawText(0, -12, 16, 10, Qt.AlignmentFlag.AlignCenter, self._display_label)


class DurabilityCalibrationOverlay(QWidget):

    points_updated = pyqtSignal(dict)

    def __init__(self, cfg, parent=None):
        super().__init__(parent)
        self.cfg = cfg
        self._points = {}
        self._visible = False
        self._sub_mode = "selfish_v1"
        self._build_overlay()

    def _build_overlay(self):
        # ── Always-present points (Win1 — rouge = STR, vert = DUR) ────────────
        str_x = int(self.cfg.get("DUR1_StrengthX", 280))
        str_y = int(self.cfg.get("DUR1_StrengthY", 108))
        strength_point = DraggablePoint(
            "STR", str_x, str_y,
            color=QColor(255, 0, 0),
            display_label="K",
            tooltip="WIN1 — Strength training position (rouge)"
        )
        strength_point.pos_changed.connect(self._on_point_moved)
        self._points["strength"] = strength_point

        dur_x = int(self.cfg.get("DUR1_ClickX", 200))
        dur_y = int(self.cfg.get("DUR1_ClickY", 108))
        durability_point = DraggablePoint(
            "DUR", dur_x, dur_y,
            color=QColor(0, 220, 80),
            display_label="K",
            tooltip="WIN1 — Durability training position (vert)"
        )
        durability_point.pos_changed.connect(self._on_point_moved)
        self._points["durability"] = durability_point

        # ── Selfish V3 extra points (Win2 — orange = STR, bleu = DUR) ─────────
        v3_str_x = int(self.cfg.get("SV3_W2_StrStatX", 280))
        v3_str_y = int(self.cfg.get("SV3_W2_StrStatY", 108))
        v3_str_point = DraggablePoint(
            "V3_STR", v3_str_x, v3_str_y,
            color=QColor(255, 140, 0),
            display_label="K",
            tooltip="WIN2 — Strength training position (orange)"
        )
        v3_str_point.pos_changed.connect(self._on_point_moved)
        self._points["v3_strength"] = v3_str_point

        v3_dur_x = int(self.cfg.get("SV3_W2_DurBuyX", 200))
        v3_dur_y = int(self.cfg.get("SV3_W2_DurBuyY", 108))
        v3_dur_point = DraggablePoint(
            "V3_DUR", v3_dur_x, v3_dur_y,
            color=QColor(0, 120, 255),
            display_label="K",
            tooltip="WIN2 — Durability training position (bleu)"
        )
        v3_dur_point.pos_changed.connect(self._on_point_moved)
        self._points["v3_durability"] = v3_dur_point

        # Initially hide all V3 points
        self._points["v3_strength"].hide()
        self._points["v3_durability"].hide()

    def is_visible(self) -> bool:
        """Return True if the overlay points are currently shown."""
        return self._visible

    def set_sub_mode(self, mode: str):
        """Call when the dropdown changes. mode: 'selfish_v1'|'selfish_v2'|'selfish_v3'|'durability'"""
        self._sub_mode = mode
        # If overlay is currently visible, refresh which points are shown
        if self._visible:
            self._refresh_point_visibility()

    def toggle_visibility(self):
        self._visible = not self._visible
        if self._visible:
            self._refresh_point_visibility()
        else:
            for point in self._points.values():
                point.hide()
        return self._visible

    def _refresh_point_visibility(self):
        is_v3 = (self._sub_mode == "selfish_v3")
        self._points["strength"].setVisible(True)
        self._points["durability"].setVisible(True)
        self._points["v3_strength"].setVisible(is_v3)
        self._points["v3_durability"].setVisible(is_v3)

    def show_points(self):
        if not self._visible:
            self._visible = True
            self._refresh_point_visibility()

    def hide_points(self):
        if self._visible:
            self._visible = False
            for point in self._points.values():
                point.hide()

    def _on_point_moved(self, x: int, y: int, label: str):
        if label == "STR":
            self.cfg.set("DUR1_StrengthX", x)
            self.cfg.set("DUR1_StrengthY", y)
        elif label == "DUR":
            self.cfg.set("DUR1_ClickX", x)
            self.cfg.set("DUR1_ClickY", y)
        elif label == "V3_STR":
            self.cfg.set("SV3_W2_StrStatX", x)
            self.cfg.set("SV3_W2_StrStatY", y)
        elif label == "V3_DUR":
            self.cfg.set("SV3_W2_DurBuyX", x)
            self.cfg.set("SV3_W2_DurBuyY", y)

        self.points_updated.emit(self.get_config_updates())

    def get_config_updates(self) -> dict:
        return {
            "DUR1_StrengthX":  int(self._points["strength"].pos_x),
            "DUR1_StrengthY":  int(self._points["strength"].pos_y),
            "DUR1_ClickX":     int(self._points["durability"].pos_x),
            "DUR1_ClickY":     int(self._points["durability"].pos_y),
            "SV3_W2_StrStatX": int(self._points["v3_strength"].pos_x),
            "SV3_W2_StrStatY": int(self._points["v3_strength"].pos_y),
            "SV3_W2_DurBuyX":  int(self._points["v3_durability"].pos_x),
            "SV3_W2_DurBuyY":  int(self._points["v3_durability"].pos_y),
        }
