
import os
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame,
    QPushButton, QLineEdit, QScrollArea, QGridLayout,
)
from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QPixmap, QIntValidator

from .theme import COLORS, sidebar_btn_style
from core.config_manager import ConfigManager

def _sec(txt):
    l = QLabel(txt)
    l.setStyleSheet(
        f"color:{COLORS['accent_gold']};font-size:10px;"
        f"font-weight:700;letter-spacing:2px;padding-bottom:4px;"
    )
    return l

def _fld(txt):
    l = QLabel(txt)
    l.setStyleSheet(f"color:{COLORS['text_secondary']};font-size:11px;")
    return l

def _dim(txt):
    l = QLabel(txt)
    l.setStyleSheet(f"color:{COLORS['text_dim']};font-size:10px;")
    return l

def _le(ph="", int_only=False, w=None):
    e = QLineEdit()
    e.setPlaceholderText(ph)
    if int_only:
        e.setValidator(QIntValidator(0, 99999))
    e.setFixedHeight(28)
    if w:
        e.setFixedWidth(w)
    e.setStyleSheet(f"""
        QLineEdit{{background:{COLORS['bg_elevated']};
        border:1px solid {COLORS['bg_border']};border-radius:6px;
        color:{COLORS['text_primary']};font-size:12px;padding:0 8px;}}
        QLineEdit:focus{{border:1px solid {COLORS['accent']};}}
    """)
    return e

def _card_frame():
    f = QFrame()
    f.setStyleSheet(
        f"QFrame{{background:{COLORS['bg_elevated']};"
        f"border:1px solid {COLORS['bg_border']};border-radius:10px;}}"
    )
    return f

def _separator():
    sep = QFrame()
    sep.setFrameShape(QFrame.Shape.HLine)
    sep.setStyleSheet(f"color:{COLORS['bg_border']};margin:2px 0;")
    return sep

def _xy_row(label, key_x, key_y, fields_dict, parent_layout):
    row = QHBoxLayout(); row.setSpacing(8)
    row.addWidget(_fld(label)); row.addStretch()
    le_x = _le(str(key_x), int_only=True, w=70)
    le_y = _le(str(key_y), int_only=True, w=70)
    row.addWidget(_dim("X")); row.addWidget(le_x)
    row.addWidget(_dim("Y")); row.addWidget(le_y)
    parent_layout.addLayout(row)
    fields_dict[key_x] = le_x
    fields_dict[key_y] = le_y

def _pixel_block(title, px_key, py_key, color_key, tol_key, fields_dict, parent_layout):
    parent_layout.addWidget(_fld(title))
    g = QGridLayout(); g.setSpacing(6); g.setContentsMargins(0, 0, 0, 4)
    for col_i, (lbl, key, ph) in enumerate([
        ("X", px_key, "960"), ("Y", py_key, "540"),
        ("Color", color_key, "0xFFFFFF"), ("Tol", tol_key, "20")
    ]):
        hdr = QLabel(lbl)
        hdr.setStyleSheet(f"color:{COLORS['text_dim']};font-size:10px;")
        g.addWidget(hdr, 0, col_i)
        is_int = key.endswith(("_X", "_Y", "_Tol", "_Tolerance"))
        le = _le(ph, int_only=is_int,
                 w=72 if col_i < 2 else 90 if col_i == 2 else 50)
        g.addWidget(le, 1, col_i)
        fields_dict[key] = le
    parent_layout.addLayout(g)

def _key_row(label, cfg_key, ph, fields_dict, parent_layout):
    row = QHBoxLayout(); row.setSpacing(8)
    row.addWidget(_fld(label))
    le = _le(ph, w=60)
    fields_dict[cfg_key] = le
    row.addWidget(le); row.addStretch()
    parent_layout.addLayout(row)

def _val_row(label, cfg_key, ph, fields_dict, parent_layout, int_only=False, w=80):
    row = QHBoxLayout(); row.setSpacing(8)
    row.addWidget(_fld(label))
    le = _le(ph, int_only=int_only, w=w)
    fields_dict[cfg_key] = le
    row.addWidget(le); row.addStretch()
    parent_layout.addLayout(row)

class StrengthPanel(QWidget):
    sig_select_str = pyqtSignal()
    sig_saved      = pyqtSignal()

    def __init__(self, config: ConfigManager, parent=None):
        super().__init__(parent)
        self._cfg    = config
        self._fields: dict[str, QLineEdit] = {}
        self._active = False
        self._build_ui()
        self.refresh_from_config()

    def _build_ui(self):
        root = QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        sidebar = QFrame()
        sidebar.setFixedWidth(160)
        sidebar.setStyleSheet(
            f"QFrame{{background:{COLORS['bg_base']};"
            f"border-right:1px solid {COLORS['bg_border']};}}"
        )
        sb_lay = QVBoxLayout(sidebar)
        sb_lay.setContentsMargins(12, 20, 12, 20)
        sb_lay.setSpacing(8)

        logo_lbl = QLabel()
        logo_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        assets = os.path.join(os.path.dirname(os.path.dirname(__file__)), "assets")
        logo_path = os.path.join(assets, "strength_logo.png")
        if os.path.isfile(logo_path):
            pm = QPixmap(logo_path).scaled(
                64, 64,
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation
            )
            logo_lbl.setPixmap(pm)
        sb_lay.addWidget(logo_lbl)

        title = QLabel("STRENGTH")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setStyleSheet(
            f"color:{COLORS['text_primary']};font-size:13px;"
            f"font-weight:700;letter-spacing:2px;"
        )
        sb_lay.addWidget(title)
        sb_lay.addSpacing(12)

        self._btn_select = QPushButton("✅  Select")
        self._btn_select.setFixedHeight(36)
        self._btn_select.setStyleSheet(sidebar_btn_style(False))
        self._btn_select.clicked.connect(self._on_select)
        sb_lay.addWidget(self._btn_select)

        self._btn_save = QPushButton("💾  Save")
        self._btn_save.setFixedHeight(36)
        self._btn_save.setStyleSheet(sidebar_btn_style(False))
        self._btn_save.clicked.connect(self._on_save)
        sb_lay.addWidget(self._btn_save)

        sb_lay.addStretch()
        root.addWidget(sidebar)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setStyleSheet("background:transparent;")

        inner = QWidget()
        inner.setStyleSheet("background:transparent;")
        inner_lay = QVBoxLayout(inner)
        inner_lay.setContentsMargins(20, 20, 20, 20)
        inner_lay.setSpacing(16)

        inner_lay.addWidget(self._build_config_card())
        inner_lay.addWidget(self._build_timing_card())
        inner_lay.addWidget(self._build_stamina_card())
        inner_lay.addStretch()

        scroll.setWidget(inner)
        root.addWidget(scroll)

    def _build_config_card(self):
        card = _card_frame()
        lay  = QVBoxLayout(card)
        lay.setContentsMargins(16, 16, 16, 16)
        lay.setSpacing(10)
        lay.addWidget(_sec("CONFIGURATION"))

        _xy_row("Position Strength Training", "STR_StrengthX", "STR_StrengthY", self._fields, lay)
        lay.addWidget(_separator())
        _key_row("Strength Training Key",  "STR_StrengthKey",  "r", self._fields, lay)
        _key_row("Fighting Style Key",      "STR_FightStyleKey","f", self._fields, lay)

        return card

    def _build_timing_card(self):
        card = _card_frame()
        lay  = QVBoxLayout(card)
        lay.setContentsMargins(16, 16, 16, 16)
        lay.setSpacing(10)
        lay.addWidget(_sec("TIMING"))

        _val_row("Training Duration (s)",         "STR_TrainingDuration",   "30",   self._fields, lay, w=80)
        _val_row("Left Click Interval (ms)","STR_LClickInterval",    "1154", self._fields, lay, int_only=True, w=80)
        _val_row("Wait before right click (ms)","STR_RClickWait",       "1000", self._fields, lay, int_only=True, w=80)
        _val_row("Right Click → Left Click Delay (ms)","STR_RClickToLClickDelay","300", self._fields, lay, int_only=True, w=80)
        _val_row("Left Clicks per Series",      "STR_ClicksPerSeries",   "5",    self._fields, lay, int_only=True, w=80)

        note = QLabel("ℹ️  Sequence: [L-click × N] → [Wait before R-click] → R-click → [R→L delay] → repeat")
        note.setStyleSheet(f"color:{COLORS['text_dim']};font-size:10px;")
        note.setWordWrap(True)
        lay.addWidget(note)

        return card

    def _build_stamina_card(self):
        card = _card_frame()
        lay  = QVBoxLayout(card)
        lay.setContentsMargins(16, 16, 16, 16)
        lay.setSpacing(10)
        lay.addWidget(_sec("STAMINA DETECTION"))

        note = QLabel(
            "If the stamina pixel disappears during training, "
            "clicks stop and the macro waits for the timer to end. "
            "Leave Color empty to disable."
        )
        note.setStyleSheet(f"color:{COLORS['text_dim']};font-size:10px;")
        note.setWordWrap(True)
        lay.addWidget(note)

        _pixel_block("Pixel Stamina",
                     "STR_StaminaX", "STR_StaminaY",
                     "STR_StaminaColor", "STR_StaminaTol",
                     self._fields, lay)
        _val_row("Disappearance Confirmation Delay (s)", "STR_PixelGoneDelay", "0.7", self._fields, lay, w=70)

        return card

    def set_active(self, active: bool):
        self._active = active
        self._btn_select.setStyleSheet(sidebar_btn_style(active))

    def _on_select(self):
        self._on_save()
        self.sig_select_str.emit()

    def _on_save(self):
        from core.config_manager import STRENGTH_DEFAULTS
        for key, widget in self._fields.items():
            default = STRENGTH_DEFAULTS.get(key, "")
            raw = widget.text().strip()
            if isinstance(default, float):
                try:
                    self._cfg.set(key, float(raw.replace(",", ".")))
                except ValueError:
                    self._cfg.set(key, default)
            elif isinstance(default, int):
                try:
                    self._cfg.set(key, int(raw))
                except ValueError:
                    self._cfg.set(key, default)
            else:
                self._cfg.set(key, raw)
        self._cfg.save_profile()
        self.sig_saved.emit()

    def refresh_from_config(self):
        defaults = {
            "STR_StrengthX": "280",    "STR_StrengthY": "108",
            "STR_StrengthKey": "r",    "STR_FightStyleKey": "f",
            "STR_TrainingDuration": "30.0",
            "STR_LClickInterval": "1154",
            "STR_RClickWait": "1000",
            "STR_RClickToLClickDelay": "300",
            "STR_ClicksPerSeries": "5",
            "STR_StaminaX": "0",       "STR_StaminaY": "0",
            "STR_StaminaColor": "",    "STR_StaminaTol": "30",
            "STR_PixelGoneDelay": "0.7",
        }
        for key, widget in self._fields.items():
            raw = self._cfg.get(key, defaults.get(key, ""))
            widget.setText("" if raw is None else str(raw))
