
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QListWidget,
    QListWidgetItem, QInputDialog, QMessageBox, QFrame,
)
from PyQt6.QtCore import Qt, pyqtSignal

from .theme import COLORS, action_btn_style
from .widgets import GlowButton, SectionCard
from core.config_manager import ConfigManager

class ProfilesPanel(QWidget):
    sig_profile_loaded = pyqtSignal(str)

    def __init__(self, config: ConfigManager, parent=None):
        super().__init__(parent)
        self.cfg = config
        self._build_ui()
        self._refresh_list()

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(20, 16, 20, 16)
        root.setSpacing(14)

        title = QLabel("Profile Manager")
        title.setStyleSheet(f"color: {COLORS['text_primary']}; font-size: 16px; font-weight: 700;")
        root.addWidget(title)

        desc = QLabel("Create profiles for different characters or configurations.")
        desc.setStyleSheet(f"color: {COLORS['text_secondary']}; font-size: 11px;")
        root.addWidget(desc)

        cur_frame = QFrame()
        cur_frame.setStyleSheet(f"""
            background: {COLORS['bg_elevated']};
            border: 1px solid {COLORS['accent']};
            border-radius: 8px;
        """)
        cf_lay = QHBoxLayout(cur_frame)
        cf_lay.setContentsMargins(14, 10, 14, 10)

        lbl = QLabel("Active profile :")
        lbl.setStyleSheet(f"color: {COLORS['text_secondary']}; font-size: 12px;")
        cf_lay.addWidget(lbl)

        self._active_label = QLabel(self.cfg.current_profile)
        self._active_label.setStyleSheet(f"""
            color: {COLORS['accent']};
            font-size: 13px;
            font-weight: 700;
        """)
        cf_lay.addWidget(self._active_label)
        cf_lay.addStretch()
        root.addWidget(cur_frame)

        card = SectionCard("AVAILABLE PROFILES")
        list_lay = card.content_layout()

        self._list = QListWidget()
        self._list.setStyleSheet(f"""
            QListWidget {{
                background: {COLORS['bg_base']};
                border: 1px solid {COLORS['bg_border']};
                border-radius: 6px;
                padding: 4px;
            }}
            QListWidget::item {{
                color: {COLORS['text_primary']};
                padding: 8px 12px;
                border-radius: 4px;
            }}
            QListWidget::item:hover {{ background: {COLORS['bg_hover']}; }}
            QListWidget::item:selected {{
                background: {COLORS['bg_active']};
                color: {COLORS['text_primary']};
            }}
        """)
        self._list.setMinimumHeight(200)
        self._list.itemDoubleClicked.connect(self._load_selected)
        list_lay.addWidget(self._list)
        root.addWidget(card)

        btn_row1 = QHBoxLayout()
        btn_row1.setSpacing(8)
        self._btn_load  = GlowButton("✓  Load",      "success")
        self._btn_new   = GlowButton("＋  New",       "primary")
        self._btn_clone = GlowButton("⊕  Duplicate", "neutral")
        self._btn_load.clicked.connect(self._load_selected)
        self._btn_new.clicked.connect(self._new_profile)
        self._btn_clone.clicked.connect(self._clone_profile)
        btn_row1.addWidget(self._btn_load)
        btn_row1.addWidget(self._btn_new)
        btn_row1.addWidget(self._btn_clone)
        root.addLayout(btn_row1)

        btn_row2 = QHBoxLayout()
        btn_row2.setSpacing(8)
        self._btn_rename = GlowButton("✎  Rename", "neutral")
        self._btn_delete = GlowButton("🗑  Delete", "danger")
        self._btn_rename.clicked.connect(self._rename_profile)
        self._btn_delete.clicked.connect(self._delete_profile)
        btn_row2.addWidget(self._btn_rename)
        btn_row2.addWidget(self._btn_delete)
        root.addLayout(btn_row2)
        root.addStretch()

    def _refresh_list(self):
        self._list.clear()
        for name in self.cfg.list_profiles():
            item = QListWidgetItem(name)
            if name == self.cfg.current_profile:
                item.setForeground(Qt.GlobalColor.white)
                item.setText(f"★  {name}")
            self._list.addItem(item)

    def _selected_name(self) -> str | None:
        items = self._list.selectedItems()
        if not items:
            return None
        return items[0].text().replace("★  ", "")

    def _load_selected(self):
        name = self._selected_name()
        if not name:
            return
        self.cfg.load_profile(name)
        self._active_label.setText(name)
        self._refresh_list()
        self.sig_profile_loaded.emit(name)

    def _new_profile(self):
        name, ok = QInputDialog.getText(self, "New Profile", "Profile name:")
        if ok and name.strip():
            from core.config_manager import DEFAULT_CONFIG
            import copy
            self.cfg._current_profile = name.strip()
            self.cfg._data = copy.deepcopy(DEFAULT_CONFIG)
            self.cfg.save_profile()
            self._refresh_list()

    def _clone_profile(self):
        name = self._selected_name()
        if not name:
            return
        new_name, ok = QInputDialog.getText(self, "Duplicate Profile",
                                             f"Name for the copy of '{name}':")
        if ok and new_name.strip():
            self.cfg.clone_profile(name, new_name.strip())
            self._refresh_list()

    def _rename_profile(self):
        name = self._selected_name()
        if not name:
            return
        new_name, ok = QInputDialog.getText(self, "Rename Profile",
                                             f"New name for '{name}':")
        if ok and new_name.strip():
            self.cfg.rename_profile(name, new_name.strip())
            self._active_label.setText(self.cfg.current_profile)
            self._refresh_list()

    def _delete_profile(self):
        name = self._selected_name()
        if not name:
            return
        if name == "Default":
            QMessageBox.warning(self, "Delete Profile",
                                "The 'Default' profile cannot be deleted.")
            return
        reply = QMessageBox.question(
            self, "Delete Profile",
            f"Permanently delete profile '{name}'?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if reply == QMessageBox.StandardButton.Yes:
            self.cfg.delete_profile(name)
            self._active_label.setText(self.cfg.current_profile)
            self._refresh_list()
