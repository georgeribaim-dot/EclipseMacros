"""Food panel — FAT macro with Burger / Sushi / Protein Drain profiles."""

import os
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame, QScrollArea,
    QPushButton, QLineEdit, QComboBox,
)
from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QPixmap, QIntValidator, QDoubleValidator

from .theme import COLORS
from .widgets import AnimatedToggle
from core.config_manager import ConfigManager


def _food_pixmap(size: int) -> QPixmap:
    assets = os.path.join(os.path.dirname(os.path.dirname(__file__)), "assets")
    path = os.path.join(assets, "food_logo.png")
    if os.path.isfile(path):
        pm = QPixmap(path)
        return pm.scaled(size, size,
                         Qt.AspectRatioMode.KeepAspectRatio,
                         Qt.TransformationMode.SmoothTransformation)
    pm = QPixmap(size, size); pm.fill(Qt.GlobalColor.transparent)
    return pm

def _sec(txt):
    l = QLabel(txt)
    l.setStyleSheet(f"color:{COLORS['accent_gold']};font-size:10px;font-weight:700;letter-spacing:2px;padding-bottom:4px;")
    return l

def _fld(txt):
    l = QLabel(txt)
    l.setStyleSheet(f"color:{COLORS['text_secondary']};font-size:11px;")
    return l

def _dim(txt):
    l = QLabel(txt)
    l.setStyleSheet(f"color:{COLORS['text_dim']};font-size:10px;")
    return l

def _le(ph="", int_only=False, float_only=False, w=None):
    e = QLineEdit()
    e.setPlaceholderText(ph)
    if int_only:
        e.setValidator(QIntValidator(0, 99999))
    elif float_only:
        v = QDoubleValidator(0.0, 9999.0, 3)
        e.setValidator(v)
    e.setFixedHeight(28)
    if w: e.setFixedWidth(w)
    e.setStyleSheet(f"""
        QLineEdit{{background:{COLORS['bg_elevated']};
        border:1px solid {COLORS['bg_border']};border-radius:6px;
        color:{COLORS['text_primary']};font-size:12px;padding:0 8px;}}
        QLineEdit:focus{{border:1px solid {COLORS['accent']};}}
    """)
    return e

def _card():
    f = QFrame()
    f.setStyleSheet(f"QFrame{{background:{COLORS['bg_elevated']};border:1px solid {COLORS['bg_border']};border-radius:10px;}}")
    return f

def _sep():
    s = QFrame(); s.setFrameShape(QFrame.Shape.HLine)
    s.setStyleSheet(f"color:{COLORS['bg_border']};margin:2px 0;")
    return s

def _detect_btn(text):
    btn = QPushButton(text)
    btn.setFixedHeight(32)
    btn.setStyleSheet(
        f"QPushButton{{background:{COLORS['bg_base']};color:{COLORS['text_secondary']};"
        f"border:1px solid {COLORS['bg_border']};border-radius:6px;font-size:11px;font-weight:600;}}"
        f"QPushButton:hover{{border-color:{COLORS['accent']};color:{COLORS['text_primary']};}}"
    )
    return btn

PROFILES = ["Burger", "Sushi", "Protein Drain"]
# Config key prefix per profile
_PFX = {"Burger": "FAT_BG_", "Sushi": "FAT_SU_", "Protein Drain": "FAT_PD_"}

# Common param keys per profile (suffix after prefix)
_COMMON_KEYS = [
    ("FoodKey",        "Food key",              "e",    False),
    ("RClickDuration", "Right-click spam (ms)", "500",  True),
    ("LClickDuration", "Left-click spam (ms)",  "1500", True),
]


class FoodPanel(QWidget):
    sig_j_toggle_changed = pyqtSignal(bool)
    sig_select_fat       = pyqtSignal()   # selects FAT macro (F1 activates it)
    sig_saved            = pyqtSignal()

    def __init__(self, cfg: ConfigManager, parent=None):
        super().__init__(parent)
        self.cfg = cfg
        self._cycle_count = 0
        self._fat_running = False
        self._fields: dict = {}          # keyed by config key
        self._fast_eating_toggles: dict  = {}  # keyed by profile
        self._fast_eat_frames: dict      = {}  # profile → QFrame (hidden/shown)
        self._build_ui()
        self._load_values()

    # ── Build ─────────────────────────────────────────────────────────────────

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(20, 16, 20, 16)
        root.setSpacing(14)

        # Header
        tr = QHBoxLayout(); tr.setSpacing(12)
        ll = QLabel(); ll.setPixmap(_food_pixmap(44)); ll.setFixedSize(44, 44)
        tr.addWidget(ll)
        col = QVBoxLayout(); col.setSpacing(2)
        t = QLabel("Food — FAT Macro")
        t.setStyleSheet(f"color:{COLORS['text_primary']};font-size:16px;font-weight:700;")
        col.addWidget(t)
        sub = QLabel("Profile-based food automation — right-click + left-click spam")
        sub.setStyleSheet(f"color:{COLORS['text_secondary']};font-size:11px;")
        col.addWidget(sub)
        tr.addLayout(col); tr.addStretch()

        # Cycle counter
        cf = QFrame()
        cf.setStyleSheet(f"QFrame{{background:{COLORS['bg_elevated']};border:1px solid {COLORS['neon_border']};border-radius:8px;}}")
        cl = QVBoxLayout(cf); cl.setContentsMargins(14, 8, 14, 8); cl.setSpacing(2)
        ct = QLabel("FOOD CYCLES")
        ct.setStyleSheet(f"color:{COLORS['text_dim']};font-size:8px;font-weight:700;letter-spacing:2px;")
        cl.addWidget(ct)
        self._lbl_cycle = QLabel("0")
        self._lbl_cycle.setStyleSheet(f"color:{COLORS['accent_glow']};font-size:22px;font-weight:700;font-family:'Cascadia Code','Consolas',monospace;")
        cl.addWidget(self._lbl_cycle)
        tr.addWidget(cf)
        root.addLayout(tr)

        # Select macro button (like other macro panels)
        self._btn_select = QPushButton("🍔  Select FAT Macro  (F1 Start  ·  F3 Stop)")
        self._btn_select.setFixedHeight(42)
        self._btn_select.setStyleSheet(self._select_style(False))
        self._btn_select.clicked.connect(self._on_select)
        root.addWidget(self._btn_select)

        # Scroll area
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setStyleSheet("background:transparent;")
        inner = QWidget(); inner.setStyleSheet("background:transparent;")
        il = QVBoxLayout(inner); il.setContentsMargins(0, 0, 8, 0); il.setSpacing(16)

        # J-key calibration card
        il.addWidget(self._build_j_card())
        # Profile card
        il.addWidget(self._build_profiles_card())

        il.addStretch()

        scroll.setWidget(inner)
        root.addWidget(scroll)

    def _build_j_card(self) -> QFrame:
        card = _card()
        lay = QVBoxLayout(card); lay.setContentsMargins(18, 14, 18, 14); lay.setSpacing(10)
        lay.addWidget(_sec("J KEY — FOOD CLICK CALIBRATION"))

        row = QHBoxLayout(); row.setSpacing(8)
        lbl = QLabel("Enable J Key")
        lbl.setStyleSheet(f"color:{COLORS['text_primary']};font-size:11px;")
        row.addWidget(lbl)
        self._j_toggle = AnimatedToggle(checked=True)
        row.addWidget(self._j_toggle)
        row.addStretch()
        lay.addLayout(row)
        self._j_toggle.toggled.connect(self.sig_j_toggle_changed.emit)

        hint = QLabel("When enabled: press J to show/hide the red calibration point. Drag it to set the food click position.")
        hint.setStyleSheet(f"color:{COLORS['text_dim']};font-size:10px;")
        hint.setWordWrap(True)
        lay.addWidget(hint)

        lay.addWidget(_sep())

        coord_row = QHBoxLayout(); coord_row.setSpacing(8)
        coord_row.addWidget(_fld("Food click position"))
        coord_row.addStretch()
        le_x = _le("960", int_only=True, w=70)
        le_y = _le("540", int_only=True, w=70)
        coord_row.addWidget(_dim("X")); coord_row.addWidget(le_x)
        coord_row.addWidget(_dim("Y")); coord_row.addWidget(le_y)
        lay.addLayout(coord_row)
        self._fields["FAT_ClickX"] = le_x
        self._fields["FAT_ClickY"] = le_y
        return card

    def _build_profiles_card(self) -> QFrame:
        card = _card()
        lay = QVBoxLayout(card); lay.setContentsMargins(18, 14, 18, 14); lay.setSpacing(10)
        lay.addWidget(_sec("FAT MACRO PROFILE"))

        # Profile dropdown
        combo_row = QHBoxLayout(); combo_row.setSpacing(8)
        combo_row.addWidget(_fld("Profile"))
        self._profile_combo = QComboBox()
        for p in PROFILES:
            self._profile_combo.addItem(p)
        self._profile_combo.setFixedHeight(30)
        self._profile_combo.setFixedWidth(160)
        self._profile_combo.setStyleSheet(f"""
            QComboBox{{background:{COLORS['bg_base']};border:1px solid {COLORS['bg_border']};
            border-radius:6px;color:{COLORS['text_primary']};font-size:12px;padding:0 8px;}}
            QComboBox:focus{{border:1px solid {COLORS['accent']};}}
            QComboBox::drop-down{{border:none;}}
            QComboBox QAbstractItemView{{background:{COLORS['bg_elevated']};
            color:{COLORS['text_primary']};selection-background-color:{COLORS['accent']};}}
        """)
        self._profile_combo.currentTextChanged.connect(self._on_profile_changed)
        combo_row.addWidget(self._profile_combo)
        combo_row.addStretch()
        lay.addLayout(combo_row)

        lay.addWidget(_sep())

        # Build per-profile sections
        self._profile_pages: dict = {}  # profile → QFrame
        for profile in PROFILES:
            page = self._build_profile_page(profile)
            lay.addWidget(page)
            self._profile_pages[profile] = page

        self._show_profile(PROFILES[0])
        return card

    def _build_profile_page(self, profile: str) -> QFrame:
        pfx = _PFX[profile]
        frame = QFrame()
        frame.setStyleSheet("QFrame{background:transparent;border:none;}")
        lay = QVBoxLayout(frame); lay.setContentsMargins(0, 4, 0, 4); lay.setSpacing(8)

        # Food key
        fkey_row = QHBoxLayout(); fkey_row.setSpacing(8)
        fkey_row.addWidget(_fld("Food key"))
        le_fk = _le("e", w=60)
        self._fields[pfx + "FoodKey"] = le_fk
        fkey_row.addWidget(le_fk); fkey_row.addStretch()
        lay.addLayout(fkey_row)

        # Right-click spam duration
        rc_row = QHBoxLayout(); rc_row.setSpacing(8)
        rc_row.addWidget(_fld("Right-click spam (ms)"))
        le_rc = _le("500", int_only=True, w=70)
        self._fields[pfx + "RClickDuration"] = le_rc
        rc_row.addWidget(le_rc); rc_row.addStretch()
        lay.addLayout(rc_row)

        # Left-click spam duration
        lc_row = QHBoxLayout(); lc_row.setSpacing(8)
        lc_row.addWidget(_fld("Left-click spam (ms)"))
        le_lc = _le("1500", int_only=True, w=70)
        self._fields[pfx + "LClickDuration"] = le_lc
        lc_row.addWidget(le_lc); lc_row.addStretch()
        lay.addLayout(lc_row)

        # Cycle delay
        cd_row = QHBoxLayout(); cd_row.setSpacing(8)
        cd_row.addWidget(_fld("Pause fin de cycle (ms)"))
        le_cd = _le("500", int_only=True, w=70)
        self._fields[pfx + "CycleDelay"] = le_cd
        cd_row.addWidget(le_cd); cd_row.addStretch()
        lay.addLayout(cd_row)

        # Burger-only: Fast Eating section
        if profile == "Burger":
            lay.addWidget(_sep())
            fe_row = QHBoxLayout(); fe_row.setSpacing(8)
            fe_lbl = QLabel("Fast Eating")
            fe_lbl.setStyleSheet(f"color:{COLORS['text_primary']};font-size:11px;font-weight:600;")
            fe_row.addWidget(fe_lbl)
            fe_toggle = AnimatedToggle(checked=False)
            fe_row.addWidget(fe_toggle)
            fe_row.addStretch()
            lay.addLayout(fe_row)
            self._fast_eating_toggles[profile] = fe_toggle

            fe_frame = QFrame()
            fe_frame.setStyleSheet("QFrame{background:transparent;border:none;}")
            fe_frame.setVisible(False)
            fe_lay = QVBoxLayout(fe_frame); fe_lay.setContentsMargins(0, 4, 0, 0); fe_lay.setSpacing(6)

            # Alternate key
            ak_row = QHBoxLayout(); ak_row.setSpacing(8)
            ak_row.addWidget(_fld("Alternate key"))
            le_ak = _le("r", w=60)
            self._fields[pfx + "AltKey"] = le_ak
            ak_row.addWidget(le_ak); ak_row.addStretch()
            fe_lay.addLayout(ak_row)

            # Alternate duration
            ad_row = QHBoxLayout(); ad_row.setSpacing(8)
            ad_row.addWidget(_fld("Alternate duration (ms)"))
            le_ad = _le("2000", int_only=True, w=70)
            self._fields[pfx + "AltDuration"] = le_ad
            ad_row.addWidget(le_ad); ad_row.addStretch()
            fe_lay.addLayout(ad_row)

            lay.addWidget(fe_frame)
            self._fast_eat_frames[profile] = fe_frame
            fe_toggle.toggled.connect(fe_frame.setVisible)

        return frame

    # ── Slots ─────────────────────────────────────────────────────────────────

    def _on_profile_changed(self, profile: str):
        self._show_profile(profile)

    def _show_profile(self, profile: str):
        for p, page in self._profile_pages.items():
            page.setVisible(p == profile)

    def _on_select(self):
        if not self._fat_running:
            self.save_to_config()          # persist params before signalling
            self.sig_select_fat.emit()

    @staticmethod
    def _select_style(active: bool) -> str:
        if active:
            return (
                "QPushButton{background:#1a3a1a;color:#4CAF50;"
                "border:2px solid #4CAF50;border-radius:8px;"
                "font-size:13px;font-weight:700;}"
                "QPushButton:hover{background:#1e461e;}"
            )
        return (
            f"QPushButton{{background:{COLORS['bg_elevated']};"
            f"color:{COLORS['text_primary']};"
            f"border:1px solid {COLORS['bg_border']};"
            f"border-radius:8px;font-size:13px;}}"
            f"QPushButton:hover{{border-color:{COLORS.get('accent','#888')};}}"
        )

    # ── Public API ────────────────────────────────────────────────────────────

    def set_fat_running(self, running: bool):
        self._fat_running = running

    def set_active(self, active: bool):
        self._fat_running = active
        if active:
            self._btn_select.setText("✅  FAT Macro — ACTIVE  (F1 Start  ·  F3 Stop)")
        else:
            self._btn_select.setText("🍔  Select FAT Macro  (F1 Start  ·  F3 Stop)")
        self._btn_select.setStyleSheet(self._select_style(active))

    def increment_cycle(self):
        self._cycle_count += 1
        self._lbl_cycle.setText(str(self._cycle_count))

    def reset_cycles(self):
        self._cycle_count = 0
        self._lbl_cycle.setText("0")

    def refresh_from_config(self):
        self._load_values()

    def update_click_pos(self, x: int, y: int):
        """Called when J-point is dragged."""
        if "FAT_ClickX" in self._fields:
            self._fields["FAT_ClickX"].setText(str(x))
        if "FAT_ClickY" in self._fields:
            self._fields["FAT_ClickY"].setText(str(y))

    def get_j_enabled(self) -> bool:
        return self._j_toggle.isChecked()

    # ── Load / Save ───────────────────────────────────────────────────────────

    def _load_values(self):
        c = self.cfg
        for key, le in self._fields.items():
            val = c.get(key)
            if val is not None:
                le.setText(str(val))

        # Profile combo
        saved_profile = c.get("FAT_Profile", "Burger")
        idx = self._profile_combo.findText(saved_profile)
        if idx >= 0:
            self._profile_combo.setCurrentIndex(idx)

        # Fast eating toggles
        for profile, toggle in self._fast_eating_toggles.items():
            pfx = _PFX[profile]
            val = int(c.get(pfx + "FastEating", 0))
            toggle.setChecked(bool(val))

        # J toggle
        j_en = int(c.get("FAT_JEnabled", 1))
        self._j_toggle.setChecked(bool(j_en))

    def save_to_config(self):
        c = self.cfg
        for key, le in self._fields.items():
            txt = le.text().strip()
            if txt:
                c.set(key, txt)
        c.set("FAT_Profile", self._profile_combo.currentText())
        c.set("FAT_JEnabled", 1 if self._j_toggle.isChecked() else 0)
        for profile, toggle in self._fast_eating_toggles.items():
            pfx = _PFX[profile]
            c.set(pfx + "FastEating", 1 if toggle.isChecked() else 0)
        c.save_profile()
        self.sig_saved.emit()
