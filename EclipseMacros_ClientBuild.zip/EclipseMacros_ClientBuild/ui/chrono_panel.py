
import time
import threading
import ctypes
import ctypes.wintypes
import os
import math

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame,
    QPushButton, QLineEdit, QScrollArea, QDialog,
    QSpinBox, QMessageBox,
)
from PyQt6.QtCore import Qt, QTimer, pyqtSignal, QObject
from PyQt6.QtGui import QFont, QIntValidator, QPixmap

from .theme import COLORS

def _win_notify(title: str, message: str):
    try:
        ctypes.windll.user32.MessageBeep(0x00000030)
        def _show():
            try:
                import subprocess
                ps_cmd = (
                    f'[Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType=WindowsRuntime] | Out-Null; '
                    f'$template = [Windows.UI.Notifications.ToastNotificationManager]::GetTemplateContent([Windows.UI.Notifications.ToastTemplateType]::ToastText02); '
                    f'$textNodes = $template.GetElementsByTagName("text"); '
                    f'$textNodes.Item(0).AppendChild($template.CreateTextNode("{title}")) | Out-Null; '
                    f'$textNodes.Item(1).AppendChild($template.CreateTextNode("{message}")) | Out-Null; '
                    f'$toast = [Windows.UI.Notifications.ToastNotification]::new($template); '
                    f'[Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier("Eclipse Macro").Show($toast);'
                )
                subprocess.Popen(
                    ["powershell", "-WindowStyle", "Hidden", "-Command", ps_cmd],
                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                    creationflags=0x08000000  # CREATE_NO_WINDOW
                )
            except Exception:
                try:
                    ctypes.windll.user32.MessageBoxW(0, message, title, 0x40 | 0x1000)
                except Exception:
                    pass
        threading.Thread(target=_show, daemon=True).start()
    except Exception:
        pass

def _beep(freq: int = 880, duration_ms: int = 400):
    try:
        ctypes.windll.kernel32.Beep(freq, duration_ms)
    except Exception:
        pass

def _sec(txt):
    l = QLabel(txt)
    l.setStyleSheet(
        f"color:{COLORS['accent_gold']};font-size:10px;"
        f"font-weight:700;letter-spacing:2px;padding-bottom:4px;"
    )
    return l

def _card_frame():
    f = QFrame()
    f.setStyleSheet(
        f"QFrame{{background:{COLORS['bg_elevated']};"
        f"border:1px solid {COLORS['bg_border']};border-radius:10px;}}"
    )
    return f

def _btn(text, color=None, min_w=None):
    b = QPushButton(text)
    b.setFixedHeight(32)
    if min_w:
        b.setMinimumWidth(min_w)
    bg = color or COLORS['bg_base']
    b.setStyleSheet(
        f"QPushButton{{background:{bg};"
        f"color:{COLORS['text_primary']};border:1px solid {COLORS['bg_border']};"
        f"border-radius:6px;font-size:12px;font-weight:600;padding:0 12px;}}"
        f"QPushButton:hover{{border-color:{COLORS['accent']};color:{COLORS['text_primary']};}}"
        f"QPushButton:disabled{{color:{COLORS['text_dim']};border-color:{COLORS['bg_border']};}}"
    )
    return b

class _TimerState:
    IDLE    = "idle"
    RUNNING = "running"
    PAUSED  = "paused"
    DONE    = "done"

    def __init__(self, name: str, total_seconds: int):
        self.name           = name
        self.total_seconds  = total_seconds
        self.remaining      = total_seconds
        self.state          = self.IDLE
        self._lock          = threading.Lock()
        self._last_tick     = 0.0

    def start(self):
        with self._lock:
            if self.state == self.IDLE or self.state == self.DONE:
                self.remaining = self.total_seconds
            self.state = self.RUNNING
            self._last_tick = time.monotonic()

    def pause(self):
        with self._lock:
            if self.state == self.RUNNING:
                elapsed = time.monotonic() - self._last_tick
                self.remaining = max(0, self.remaining - elapsed)
                self.state = self.PAUSED

    def resume(self):
        with self._lock:
            if self.state == self.PAUSED:
                self.state = self.RUNNING
                self._last_tick = time.monotonic()

    def stop(self):
        with self._lock:
            self.state = self.IDLE
            self.remaining = self.total_seconds

    def tick(self) -> bool:
        with self._lock:
            if self.state != self.RUNNING:
                return False
            now = time.monotonic()
            elapsed = now - self._last_tick
            self._last_tick = now
            self.remaining = max(0.0, self.remaining - elapsed)
            if self.remaining <= 0:
                self.state = self.DONE
                return True
            return False

    def display(self) -> str:
        with self._lock:
            r = int(self.remaining)
        h = r // 3600
        m = (r % 3600) // 60
        s = r % 60
        return f"{h:02d}:{m:02d}:{s:02d}"

class TimerCard(QFrame):
    sig_finished = pyqtSignal(str)   # timer name
    sig_deleted  = pyqtSignal(object)  # self

    def __init__(self, name: str, total_seconds: int, deletable: bool = True, parent=None):
        super().__init__(parent)
        self._state = _TimerState(name, total_seconds)
        self._deletable = deletable
        self._build_ui()
        self._setup_tick()

    def _build_ui(self):
        self.setStyleSheet(
            f"QFrame{{background:{COLORS['bg_elevated']};"
            f"border:1px solid {COLORS['bg_border']};border-radius:10px;}}"
        )
        lay = QVBoxLayout(self)
        lay.setContentsMargins(14, 12, 14, 12)
        lay.setSpacing(8)

        hr = QHBoxLayout(); hr.setSpacing(8)
        self._lbl_name = QLabel(self._state.name)
        self._lbl_name.setStyleSheet(
            f"color:{COLORS['text_primary']};font-size:13px;font-weight:700;"
        )
        hr.addWidget(self._lbl_name)
        hr.addStretch()

        total = self._state.total_seconds
        h = total // 3600; m = (total % 3600) // 60
        dur_txt = f"{h}h" if m == 0 else f"{h}h{m:02d}m" if h else f"{m}m"
        self._lbl_dur = QLabel(dur_txt)
        self._lbl_dur.setStyleSheet(
            f"color:{COLORS['text_dim']};font-size:10px;"
        )
        hr.addWidget(self._lbl_dur)

        if self._deletable:
            btn_del = QPushButton("✕")
            btn_del.setFixedSize(22, 22)
            btn_del.setStyleSheet(
                f"QPushButton{{background:transparent;color:{COLORS['text_dim']};"
                f"border:none;font-size:12px;border-radius:4px;}}"
                f"QPushButton:hover{{color:#FF5555;background:{COLORS['bg_base']};}}"
            )
            btn_del.clicked.connect(lambda: self.sig_deleted.emit(self))
            hr.addWidget(btn_del)
        lay.addLayout(hr)

        self._lbl_time = QLabel("00:00:00")
        self._lbl_time.setAlignment(Qt.AlignmentFlag.AlignCenter)
        font = QFont("Consolas", 28, QFont.Weight.Bold)
        self._lbl_time.setFont(font)
        self._lbl_time.setStyleSheet(f"color:{COLORS['text_primary']};")
        lay.addWidget(self._lbl_time)

        self._lbl_status = QLabel()
        self._lbl_status.setText("Waiting")
        self._lbl_status.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._lbl_status.setStyleSheet(f"color:{COLORS['text_dim']};font-size:10px;")
        lay.addWidget(self._lbl_status)

        br = QHBoxLayout(); br.setSpacing(8)
        self._btn_play  = _btn("▶  Start", min_w=110)
        self._btn_pause = _btn("⏸  Pause",    min_w=90)
        self._btn_stop  = _btn("⏹  Stop",     min_w=80)
        self._btn_pause.setEnabled(False)
        self._btn_stop.setEnabled(False)
        self._btn_play.clicked.connect(self._on_play)
        self._btn_pause.clicked.connect(self._on_pause)
        self._btn_stop.clicked.connect(self._on_stop)
        br.addWidget(self._btn_play)
        br.addWidget(self._btn_pause)
        br.addWidget(self._btn_stop)
        br.addStretch()
        lay.addLayout(br)

    def _setup_tick(self):
        self._tick_timer = QTimer(self)
        self._tick_timer.setInterval(500)
        self._tick_timer.timeout.connect(self._on_tick)
        self._tick_timer.start()

    def _on_tick(self):
        state = self._state
        finished = state.tick()
        self._lbl_time.setText(state.display())
        if finished:
            self._set_done()
            self.sig_finished.emit(state.name)
            threading.Thread(
                target=lambda: (_beep(880, 300), time.sleep(0.35), _beep(1100, 400),
                                _win_notify("⏰ Eclipse Macro",
                                            f"Timer \"{state.name}\" finished!")),
                daemon=True
            ).start()
        else:
            self._refresh_buttons()

    def _on_play(self):
        s = self._state.state
        if s == _TimerState.IDLE or s == _TimerState.DONE:
            self._state.start()
            self._lbl_time.setText(self._state.display())
        elif s == _TimerState.PAUSED:
            self._state.resume()
        self._refresh_buttons()

    def _on_pause(self):
        s = self._state.state
        if s == _TimerState.RUNNING:
            self._state.pause()
        elif s == _TimerState.PAUSED:
            self._state.resume()
        self._refresh_buttons()

    def _on_stop(self):
        self._state.stop()
        self._lbl_time.setText("00:00:00")
        self._lbl_status.setText("Waiting")
        self._lbl_status.setStyleSheet(f"color:{COLORS['text_dim']};font-size:10px;")
        self._lbl_time.setStyleSheet(f"color:{COLORS['text_primary']};")
        self.setStyleSheet(
            f"QFrame{{background:{COLORS['bg_elevated']};"
            f"border:1px solid {COLORS['bg_border']};border-radius:10px;}}"
        )
        self._refresh_buttons()

    def _set_done(self):
        self._lbl_status.setText("✅ Done!")
        self._lbl_status.setStyleSheet("color:#50FA7B;font-size:11px;font-weight:700;")
        self._lbl_time.setStyleSheet("color:#50FA7B;")
        self.setStyleSheet(
            f"QFrame{{background:#1A2D1A;"
            f"border:2px solid #50FA7B;border-radius:10px;}}"
        )
        self._btn_play.setEnabled(True)
        self._btn_pause.setEnabled(False)
        self._btn_stop.setEnabled(True)
        self._btn_play.setText("🔄  Restart")

    def _refresh_buttons(self):
        s = self._state.state
        if s == _TimerState.IDLE:
            self._btn_play.setText("▶  Start")
            self._btn_play.setEnabled(True)
            self._btn_pause.setEnabled(False)
            self._btn_stop.setEnabled(False)
            self._lbl_status.setText("En attente")
            self._lbl_status.setStyleSheet(f"color:{COLORS['text_dim']};font-size:10px;")
        elif s == _TimerState.RUNNING:
            self._btn_play.setText("▶  Start")
            self._btn_play.setEnabled(False)
            self._btn_pause.setText("⏸  Pause")
            self._btn_pause.setEnabled(True)
            self._btn_stop.setEnabled(True)
            self._lbl_status.setText("⏱ Running...")
            self._lbl_status.setStyleSheet(f"color:{COLORS['accent']};font-size:10px;")
        elif s == _TimerState.PAUSED:
            self._btn_play.setText("▶  Resume")
            self._btn_play.setEnabled(True)
            self._btn_pause.setText("⏸  Pause")
            self._btn_pause.setEnabled(False)
            self._btn_stop.setEnabled(True)
            self._lbl_status.setText("⏸ Paused")
            self._lbl_status.setStyleSheet("color:#FFB86C;font-size:10px;")
        elif s == _TimerState.DONE:
            pass  # handled by _set_done

class NewTimerDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("New Timer")
        self.setFixedSize(340, 200)
        self.setStyleSheet(f"background:{COLORS['bg_base']};color:{COLORS['text_primary']};")
        self._name = ""
        self._seconds = 0
        self._build_ui()

    def _build_ui(self):
        lay = QVBoxLayout(self)
        lay.setSpacing(14)
        lay.setContentsMargins(20, 20, 20, 20)

        lay.addWidget(QLabel("Timer name:"))
        self._le_name = QLineEdit()
        self._le_name.setPlaceholderText("ex: World Boss")
        self._le_name.setFixedHeight(32)
        self._le_name.setStyleSheet(
            f"background:{COLORS['bg_elevated']};border:1px solid {COLORS['bg_border']};"
            f"border-radius:6px;color:{COLORS['text_primary']};padding:0 8px;"
        )
        lay.addWidget(self._le_name)

        time_row = QHBoxLayout(); time_row.setSpacing(10)
        time_row.addWidget(QLabel("Duration:"))
        self._sb_h = QSpinBox(); self._sb_h.setRange(0, 23); self._sb_h.setSuffix(" h")
        self._sb_m = QSpinBox(); self._sb_m.setRange(0, 59); self._sb_m.setSuffix(" min")
        self._sb_s = QSpinBox(); self._sb_s.setRange(0, 59); self._sb_s.setSuffix(" sec")
        self._sb_m.setValue(30)
        for sb in (self._sb_h, self._sb_m, self._sb_s):
            sb.setFixedHeight(32)
            sb.setStyleSheet(
                f"QSpinBox{{background:{COLORS['bg_elevated']};border:1px solid {COLORS['bg_border']};"
                f"border-radius:6px;color:{COLORS['text_primary']};padding:0 4px;}}"
                f"QSpinBox::up-button,QSpinBox::down-button{{width:16px;}}"
            )
            time_row.addWidget(sb)
        lay.addLayout(time_row)

        btn_row = QHBoxLayout(); btn_row.addStretch()
        btn_ok = _btn("✅  Create", min_w=90)
        btn_cancel = _btn("Annuler", min_w=80)
        btn_ok.clicked.connect(self._on_ok)
        btn_cancel.clicked.connect(self.reject)
        btn_row.addWidget(btn_cancel)
        btn_row.addWidget(btn_ok)
        lay.addLayout(btn_row)

    def _on_ok(self):
        name = self._le_name.text().strip()
        secs = self._sb_h.value() * 3600 + self._sb_m.value() * 60 + self._sb_s.value()
        if not name:
            self._le_name.setFocus(); return
        if secs <= 0:
            self._sb_m.setFocus(); return
        self._name = name
        self._seconds = secs
        self.accept()

    def result_data(self):
        return self._name, self._seconds

DEFAULT_TIMERS = [
    ("Bosses",       3600),
    ("Super Bosses", 3600),
    ("Raids",        7200),
]

class ChronoPanel(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._cards: list[TimerCard] = []
        self._build_ui()
        self._add_defaults()

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(20, 16, 20, 16)
        root.setSpacing(14)

        hr = QHBoxLayout(); hr.setSpacing(12)
        ico = QLabel()
        _assets = os.path.join(os.path.dirname(os.path.dirname(__file__)), "assets")
        _logo_path = os.path.join(_assets, "timer_logo.png")
        if os.path.isfile(_logo_path):
            _pm = QPixmap(_logo_path).scaled(
                44, 44,
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation
            )
            ico.setPixmap(_pm)
        else:
            ico.setText("⏱")
            ico.setStyleSheet("font-size:32px;")
        ico.setFixedSize(44, 44)
        hr.addWidget(ico)
        col = QVBoxLayout(); col.setSpacing(2)
        t = QLabel("Timers")
        t.setStyleSheet(f"color:{COLORS['text_primary']};font-size:16px;font-weight:700;")
        col.addWidget(t)
        sub = QLabel("Timers for Bosses, Raids and Events — Windows notification on completion")
        sub.setStyleSheet(f"color:{COLORS['text_secondary']};font-size:11px;")
        col.addWidget(sub)
        hr.addLayout(col); hr.addStretch()

        btn_new = _btn("➕  New Timer", min_w=180)
        btn_new.clicked.connect(self._on_new_timer)
        hr.addWidget(btn_new)
        root.addLayout(hr)

        sep = QFrame(); sep.setFrameShape(QFrame.Shape.HLine)
        sep.setStyleSheet(f"color:{COLORS['bg_border']};")
        root.addWidget(sep)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setStyleSheet("background:transparent;")
        self._inner = QWidget()
        self._inner.setStyleSheet("background:transparent;")
        self._inner_lay = QVBoxLayout(self._inner)
        self._inner_lay.setContentsMargins(0, 0, 8, 0)
        self._inner_lay.setSpacing(12)
        self._inner_lay.addStretch()
        scroll.setWidget(self._inner)
        root.addWidget(scroll)

    def _add_defaults(self):
        for name, secs in DEFAULT_TIMERS:
            self._create_card(name, secs, deletable=False)

    def _create_card(self, name: str, seconds: int, deletable: bool = True):
        card = TimerCard(name, seconds, deletable=deletable)
        card.sig_finished.connect(self._on_finished)
        card.sig_deleted.connect(self._on_delete)
        count = self._inner_lay.count()
        self._inner_lay.insertWidget(count - 1, card)
        self._cards.append(card)

    def _on_new_timer(self):
        dlg = NewTimerDialog(self)
        if dlg.exec():
            name, secs = dlg.result_data()
            self._create_card(name, secs, deletable=True)

    def _on_finished(self, name: str):
        pass

    def _on_delete(self, card: TimerCard):
        card.sig_finished.disconnect()
        card.sig_deleted.disconnect()
        self._inner_lay.removeWidget(card)
        card.deleteLater()
        if card in self._cards:
            self._cards.remove(card)
