
import html
from PyQt6.QtWidgets import (
    QWidget, QPushButton, QLabel, QFrame, QVBoxLayout,
    QHBoxLayout, QTextEdit, QSizePolicy, QGraphicsDropShadowEffect,
    QGraphicsOpacityEffect,
)
from PyQt6.QtCore import (
    Qt, QTimer, QPropertyAnimation, QEasingCurve,
    QRect, pyqtProperty, QPoint, pyqtSignal, QSize,
)
from PyQt6.QtGui import (
    QPainter, QColor, QFont, QPen, QBrush, QLinearGradient,
    QPainterPath, QFontMetrics, QRadialGradient,
)
from .theme import COLORS, action_btn_style, log_color

class AnimatedToggle(QWidget):
    toggled = pyqtSignal(bool)

    def __init__(self, parent=None, checked: bool = False):
        super().__init__(parent)
        self._checked = checked
        self._thumb_x = 4.0 if not checked else 26.0
        self._glow    = 0.0 if not checked else 1.0
        self.setFixedSize(54, 28)
        self.setCursor(Qt.CursorShape.PointingHandCursor)

        self._anim = QPropertyAnimation(self, b"thumb_x", self)
        self._anim.setDuration(200)
        self._anim.setEasingCurve(QEasingCurve.Type.InOutCubic)

        self._glow_anim = QPropertyAnimation(self, b"glow_val", self)
        self._glow_anim.setDuration(200)

    @pyqtProperty(float)
    def thumb_x(self):
        return self._thumb_x

    @thumb_x.setter
    def thumb_x(self, val):
        self._thumb_x = val
        self.update()

    @pyqtProperty(float)
    def glow_val(self):
        return self._glow

    @glow_val.setter
    def glow_val(self, val):
        self._glow = val
        self.update()

    def isChecked(self) -> bool:
        return self._checked

    def setChecked(self, val: bool):
        if val != self._checked:
            self._checked = val
            self._animate()

    def _animate(self):
        target_x    = 26.0 if self._checked else 4.0
        target_glow = 1.0  if self._checked else 0.0

        self._anim.setStartValue(self._thumb_x)
        self._anim.setEndValue(target_x)
        self._anim.start()

        self._glow_anim.setStartValue(self._glow)
        self._glow_anim.setEndValue(target_glow)
        self._glow_anim.start()

    def mousePressEvent(self, e):
        self._checked = not self._checked
        self._animate()
        self.toggled.emit(self._checked)

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)

        if self._checked:
            g = QLinearGradient(0, 0, 54, 0)
            g.setColorAt(0, QColor(80, 0, 140, int(200 + 55 * self._glow)))
            g.setColorAt(1, QColor(160, 40, 240, int(200 + 55 * self._glow)))
            p.setBrush(QBrush(g))
            pen_col = QColor(180, 60, 255, int(100 + 155 * self._glow))
        else:
            p.setBrush(QBrush(QColor(15, 12, 30)))
            pen_col = QColor(40, 30, 80)

        p.setPen(QPen(pen_col, 1))
        p.drawRoundedRect(1, 4, 52, 20, 10, 10)

        if self._glow > 0.05:
            gx = int(self._thumb_x) + 9
            rg = QRadialGradient(gx, 14, 12)
            rg.setColorAt(0, QColor(180, 60, 255, int(120 * self._glow)))
            rg.setColorAt(1, QColor(180, 60, 255, 0))
            p.setBrush(QBrush(rg))
            p.setPen(Qt.PenStyle.NoPen)
            p.drawEllipse(gx - 12, 2, 24, 24)

        p.setPen(Qt.PenStyle.NoPen)
        if self._checked:
            p.setBrush(QBrush(QColor(220, 180, 255)))
        else:
            p.setBrush(QBrush(QColor(80, 70, 110)))
        p.drawEllipse(int(self._thumb_x), 6, 20, 16)
        p.end()

class StatusIndicator(QWidget):
    _STATE_COLORS = {
        "idle":    ("#302858", "#181030"),
        "running": ("#40D080", "#1A5030"),
        "paused":  ("#E0A030", "#503810"),
        "stopped": ("#E04060", "#501020"),
    }

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(14, 14)
        self._state    = "idle"
        self._pulse    = 0.0
        self._pulse_dir = 1.0
        self._timer    = QTimer(self)
        self._timer.timeout.connect(self._tick)
        self._timer.start(40)

    def set_state(self, state: str):
        self._state = state
        self.update()

    def _tick(self):
        if self._state == "running":
            self._pulse += 0.06 * self._pulse_dir
            if self._pulse >= 1.0:
                self._pulse = 1.0
                self._pulse_dir = -1.0
            elif self._pulse <= 0.0:
                self._pulse = 0.0
                self._pulse_dir = 1.0
        else:
            self._pulse = 1.0
        self.update()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        colors = self._STATE_COLORS.get(self._state, self._STATE_COLORS["idle"])
        core_col  = QColor(colors[0])
        glow_col  = QColor(colors[1])

        cx, cy = 7, 7
        rg = QRadialGradient(cx, cy, 7)
        gc = QColor(core_col)
        gc.setAlpha(max(0, min(255, int(80 * self._pulse))))
        rg.setColorAt(0, gc)
        rg.setColorAt(1, QColor(0, 0, 0, 0))
        p.setBrush(QBrush(rg))
        p.setPen(Qt.PenStyle.NoPen)
        p.drawEllipse(0, 0, 14, 14)

        p.setBrush(QBrush(core_col))
        p.drawEllipse(4, 4, 6, 6)
        p.end()

class GlowButton(QPushButton):
    def __init__(self, text: str, variant: str = "primary", parent=None):
        super().__init__(text, parent)
        self.variant = variant
        self._apply_style()
        self.setCursor(Qt.CursorShape.PointingHandCursor)

    def _apply_style(self):
        c = COLORS
        variant_map = {
            "success": ("#0A2018", "#0E2E20", "#40D080", "#60F090"),
            "danger":  ("#200A18", "#2E1020", "#E04060", "#FF6080"),
            "neutral": ("#0F0F1A", "#141428", c['neon_border'], c['accent_glow']),
            "primary": ("#1A1030", "#1E1540", c['neon_border'], c['accent_glow']),
        }
        bg, hover_bg, border, hborder = variant_map.get(self.variant, variant_map["primary"])
        self.setStyleSheet(f"""
            QPushButton {{
                background: {bg};
                color: {c['text_primary']};
                border: 1px solid {border};
                border-radius: 6px;
                padding: 9px 20px;
                font-weight: 600;
                letter-spacing: 1px;
                font-size: 12px;
            }}
            QPushButton:hover {{
                background: {hover_bg};
                border: 1px solid {hborder};
                color: {c['accent_gold']};
            }}
            QPushButton:pressed {{
                background: {bg};
            }}
            QPushButton:disabled {{
                background: {c['bg_surface']};
                color: {c['text_dim']};
                border-color: {c['bg_border']};
            }}
        """)

    def setVariant(self, variant: str):
        self.variant = variant
        self._apply_style()

class StatCard(QFrame):
    def __init__(self, label: str, value: str = "0", icon: str = "", parent=None, logo: str = ""):
        super().__init__(parent)
        self.setObjectName("stat_card")
        self._setup_style()
        self.setFixedHeight(76)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(14, 10, 14, 10)
        lay.setSpacing(2)

        top = QHBoxLayout()
        if logo:
            import os
            from PyQt6.QtGui import QPixmap
            from PyQt6.QtCore import Qt
            assets_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "assets")
            path = os.path.join(assets_dir, logo)
            if os.path.isfile(path):
                pm = QPixmap(path).scaled(18, 18, Qt.AspectRatioMode.KeepAspectRatio,
                                          Qt.TransformationMode.SmoothTransformation)
                lbl_logo = QLabel()
                lbl_logo.setPixmap(pm)
                lbl_logo.setFixedSize(20, 20)
                lbl_logo.setStyleSheet("background: transparent;")
                top.addWidget(lbl_logo)
        elif icon:
            lbl_icon = QLabel(icon)
            lbl_icon.setStyleSheet(f"color: {COLORS['text_dim']}; font-size: 14px;")
            top.addWidget(lbl_icon)

        lbl_name = QLabel(label.upper())
        lbl_name.setStyleSheet(f"""
            color: {COLORS['text_secondary']};
            font-size: 9px;
            font-weight: 700;
            letter-spacing: 2px;
        """)
        top.addWidget(lbl_name)
        top.addStretch()
        lay.addLayout(top)

        sep = QFrame()
        sep.setFrameShape(QFrame.Shape.HLine)
        sep.setFixedHeight(1)
        sep.setStyleSheet(f"background: {COLORS['bg_border']}; border: none;")
        lay.addWidget(sep)

        self._val_label = QLabel(value)
        self._val_label.setStyleSheet(f"""
            color: {COLORS['accent_gold']};
            font-size: 24px;
            font-weight: 700;
            letter-spacing: 1px;
        """)
        lay.addWidget(self._val_label)

    def _setup_style(self):
        self.setStyleSheet(f"""
            QFrame#stat_card {{
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 {COLORS['bg_elevated']}, stop:1 {COLORS['bg_surface']});
                border: 1px solid {COLORS['bg_border']};
                border-top: 1px solid {COLORS['neon_border']};
                border-radius: 8px;
            }}
        """)

    def set_value(self, val: str):
        self._val_label.setText(val)

class LogConsole(QTextEdit):
    MAX_LINES = 300

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setReadOnly(True)
        self.setStyleSheet(f"""
            QTextEdit {{
                background-color: {COLORS['bg_surface']};
                border: 1px solid {COLORS['bg_border']};
                border-left: 2px solid {COLORS['neon_border']};
                border-radius: 8px;
                padding: 8px 10px;
                font-family: "Cascadia Code", "Consolas", monospace;
                font-size: 11px;
                color: {COLORS['text_primary']};
            }}
        """)
        self._line_count = 0

    def append_log(self, message: str, level: str = "info"):
        import datetime
        ts    = datetime.datetime.now().strftime("%H:%M:%S")
        color = log_color(level)
        icon_map = {"ok": "✓", "warn": "⚠", "error": "✗", "info": "›"}
        icon     = icon_map.get(level, "›")
        safe_msg = html.escape(message)
        dim      = COLORS["text_dim"]
        dim2     = COLORS["text_secondary"]
        line = (
            f'<span style="color:{dim}">[{ts}]</span> '
            f'<span style="color:{dim2}">{icon}</span> '
            f'<span style="color:{color}">{safe_msg}</span>'
        )
        self.append(line)
        self._line_count += 1
        if self._line_count > self.MAX_LINES:
            cursor = self.textCursor()
            cursor.movePosition(cursor.MoveOperation.Start)
            cursor.select(cursor.SelectionType.LineUnderCursor)
            cursor.removeSelectedText()
            cursor.deleteChar()
            self._line_count -= 1
        self.ensureCursorVisible()

    def clear_logs(self):
        self.clear()
        self._line_count = 0

class SectionCard(QFrame):
    def __init__(self, title: str = "", parent=None):
        super().__init__(parent)
        self.setObjectName("section_card")
        self.setStyleSheet(f"""
            QFrame#section_card {{
                background: {COLORS['bg_elevated']};
                border: 1px solid {COLORS['bg_border']};
                border-radius: 10px;
            }}
        """)
        self._root = QVBoxLayout(self)
        self._root.setContentsMargins(0, 0, 0, 0)
        self._root.setSpacing(0)

        if title:
            header = QWidget()
            header.setObjectName("sc_header")
            header.setStyleSheet(f"""
                QWidget#sc_header {{
                    background: transparent;
                    border-bottom: 1px solid {COLORS['bg_border']};
                    border-radius: 0px;
                }}
            """)
            h_lay = QHBoxLayout(header)
            h_lay.setContentsMargins(14, 10, 14, 10)

            accent_bar = QLabel()
            accent_bar.setFixedSize(3, 14)
            accent_bar.setStyleSheet(f"""
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 {COLORS['accent_glow']}, stop:1 {COLORS['accent_2']});
                border-radius: 1px;
            """)
            h_lay.addWidget(accent_bar)
            h_lay.addSpacing(8)

            lbl = QLabel(title)
            lbl.setStyleSheet(f"""
                color: {COLORS['text_secondary']};
                font-size: 9px;
                font-weight: 700;
                letter-spacing: 2px;
            """)
            h_lay.addWidget(lbl)
            h_lay.addStretch()
            self._root.addWidget(header)

        self._content = QWidget()
        self._content.setStyleSheet("background: transparent;")
        self._content_lay = QVBoxLayout(self._content)
        self._content_lay.setContentsMargins(14, 12, 14, 12)
        self._content_lay.setSpacing(8)
        self._root.addWidget(self._content)

    def content_layout(self) -> QVBoxLayout:
        return self._content_lay

class NeonSeparator(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedHeight(2)

    def paintEvent(self, e):
        p = QPainter(self)
        g = QLinearGradient(0, 0, self.width(), 0)
        g.setColorAt(0,   QColor(0, 0, 0, 0))
        g.setColorAt(0.3, QColor(120, 30, 200, 180))
        g.setColorAt(0.5, QColor(200, 60, 255, 255))
        g.setColorAt(0.7, QColor(120, 30, 200, 180))
        g.setColorAt(1,   QColor(0, 0, 0, 0))
        p.fillRect(self.rect(), QBrush(g))
        p.end()
