# Eclipse Macros — Build sécurisé & distribution client

## Ce qui a changé

- Le dossier `server/` et `admin.py` ont été retirés de ce package.
  Garde-les uniquement dans ton repo de travail privé, jamais dans ce qui
  est envoyé au client.
- `install.bat` et `requirements.txt` (anciens) ont été retirés : le
  client n'a plus besoin d'installer Python ni de compiler quoi que ce
  soit. Il reçoit directement un `.exe` prêt à l'emploi.

## Workflow (à faire sur TA machine Windows, jamais chez le client)

1. Place ce dossier complet sur ta machine de dev (avec `main.py`,
   `core/`, `ui/`, `assets/`, `license_client.py`,
   `build_secure.bat`, `requirements_dev.txt`).
2. Double-clique `build_secure.bat`.
   - Installe PyArmor + PyInstaller + dépendances runtime
   - Obfusque tout le code Python avec PyArmor (chiffre le bytecode)
   - Compile un `.exe` unique sans console avec PyInstaller
3. Récupère le fichier dans `dist_client\Eclipse Macros.exe`.

## Ce que tu envoies au client

**UNIQUEMENT** : `dist_client\Eclipse Macros.exe`

C'est le seul fichier nécessaire. Aucun `.py`, aucun dossier `core/`,
`ui/`, `assets/` séparé, aucun `server/`.

## Ce que tu ne dois JAMAIS envoyer

- `main.py`, `core/*.py`, `ui/*.py`, `license_client.py` (sources brutes)
- `obf_dist/` (code obfusqué intermédiaire — toujours plus facile à
  analyser qu'un .exe compilé)
- `server/`, `admin.py` (logique serveur/admin de licence)
- `build/`, les fichiers `.spec`
- `requirements_dev.txt`, `build_secure.bat`

## Limites importantes (honnêteté)

- PyArmor + PyInstaller rendent le reverse engineering coûteux, mais
  pas impossible. Un attaquant déterminé avec assez de temps peut
  toujours dumper la mémoire du process en cours d'exécution.
- L'objectif réaliste est de rendre le piratage plus cher/lent que
  l'achat d'une licence, et de pouvoir révoquer/changer rapidement le
  protocole de licence côté serveur si une clé fuite.
- Pense à régénérer régulièrement le build (PyArmor change la clé de
  chiffrement à chaque génération), ce qui casse les anciens dumps.

## Configuration client (assets/configs/Default.json)

Le fichier reste à `assets/configs/Default.json` à l'intérieur de
l'exe au premier lancement (extrait par PyInstaller dans le dossier
temporaire `_MEIPASS`), puis `ConfigManager` redirige la sauvegarde
vers `%APPDATA%\EclipseMacros\Default.json` comme déjà en place.
Aucun changement de ce côté.
