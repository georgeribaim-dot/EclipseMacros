
import sys
import os

if sys.platform == "win32":
    try:
        import ctypes
        ctypes.windll.shcore.SetProcessDpiAwareness(2)  # PROCESS_PER_MONITOR_DPI_AWARE
    except Exception:
        pass

from PyQt6.QtWidgets import QApplication
from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtGui import QFont, QIcon

def main():
    app = QApplication(sys.argv)
    app.setApplicationName("Eclipse Macro")
    app.setApplicationVersion("3.2")
    app.setOrganizationName("EclipseMacro")

    app.setHighDpiScaleFactorRoundingPolicy(
        Qt.HighDpiScaleFactorRoundingPolicy.PassThrough)

    from ui.theme import build_stylesheet
    app.setStyleSheet(build_stylesheet())

    default_font = QFont("Segoe UI Variable", 10)
    app.setFont(default_font)

    # ── License check (avant tout affichage) ──────────────────────────────────
    from license_client import verify_license
    if not verify_license():
        sys.exit(1)

    # ── Config ────────────────────────────────────────────────────────────────
    from core.config_manager import ConfigManager
    config = ConfigManager()

    # ── Hub : s'ouvre en premier, avant la macro ───────────────────────────────
    from ui.hub_window import HubWindow
    hub = HubWindow()
    hub.show()

    # Quand l'utilisateur clique Start dans le Hub → on lance la macro
    def _launch_macro():
        hub.hide()

        from ui.splash import SplashScreen
        splash = SplashScreen()
        splash.show()
        app.processEvents()

        from ui.main_window import MainWindow
        window = MainWindow(config)

        def _on_splash_done():
            splash.close()
            window.show()
            hub.close()   # libère la mémoire

        splash.finished.connect(_on_splash_done)

        # Garde une référence pour éviter le garbage collect
        _launch_macro._window = window
        _launch_macro._splash = splash

    hub.launch_macro.connect(_launch_macro)

    sys.exit(app.exec())

if __name__ == "__main__":
    main()
